package com.huateng.user.api.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
public @interface OperLog {

	/**操作日志的菜单名称
	 * @return
	 */
	public String menuName() ;
	/**操作日志的功能名称
	 * @return
	 */
	public String functionName();
	/**
	 * 是否保存请求数据
	 */
	public boolean saveRequestData() default true;
}

package com.huateng.user.api.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 模仿shiro/springSecurity,实现资源的安全访问
 * 配置拦截器,对加载SecurityChecker的controller方法,进行拦截
 * @author senvon
 *
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
public @interface SecurityChecker {
	String value();
}

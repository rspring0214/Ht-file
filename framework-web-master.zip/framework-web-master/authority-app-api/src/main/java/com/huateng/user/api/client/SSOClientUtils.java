package com.huateng.user.api.client;

import com.huateng.user.api.model.SSOUser;
import com.huateng.user.api.service.StorageService;
import com.huateng.user.api.utils.UserUtils;

/**
 * 存取sso信息的入口
 * 只保存和登录用户有关的信息
 * 
 * @author senvon
 *
 */
public class SSOClientUtils {

	private static volatile SSOClientUtils instance = null;
	
	private StorageService storageService;
	
	public StorageService getStorageService() {
		return storageService;
	}

	public void setStorageService(StorageService storageService) {
		this.storageService = storageService;
	}

	/**
	 * 对登录用户,存储一个大的key,存储结构如下
	 * key=_USER_ssoUser.tenantCode+ssoUser.userName
	 * key:{
	 *  ,"PC":[token1,token2]
	 *  ,"MOBLIE":[token3,token4]
	 * }
	 */
	public static final String KEY_SSO_USER = "_USER_";
	
	/**
	 * 存储token的缓存,使用token作为key
	 * token:{
	 * ssoUser
	 * deivceIp:[ip1,ip2]
	 * }
	 */
	public static final String KEY_TOKEN = "_TOKEN";
	
	private SSOClientUtils() {
		
	}
	
	public static SSOClientUtils getInstance() {
		if(instance == null) {
			synchronized(SSOClientUtils.class) {
				if(instance == null) {
					instance = new SSOClientUtils();
				}
			}
		}
		return instance;
	}
	
	private ThreadLocal<String> curToken = new ThreadLocal<String>();
//	private ThreadLocal<SSOUser> curUser = new ThreadLocal<SSOUser>();
	
	/**
	 * filter每次获取到登录信息,都对token进行赋值
	 * 方便使用SSOClientUtils.getInstance().getxxx() 直接获取存储的信息
	 * 
	 * 对于param的数据,这边已经对token进行了设置,所有的参数获取如果使用get方式调用的话,直接获取缓存
	 * 没有必要对其余参数进行设置
	 * @param token
	 */
	public void setCurrent(String token) {
		curToken.set(token);
	}
	
	public void removeCurrent(String token) {
		curToken.remove();
	}
	
	/**
	 * 得到当前登录的用户信息
	 * @return
	 */
	public SSOUser findCurrentUser() {
		String tokenKey = SSOClientUtils.KEY_TOKEN + curToken.get();
		SSOUser u = storageService.getObject(curToken.get(), tokenKey, SSOUser.class); 
		return u;
	}
	
	public void putObject(String key , Object obj) {
		storageService.putObject(curToken.get(), key, obj);
	}
	
	/*public void putObject(String key , Object obj, Long expireTime) {
		storageService.putObject(curToken.get(), key, obj, expireTime);
	}*/
	
	public <T> T getObject(String key, Class<T> clazz) {
		return storageService.getObject(curToken.get(), key, clazz);
	}
	
	/*public <T> T getObject(String key, Class<T> clazz, Long expireTime) {
		return storageService.getObject(curToken.get(), key, clazz, expireTime);
	}*/
	
	public void remove(String key){
		storageService.removeObject(curToken.get(), key);
	}
	
	/**
	 * 删除所有登录相关的key
	 */
	public void removeAll() {
		storageService.removeAll(curToken.get());
	}
	
	public boolean hasPermiss(String permiss) {
		SSOUser ssoUser = findCurrentUser();
		if (UserUtils.isAdmin(ssoUser)) {
			return true;
		}
		return ssoUser.getPermissions().contains(permiss);
	}
	
	
}

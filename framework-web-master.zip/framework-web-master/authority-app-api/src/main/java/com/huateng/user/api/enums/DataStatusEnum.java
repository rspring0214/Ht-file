/**
 * Copyright (c) 2018 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.api.enums;

/**
 * Description:是否...统一枚举
 *
 * @author Heaven.tang
 * @version $Id: YesOrNoEnum.java, v 0.1 2018年2月7日 下午5:33:48 Heaven.tang Exp $
 */
public enum DataStatusEnum {

	/**
	 * 是
	 */
    YES("1", "是"),
    /**
     * 否
     */
    NO("2", "否"),
    ;

    private String code;
    private String desc;

    private DataStatusEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static DataStatusEnum findByCode(String code) {
    	for (DataStatusEnum value : DataStatusEnum.values()) {
			if (code.equals(value.getCode())) {
				return value;
			}
		}
    	return null;
	}
    
    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

}

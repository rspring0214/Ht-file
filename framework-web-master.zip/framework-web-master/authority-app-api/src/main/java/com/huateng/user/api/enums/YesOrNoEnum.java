/**
 * Copyright (c) 2018 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.api.enums;

/**
 * Description:是否...统一枚举
 *
 * @author Heaven.tang
 * @version $Id: YesOrNoEnum.java, v 0.1 2018年2月7日 下午5:33:48 Heaven.tang Exp $
 */
public enum YesOrNoEnum {

	/**
	 * 是
	 */
    YES("1", "是"),
    /**
     * 否
     */
    NO("2", "否"),
    ;

    private String code;
    private String desc;

    private YesOrNoEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static YesOrNoEnum findByCode(String code) {
    	for (YesOrNoEnum value : YesOrNoEnum.values()) {
			if (code.equals(value.getCode())) {
				return value;
			}
		}
    	return null;
	}
    
    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

}

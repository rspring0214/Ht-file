/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.api.model;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: BaseException.java, v 0.1 2019年4月3日 下午8:48:11 Heaven.tang Exp $
 */
public class BaseException extends RuntimeException {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = -7513378039499968274L;

	protected String code;
	
	protected String message;

	public BaseException(String message) {
		this.message = message;
	}
	
	public BaseException(String code, String message) {
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	@Override
	public String getMessage() {
		return message;
	}
}

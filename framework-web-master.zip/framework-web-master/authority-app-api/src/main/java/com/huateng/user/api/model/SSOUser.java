package com.huateng.user.api.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SSOUser implements Serializable{

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = -7154053011579158349L;
	
	// 登录用户ID
	private String userId;
	// 登录用户名
	private String userName;
	//登录用户名
	private String loginName;
	// 登录用户租户ID
	private String tenantId;
	// 登录用户租户编号
	private String tenantCode;
	// 登录设备
	private String deviceType = "PC";
	// 登录token
	private String token;
	// 当前用户登录的机构（登录时选择的用户所有挂职机构中的一个）
	private UserDept loginDept;
	// 当前用户所属机构（创建用户的机构/部门）
	private UserDept belongDept;
	// 当前用户登录的角色信息
	private List<UserRole> roles;
	// 当前用户的权限标识列表
	private Set<String> permissions = new HashSet<String>();
	// 登录时间
	private Date loginTime;

	public SSOUser() {
		super();
	}
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getTenantCode() {
		return tenantCode;
	}

	public void setTenantCode(String tenantCode) {
		this.tenantCode = tenantCode;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public UserDept getLoginDept() {
		return loginDept;
	}

	public void setLoginDept(UserDept loginDept) {
		this.loginDept = loginDept;
	}

	public UserDept getBelongDept() {
		return belongDept;
	}

	public void setBelongDept(UserDept belongDept) {
		this.belongDept = belongDept;
	}

	public List<UserRole> getRoles() {
		return roles;
	}

	public void setRoles(List<UserRole> roles) {
		this.roles = roles;
	}

	public Set<String> getPermissions() {
		return permissions;
	}

	public void setPermissions(Set<String> permissions) {
		this.permissions = permissions;
	}

	public Date getLoginTime() {
		return loginTime;
	}

	public void setLoginTime(Date loginTime) {
		this.loginTime = loginTime;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	
}

/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.api.model;

import java.io.Serializable;

/**
 * Description:登录用户组织机构信息
 *
 * @author Heaven.tang
 * @version $Id: UserDept.java, v 0.1 2019年4月10日 下午5:05:15 Heaven.tang Exp $
 */
public class UserDept implements Serializable {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = -7241244724847590063L;
	
	private String id;
	
	private String deptName;
	
	private String deptCode;
	
	private String tenantId;
	
	private String tenantCode;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	public String getTenantCode() {
		return tenantCode;
	}

	public void setTenantCode(String tenantCode) {
		this.tenantCode = tenantCode;
	}
	
}

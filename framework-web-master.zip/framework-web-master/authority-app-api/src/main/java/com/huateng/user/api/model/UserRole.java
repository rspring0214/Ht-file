/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.api.model;

import java.io.Serializable;

/**
 * Description:登录用户角色信息
 *
 * @author Heaven.tang
 * @version $Id: UserRole.java, v 0.1 2019年4月16日 上午10:46:24 Heaven.tang Exp $
 */
public class UserRole implements Serializable {
	
	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = -7128088394068706439L;

	// 角色ID
    private String id;
    
    // 角色名称
    private String roleName;
    
    // 角色权限字符串
    private String roleKey;
    
    // 角色权限范围
    private Integer dataScope;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleKey() {
		return roleKey;
	}

	public void setRoleKey(String roleKey) {
		this.roleKey = roleKey;
	}

	public Integer getDataScope() {
		return dataScope;
	}

	public void setDataScope(Integer dataScope) {
		this.dataScope = dataScope;
	}
    
}

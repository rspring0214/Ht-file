package com.huateng.user.api.service;

import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.user.api.model.SSOUser;

/**
 * 登录服务暴露
 * 
 * 允许用户修改或者自定义登录的验证服务
 * 主要是为了适应登录的验证源,不只有数据库一种,也会有ldap
 * 
 * 只需要应用程序在使用sso的扩展ldap的实现就可以了
 * 
 * 也有可能,不同的租户有不同的登录源
 * 
 * @author senvon
 *
 */
public interface SSOUserService {

	/**执行登录验证操作
	 * 暴露的接口,允许用户进行扩展
	 * 
	 * @param tenantCode 登录页面输入的租户,可能为空
	 * @param userName 登录页面输入的用户名
	 * @param passwd 登录页面输入的密码
	 * @return
	 */
	public ApiBaseResponse<SSOUser> checkPasswd(String tenantCode, String userName , String passwd);
	
}

package com.huateng.user.api.service;

/**
 * 登录信息的存储服务
 * 一般有几个实现
 * SessionStorageService,将登录信息存储在session里面,可以不依赖于任何外部组件,需要开启session和nginx的会话保持
 * EhcacheStorageService,将登录信息保存在ehcache里面,针对小型应用,不依赖于外部组件,不需要开启session
 * RedisStorageService,将登录信息保存在redis里面,需要依赖redis
 * 
 * XXX add by Heaven.tang 使用这种方式，由于各个缓存存储对象支持的范围不同，实际只能使用通用对象，存储时全部转换成json串
 * 
 * @author senvon
 *
 */
public interface StorageService {

	/**获得一个存储的信息,如果不存在,返回null
	 * @param key
	 * @param clazz
	 * @return
	 */
	public <T> T getObject(String token , String key , Class<T> clazz);
	
	/**获得一个存储的信息,如果不存在,返回null,如果存在、更新过期时间
	 * @param key
	 * @param clazz
	 * @param expireSecond
	 * @return
	 */
	public <T> T getObject(String token , String key , Class<T> clazz, Long expireSecond);
	
	/**存储一个信息
	 * 该方法为session的替代,跟随token失效实现
	 * @param token
	 * @param key
	 * @param obj
	 * @param expireSecond
	 */
	public void putObject(String token ,String key , Object obj);
	
	public void putObject(String token ,String key , Object obj , Long expireSecond);
	
	/**移除一个信息
	 * @param key
	 */
	public void removeObject(String token, String key);
	
	/**
	 * 移除所有信息
	 */
	public void removeAll(String token);
}

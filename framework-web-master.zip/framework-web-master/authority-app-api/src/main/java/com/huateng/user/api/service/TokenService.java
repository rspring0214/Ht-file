package com.huateng.user.api.service;

import com.huateng.user.api.model.SSOUser;

/**token的服务
 * 用于继承token的存储
 * 使用user信息，生成token和负责验证token
 * 可以使用cache存储token信息
 * 也可以使用session存储
 * @author senvon
 *
 */
public interface TokenService {

	/**验证token,通过token得到当前的ssouser
	 * @param token
	 * @return
	 */
	public SSOUser verify(String token);
	
}

/**
 * 
 */
package com.huateng.user.api.translate;

import java.util.List;
import java.util.Map;

/**
 * 数据翻译的回调
 * @author senvon
 *
 */
public interface TranslateCallback {

	/**翻译过程中的回调
	 * 使用codeList,进行数据库查询,查询的结果以code,name的方式存储在map里面
	 * @param codeList
	 * @return
	 */
	public Map<Object , Object> translate(List codeList);
}

/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.api.utils;

import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.constants.ExceptionConstants;
import com.huateng.user.api.model.BaseException;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: Echo.java, v 0.1 2019年5月13日 上午10:29:20 Heaven.tang Exp $
 */
public abstract class Echo {

	/**
	 * 只用于检查吐出异常信息
	 * 
	 * @param e
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> ApiBaseResponse<T> toFail(Exception e) {
		String rspMsg = ExceptionConstants.UNKHNOWN_EXCEPTION_MESSAGE;
		if (e instanceof BaseException) {
			rspMsg = e.getMessage();
		}
		return (ApiBaseResponse<T>) new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, rspMsg);
	}
}

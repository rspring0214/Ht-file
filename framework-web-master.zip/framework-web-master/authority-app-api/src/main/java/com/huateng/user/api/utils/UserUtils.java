package com.huateng.user.api.utils;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.api.model.UserRole;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: UserUtils.java, v 0.1 2019年4月8日 上午11:07:05 Heaven.tang Exp $
 */
public class UserUtils {

	/**
	 * 判断当前登录用户是否超级用户
	 * 
	 * @return
	 */
	public static boolean isAdmin() {
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		if (null != user && StringUtils.equals(Constants.SUPER_USER_NAME, user.getLoginName())) {
			return true;
		}
		return false;
	}
	
	/**
	 * 判断当前登录用户是否超级用户
	 * 
	 * @param ssoUser
	 * @return
	 */
	public static boolean isAdmin(SSOUser ssoUser) {
		return Constants.SUPER_USER_NAME.equalsIgnoreCase(ssoUser.getLoginName());
	}

	/**
	 * 判断用户是否是超级用户
	 * 
	 * @param userName
	 * @return
	 */
	public static boolean isAdmin(String userName) {
		return Constants.SUPER_USER_NAME.equalsIgnoreCase(userName);
	}

	/**
	 * 得到当前用户ID
	 * 
	 * @return
	 */
	public static String getCurUserId() {
		return getCurUser().getUserId();
	}
	
	/**
	 * 得到当前用户
	 * 
	 * @return
	 */
	public static SSOUser getCurUser() {
		return SSOClientUtils.getInstance().findCurrentUser();
	}
	
	/**
	 * 得到当前用户登录机构ID
	 * 
	 * @return
	 */
	public static String getCurUserDeptId() {
		return SSOClientUtils.getInstance().findCurrentUser().getLoginDept().getId();
	}
	
	/**
	 * 判断用户是否当前用户
	 * 
	 * @param id
	 * @return
	 */
	public static boolean isCurUser(String id) {
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		return id.compareTo(user.getUserId()) == 0;
	}
	
	/**
	 * 获取登录用户角色信息
	 */
	public static List<UserRole> getCurUserRoles() {
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		return user.getRoles();
	}
	
	/**
	 * 获取登录用户角色信息
	 */
	public static String getCurUserRoleIds() {
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		List<UserRole> roles = user.getRoles();
		StringBuilder roleIdsb = new StringBuilder("");
		if (null == roles || roles.size() == 0) {
			return null;
		}
		for (UserRole role : roles) {
			roleIdsb.append(role.getId()).append(",");
		}
		String roleIds = roleIdsb.toString();
		if (roleIds.lastIndexOf(",") == roleIds.length() - 1) {
			roleIds.substring(0, roleIds.length() - 2);
		}
		return roleIds;
	}
	
	/**
	 * 判断当前用户是否有角色
	 */
	public static boolean hasRole(String roleId) {
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		List<UserRole> roles = user.getRoles();
		if (null == roles || roles.size() == 0) {
			return false;
		}
		for (UserRole userRole : roles) {
			if (StringUtils.equals(userRole.getId(), roleId)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * 组合用于生成加密密码的KEY
	 * 
	 * @param user
	 * @return
	 */
	public static String createPasswdKey(String... args) {
		String key = "";
		for (String arg : args) {
			if (StringUtils.isNotBlank(arg)) {
				key = key + arg;
			}
		}
		return key;
	}
}

/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: CommonController.java, v 0.1 2019年5月10日 下午4:55:31 Heaven.tang Exp $
 */
@RequestMapping("/common")
@Controller
public class CommonController {

	@RequestMapping("forbidden")
	public String showTenant(ModelMap model) {
		return "forbidden";
	}
	
	@RequestMapping("errorUrl")
	public String errorUrl(ModelMap model) {
		return "errorUrl";
	}
}

package com.huateng.user.web.controller;

import java.awt.image.BufferedImage;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ImgGenerateController {

	@RequestMapping(value = "captcha/writeImage")
	public String write(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		int len = 5;
		
		try {
			RandImage img = new RandImage(len);
			response.setHeader("Pragma", "No-cache");
			response.setHeader("Cache-Control", "no-cache");
			response.setDateHeader("Expires", 0);
			BufferedImage bi = img.creatImage();

			// 存放随机码至session中
			request.getSession(true).setAttribute("verifyCode", img.getRandomString());
			ImageIO.write(bi, "JPEG", response.getOutputStream());
		} catch (Exception e) {
			Random random = new Random();
			request.getSession(true).setAttribute("verifyCode", "MSG_CREAGE_ERROR_" + random.nextInt(10000));
		}
		return null;
	}
}

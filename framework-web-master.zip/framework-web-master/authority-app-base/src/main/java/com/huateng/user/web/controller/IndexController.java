package com.huateng.user.web.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.huateng.common.utils.PropertyLoader;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.api.utils.UserUtils;
import com.huateng.user.core.service.MenuInfoService;
import com.huateng.user.core.service.UserDeptRoleService;
import com.huateng.user.dal.model.MenuInfo;
import com.huateng.user.web.model.MenuInfoVo;
import com.huateng.user.web.util.WebCommonUtils;

@Controller
@RequestMapping("/s")
public class IndexController {

	@Autowired
	private MenuInfoService menuInfoService;
	
	@Autowired
	private UserDeptRoleService userDeptRoleService;

	@Value("${sso.token.name:HTtoken}")
	private String tokenName = "";
	
	@RequestMapping("index")
	public String toIndex(ModelMap model , HttpServletRequest request){
		//进入index页面,需要渲染菜单和当前登录用户的信息
		//只要进入index,就需要加载信息
		model.put("storeType", PropertyLoader.getInstance().getProperty("sso.token.storeType", Constants.COOKIE));
		model.put("tokenName", tokenName);
		SSOUser ssoUser = SSOClientUtils.getInstance().findCurrentUser();
		model.put("user", ssoUser);
		List<MenuInfo> menuList = null;
		if (UserUtils.isAdmin(ssoUser)) {
			menuList = menuInfoService.findAllMenu();
		} else {
			menuList = menuInfoService.findMenuInfoByUserId(ssoUser.getUserId(), ssoUser.getLoginDept().getId());
		}
		model.put("menuList", convertMenu(menuList , request.getContextPath()));
		if (!UserUtils.isAdmin(ssoUser)) {
			model.put("canChange", userDeptRoleService.countUserDepts(ssoUser.getUserId()) > 1);
		}

		return "index";
	}
	
	@RequestMapping("main")
	public String toMain(){
		return "main";
	}
	
	/**menuList 是按照parentId排序过的一个平面列表
	 * 将menuList组装成一个带有children的列表
	 * @param menuList
	 * @return
	 */
	private List<MenuInfoVo> convertMenu(List<MenuInfo> menuList , String contextPath){
		if (menuList != null) {
			List<MenuInfoVo> result = new ArrayList<MenuInfoVo>(10);

			for (MenuInfo menuInfo : menuList) {
				MenuInfoVo menuInfoVO = new MenuInfoVo();
				menuInfoVO.setMenuName(menuInfo.getMenuName());
				if (StringUtils.isNotBlank(menuInfo.getUrl())) {
					if(menuInfo.getUrl().toLowerCase().startsWith("http") || menuInfo.getUrl().startsWith("/") 
							|| menuInfo.getUrl().equalsIgnoreCase("#")){
						menuInfoVO.setUrl(menuInfo.getUrl());
					}else{
						menuInfoVO.setUrl(WebCommonUtils.contactPath(contextPath, menuInfo.getUrl()));
					}
					
//					menuInfoVO.setUrl(menuInfo.getUrl());
				}
				menuInfoVO.setId(menuInfo.getId());
				if ("0".equalsIgnoreCase(menuInfo.getParentId())) {
					// 因为排序过,parentId为0,则直接在
					result.add(menuInfoVO);
				} else {
					MenuInfoVo targetMenuInfo = findMenuById(result, menuInfo.getParentId());
					if (targetMenuInfo != null) {
						targetMenuInfo.getChildren().add(menuInfoVO);
					}
				}
			}

			return result;
		}
		return null;
	}

	/**从menuList中,选择id的menu对象
	 * 包含子节点的过滤
	 * @param menuList
	 * @param id
	 * @return
	 */
	private MenuInfoVo findMenuById(List<MenuInfoVo> menuList , String id){
		if (menuList != null) {
			for (MenuInfoVo menuInfo : menuList) {
				if (menuInfo.getId().equalsIgnoreCase(id)) {
					return menuInfo;
				}
				if (menuInfo.getChildren() != null && menuInfo.getChildren().size() > 0) {
					MenuInfoVo childResult = findMenuById(menuInfo.getChildren(), id);
					if (childResult != null) {
						return childResult;
					}
				}
			}
		}
		return null;
	}
}

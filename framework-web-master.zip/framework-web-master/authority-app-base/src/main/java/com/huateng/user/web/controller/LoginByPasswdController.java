package com.huateng.user.web.controller;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.support.RequestContext;

import com.huateng.base.cache.CacheManager;
import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.base.enumration.Enumration;
import com.huateng.common.utils.PropertyLoader;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.constants.ExceptionConstants;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.api.model.UserDept;
import com.huateng.user.api.service.SSOUserService;
import com.huateng.user.api.service.StorageService;
import com.huateng.user.api.utils.UserUtils;
import com.huateng.user.core.model.GlobalUserModel;
import com.huateng.user.core.model.I18NMessageCode;
import com.huateng.user.core.model.LoginModel;
import com.huateng.user.core.security.InnerTokenService;
import com.huateng.user.core.service.AsycRecordService;
import com.huateng.user.core.service.DeptInfoService;
import com.huateng.user.core.service.TenantInfoService;
import com.huateng.user.core.util.Assembler;
import com.huateng.user.dal.model.DeptInfo;
import com.huateng.user.dal.model.LoginInfo;
import com.huateng.user.dal.model.UserOnlineInfo;
import com.huateng.user.web.util.WebCommonUtils;

import eu.bitwalker.useragentutils.UserAgent;

/**
 * @author senvon
 *
 */
@Controller
@RequestMapping("pre")
public class LoginByPasswdController {

	private static final Logger logger = LoggerFactory.getLogger(LoginByPasswdController.class);
	
	@Value("${app.base.url}")
	private String baseUrl;
	
	@Value("${sso.login.success.url}")
	private String loginSuccessUrl;
	
	@Value("${multiple.corporate:false}")
	private boolean multipleCorporate;
	
	@Value("${sso.login.verify.count:3}")
	private Integer overVerifyCount;

	@Value("${sso.token.name:HTtoken}")
	private String tokenName;

	@Value("${sso.token.storeType:cookie}")
	private String storeType;

	@Value("${sso.token.over.strategy:forbidden}")
	private String overStrategy = "forbidden";
	
	@Value("${sso.token.expire.time:1800}")
	private Long tokenExpire;

	@Value("${password.input.error.count:5}")
	private Integer passwordInputErrorCount;
	
	@Value("${auto.unlock.time:-1}")
	private Integer autoUnlockTime;
	
	@Value("${default.tenantCode:''}")
	private String defaultTenantCode;
	
	@Autowired
	private SSOUserService ssoUserService;

	@Autowired
	private InnerTokenService tokenService;
	
//	@Autowired
//	private StorageService storageService;
	
//	@Autowired
//	private UserInfoService userInfoService;
	
	@Autowired
	private DeptInfoService deptService;
	
	@Autowired
	private TenantInfoService tenantService;
	
	@Autowired
	private AsycRecordService asycRecord;
	
	@Autowired
	private StorageService storageService;
	
	
	private final String DICT_TYPE_SYS_YES_NO = "sys_yes_no";
	private final String DICT_CODE_SYS_YES_NO_YES = "sys_yes_no_yes";
	private final String DICT_CODE_SYS_YES_NO_NO = "sys_yes_no_no";
	
//	private final String LOGIN_FRAME_URL = "login/loginFrame";
	private final String PASSWORD_INPUT_ERROR_TIMES = "password_input_error_times";
	
//	private final String TOKEN = "token";
//	private final String NEED_VERIFY = "needVerify";
	/*
	private final String PAGE_ERROR_MESSAGE_CODE = "msg";
	private final String PAGE_ERROR_TARGET_CODE = "target";
	private final String PAGE_ERROR_TARGET_OTHER = "otherError";
	private final String PARAM_TENANT_CODE = "tenantCode";
	private final String PARAM_USER_NAME = "userName";
	private final String PARAM_PASSWD = "passwd";
	private final String PARAM_VERIFY_CODE = "verifyCode";
	private final String PARAM_INPUT_VERIFY_CODE = "inputVerifyCode";
	*/
	/**
	 * 用户名密码的登录
	 * 
	 * 登录流程中的关键步骤 
	 * 1.判断有效性 判断验证码,用户名,密码不能为空
	 *  2.调用loginService,进行数据库验证
	 * 3.数据库验证成功,调用innerTokenService,分配token 一般不允许分配失败,如果pc端限制了登录次数,则T掉最老的登录token信息 
	 * 4.写入登录标识
	 */
	@RequestMapping("login")
	public String login(ModelMap model, LoginModel loginModel, HttpServletRequest request, HttpServletResponse response) {
		/*LoginInfo loginforInfo = new LoginInfo();
		UserAgent agent = UserAgent.parseUserAgentString(request.getHeader("User-Agent"));
		loginforInfo.setBrowser(agent.getBrowser().getName());
		loginforInfo.setIpaddr(WebCommonUtils.getIpAddr(request));
		loginforInfo.setLoginName(loginModel.getUserName());
		loginforInfo.setTenantId(loginModel.getTenantCode());
		loginforInfo.setOs(agent.getOperatingSystem().getName());
		String resultPage = null;
		String token = null;
		String tokenKey = SSOClientUtils.KEY_TOKEN;
		try {
			
			
			resultPage = loginIntern(model, loginModel, request, response);
			
			
			token = model.get(TOKEN) + "";
			tokenKey = tokenKey + token;
			if (StringUtils.equals(resultPage, LOGIN_FRAME_URL)) {
				loginforInfo.setStatus(Integer.parseInt(Enumration.getInstance().findEnumValueByCode(DICT_TYPE_SYS_YES_NO, DICT_CODE_SYS_YES_NO_NO)));
			} else {
				loginforInfo.setStatus(Integer.parseInt(Enumration.getInstance().findEnumValueByCode(DICT_TYPE_SYS_YES_NO, DICT_CODE_SYS_YES_NO_YES)));
			}
			SSOUser user = storageService.getObject(token, tokenKey, SSOUser.class);
			loginforInfo.setTenantId(user.getTenantId());
		} catch (Exception e) {
			logger.error("exception when login ", e);
			resultPage = LOGIN_FRAME_URL;
			loginforInfo.setStatus(Integer.parseInt(Enumration.getInstance().findEnumValueByCode(DICT_TYPE_SYS_YES_NO, DICT_CODE_SYS_YES_NO_NO)));
		}
		loginforInfo.setSessionId(token);
		loginforInfo.setMsg(model.get(PAGE_ERROR_MESSAGE_CODE) + "");
		asycRecord.loginRecord(loginforInfo);

		if (loginforInfo.getStatus() == Integer.parseInt(Enumration.getInstance().findEnumValueByCode(DICT_TYPE_SYS_YES_NO, DICT_CODE_SYS_YES_NO_YES))) {
			UserOnlineInfo userOnlineInfo = new UserOnlineInfo();
			userOnlineInfo.setBrowser(agent.getBrowser().getName());
			userOnlineInfo.setExpireTime(tokenExpire != null ? tokenExpire.intValue() : 60 * 30);
			userOnlineInfo.setIpaddr(WebCommonUtils.getIpAddr(request));
			userOnlineInfo.setLastAccessTime(new Date());
			userOnlineInfo.setLoginName(loginModel.getUserName());
			userOnlineInfo.setOs(agent.getOperatingSystem().getName());
			userOnlineInfo.setSessionId(model.get(TOKEN) + "");
			userOnlineInfo.setStartTimestamp(new Date());
			userOnlineInfo.setStatus(Integer.valueOf(Enumration.getInstance().findEnumValueByCode(DICT_TYPE_SYS_YES_NO, DICT_CODE_SYS_YES_NO_YES)));
			asycRecord.userOnlineRecord(userOnlineInfo);
		}
		if (null != resultPage) {
			model.put("tenants", tenantService.selectTenants());
		}
		return resultPage;*/
		model.put("loginModel", loginModel);
		CheckResult result = doLogin(loginModel, request);
		if(!result.isFlag()) {
			model.put("msg",result.getMessage());
			return "forward:showLogin";
		}
		
		//如果验证通过,生成token
		SSOUser userInfo = result.getSsoUser();
		//登录成功,下次不再显示验证码
		request.getSession(true).removeAttribute("loginTime");
		//不再记录登录失败次数
		String key = loginModel.getTenantCode() + loginModel.getUserName() + PASSWORD_INPUT_ERROR_TIMES;
//		cacheManager.removeObj(key);
		storageService.removeAll(key);
		
		return loginSuccess(model , userInfo , request, response);
	}
	
	//登录动作在这个示例程序里面可能是最复杂的业务逻辑了
	//这部分的业务逻辑的写法,适合所有复杂的业务处理
	//写在这边的废话,让有缘人看到
	public CheckResult doLogin(LoginModel loginModel , HttpServletRequest request ) {
		RequestContext requestContext = new RequestContext(request);
		//输入判断
		CheckResult inputResult = preCheck(loginModel,request, requestContext);
		
		LoginInfo loginforInfo = new LoginInfo();
		UserAgent userAgent = UserAgent.parseUserAgentString(request.getHeader("User-Agent"));
		loginforInfo.setBrowser(userAgent.getBrowser().getName());
		loginforInfo.setIpaddr(WebCommonUtils.getIpAddr(request));
		loginforInfo.setLoginName(loginModel.getUserName());
		loginforInfo.setOs(userAgent.getOperatingSystem().getName());
		loginforInfo.setTenantId(loginModel.getTenantCode());
		loginforInfo.setLoginTime(new Date());
		
		if(!inputResult.isFlag()) {
			loginforInfo.setMsg(inputResult.getMessage());
			loginforInfo.setStatus(Integer.parseInt(Enumration.getInstance().findEnumValueByCode(DICT_TYPE_SYS_YES_NO, DICT_CODE_SYS_YES_NO_NO)));
			asycRecord.loginRecord(loginforInfo);
			return inputResult;
		}
		
		CheckResult serverResult = loginIntern(loginModel , request);
		if(serverResult.isFlag()) {
			loginforInfo.setStatus(Integer.parseInt(Enumration.getInstance().findEnumValueByCode(DICT_TYPE_SYS_YES_NO, DICT_CODE_SYS_YES_NO_YES)));
		}else{
			loginforInfo.setStatus(Integer.parseInt(Enumration.getInstance().findEnumValueByCode(DICT_TYPE_SYS_YES_NO, DICT_CODE_SYS_YES_NO_NO)));
		}
		
		loginforInfo.setMsg(serverResult.getMessage());
		asycRecord.loginRecord(loginforInfo);
		return serverResult;
	}

	static class CheckResult{
		private String message;
		private boolean flag;
		private SSOUser ssoUser;
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public boolean isFlag() {
			return flag;
		}
		public void setFlag(boolean flag) {
			this.flag = flag;
		}
		public SSOUser getSsoUser() {
			return ssoUser;
		}
		public void setSsoUser(SSOUser ssoUser) {
			this.ssoUser = ssoUser;
		}
	}
	
	/**服务器端校验
	 * @param loginModel
	 * @param request
	 * @return
	 */
	public CheckResult loginIntern(LoginModel loginModel, HttpServletRequest request) {
		logger.debug("loginIntern begin...");
		
		RequestContext requestContext = new RequestContext(request);
		
		//校验密码前,先判断当前的用户是否被锁定
		
		
		// 调用用户名密码验证接口
		ApiBaseResponse<SSOUser> checkResponse = ssoUserService.checkPasswd(loginModel.getTenantCode(), loginModel.getUserName(),
				loginModel.getPasswd());

		CheckResult ckRst = checkPasswdResult(loginModel, requestContext, checkResponse);
		if (ckRst != null && !ckRst.isFlag()) {
//			takeLoginParam(model, loginModel);
			return ckRst;
		}
		ckRst.setFlag(true);
		ckRst.setSsoUser(checkResponse.getResult());
		// 登录成功清除验证码相关配置
//		request.getSession(true).removeAttribute(NEED_VERIFY);
		// 组装登录用户详细数据
		findUserDetail(checkResponse.getResult());
		logger.debug("loginIntern end...");
		return ckRst;
		// 如果验证通过，生成token，过程中将登录用户放入缓存，并将token写入浏览器
//		return redirect(model, response, tokenService.generateToken(checkResponse.getResult()));
	}

	/*private void takeLoginParam(ModelMap model, LoginModel loginModel) {
		model.put(PARAM_USER_NAME, loginModel.getUserName());
		if (StringUtils.isNotBlank(loginModel.getTenantCode())) {
			model.put(PARAM_TENANT_CODE, loginModel.getTenantCode());
		}
		if (StringUtils.isNotBlank(loginModel.getVerifyCode())) {
			model.put(PARAM_INPUT_VERIFY_CODE, loginModel.getVerifyCode());
		}
		if (StringUtils.isBlank((String) model.get(PAGE_ERROR_TARGET_CODE))) {
			model.put(PAGE_ERROR_TARGET_CODE, PAGE_ERROR_TARGET_OTHER);
		}
	}*/

	/**
	 * 验证密码前置的基本校验
	 * 
	 * @param model
	 * @param loginModel
	 * @param request
	 * @param requestContext
	 */
	private CheckResult preCheck(LoginModel loginModel, HttpServletRequest request, RequestContext requestContext) {
		// 参数基本校验
		CheckResult ckRst = paramsBasicCheck(loginModel, requestContext);
		if (ckRst != null && !ckRst.isFlag()) {
			//验证不成功,返回
			return ckRst;
		}
		
		// 租户存在验证
		/*ckRst = checkTenant(model, loginModel, requestContext);
		if (StringUtils.isNotBlank(ckRst)) {
			return ckRst;
		}*/
		
		// 已经启用验证码
		// TODO 启用验证码的是,这边一定要开启nginx的会话保持,也会影响一个浏览器,多个标签页登录不同的用户,需要在前端配置一个过滤器,无论怎么样,都需要在请求中设置一个唯一值
		// 保持会话过程中的,对于验证码的不断生成,造成侵占缓存资源
		// HttpServletRequest request = (HttpServletRequest)XssSqlFilter.findRequest();
		HttpSession session = request.getSession(true);
		// 验证码校验
		ckRst = checkVerifyCode(loginModel, session, requestContext);
		if (ckRst != null && !ckRst.isFlag()) {
			return ckRst;
		}

		// 在进行数据库验证之前,对用户的登录次数进行记录,如果登录次数大于一定的数据,就需要展示验证码
		//FIXED 不在这边记录,而是在展示登录页面的时候记录
//		checkLoginTimes(session);

		// 需要在nginx的转发配置里面,增加device的配置
		ckRst = checkDeviceLoginTimes(loginModel, request);
		if (ckRst != null && !ckRst.isFlag()) {
			return ckRst;
		}
		
		return ckRst;
	}

	/**
	 * 校验租户存在性
	 * 
	 * @param model
	 * @param loginModel
	 * @param requestContext 
	 * @return
	 */
	/*private CheckResult checkTenant(ModelMap model, LoginModel loginModel, RequestContext requestContext) {
		boolean pass = true;
		if (multipleCorporate) {
			pass = checkTenant(loginModel);
		} else {
			pass = checkDefaultTenant(loginModel);
		}
		
		CheckResult result = new CheckResult();
		
		if (!pass) {
//			model.put(PAGE_ERROR_MESSAGE_CODE, requestContext.getMessage(I18NMessageCode.AGENT_NOT_EXISTS, "组织机构不存在"));
//			return LOGIN_FRAME_URL;
			result.setFlag(false);
			result.setMessage(requestContext.getMessage(I18NMessageCode.AGENT_NOT_EXISTS, "组织机构不存在"));
			return result;
		}
		
		result.setFlag(true);
		return result;
	}*/

	/**
	 * 
	 * @param loginModel
	 * @param pass
	 * @return
	 */
	/*private boolean checkTenant(LoginModel loginModel) {
		if (UserUtils.isAdmin(loginModel.getUserName())) {
			return true;
		}
		if (StringUtils.isBlank(loginModel.getTenantCode())) {
			logger.warn("Multi tenant mode no super user must input tenantCode");
			return false;
		}
		TenantInfo tenant = tenantService.selectTenantByCode(loginModel.getTenantCode());
		if (null == tenant) {
			logger.error("Multi tenant mode, tenant not found by tenantCode");
			return false;
		}
		return true;
	}

	private boolean checkDefaultTenant(LoginModel loginModel) {
		if (StringUtils.isBlank(defaultTenantCode)) {
			logger.error("Single tenant mode, but defaultTenantCode config not found");
			return false;
		}
		if (UserUtils.isAdmin(loginModel.getUserName())) {
			return true;
		}
		TenantInfo tenant = tenantService.selectTenantByCode(defaultTenantCode);
		if (null == tenant) {
			logger.error("Single tenant mode, but defaultTenantCode data not found");
			return false;
		} else {
			loginModel.setTenantCode(defaultTenantCode);
		}
		return true;
	}*/

	/**
	 * 调用密码校验后续校验
	 * 
	 * @param model
	 * @param loginModel 
	 * @param requestContext
	 * @param checkResponse
	 */
	private CheckResult checkPasswdResult(LoginModel loginModel, RequestContext requestContext, ApiBaseResponse<SSOUser> checkResponse) {
		CheckResult result = new CheckResult();
		result.setFlag(false);
		if (checkResponse == null) {
			result.setMessage("密码校验服务无法调通");
			return result;
		}
		
		if (checkResponse.getRetStatus() == RetStatusEnum.FAIL || checkResponse.getResult() == null) {
			if (StringUtils.isNotBlank(checkResponse.getMessage())) {
				result.setMessage(checkResponse.getMessage());
//				model.put(PAGE_ERROR_MESSAGE_CODE, checkResponse.getMessage());
			} else {
//				model.put(PAGE_ERROR_MESSAGE_CODE, requestContext.getMessage(I18NMessageCode.USER_PASSWORD_NOT_MATCH, "用户名或密码不正确"));
				result.setMessage(requestContext.getMessage(I18NMessageCode.USER_PASSWORD_NOT_MATCH, "用户名或密码不正确"));
			}
			// 密码输错错入次数记录
			if (StringUtils.equals(checkResponse.getCode(), ExceptionConstants.LOGIN_CHECK_PASSWORD_NOT_MATCH_CODE)) {
				Integer times = recordPasswordErrorTimes(loginModel);
				if (times.intValue() >= passwordInputErrorCount) {
					//密码输错一定的次数,锁定用户
					lockUser(loginModel.getTenantCode(), loginModel.getUserName());
				}
			}
			return result;
		}
		result.setFlag(true);
		return result;
	}

	/**
	 * 
	 * @param loginModel
	 * @return
	 */
	private Integer recordPasswordErrorTimes(LoginModel loginModel) {
		if (UserUtils.isAdmin(loginModel.getUserName())) {
			return 0;
		}
		String key = loginModel.getTenantCode() + loginModel.getUserName() + PASSWORD_INPUT_ERROR_TIMES;
//		Integer times = cacheManager.getObj(key , Integer.class);
		Integer times = storageService.getObject("_GLOBAL_", key, Integer.class);
		if (null == times) {
			times = 0;
		}
		times = times + 1;
//		cacheManager.set(key, times);
		storageService.putObject("_GLOBAL_", key, times);
		return times;
	}

	/**
	 * 查询并锁定用户（更改用户状态为2）
	 * 
	 * @param tanentCode
	 * @param userLoginName
	 */
	private void lockUser(String tanentCode, String userLoginName) {
		//TODO 这边应该使用缓存操作,当然,在检查用户名密码之前,还要检查缓存锁定
		//锁定用户,不应该修改数据库记录,还要考虑什么时候改回来,缓存的优点就是自动过期
		
	}

	/**
	 * 基本参数校验，非空、格式要求
	 * 
	 * @param model
	 * @param loginModel
	 * @param requestContext
	 * @return
	 */
	private CheckResult paramsBasicCheck(LoginModel loginModel, RequestContext requestContext) {
		CheckResult result = new CheckResult();
		result.setFlag(false);
		if (loginModel == null) {
			result.setMessage(requestContext.getMessage(I18NMessageCode.NOT_NULL, "登录信息"));
			return result;
		}
		if (StringUtils.isBlank(loginModel.getUserName())) {
			result.setMessage(requestContext.getMessage(I18NMessageCode.PARAMETER_NOT_NULL, new String[]{"用户名"}, "用户名不能为空"));
			return result;
		}
		if (!StringUtils.equals(Constants.SUPER_USER_NAME, loginModel.getUserName()) && multipleCorporate) {
			if (StringUtils.isBlank(loginModel.getTenantCode())) {
				result.setMessage(requestContext.getMessage(I18NMessageCode.PARAMETER_NOT_NULL, new String[]{"租户号"}, "租户不能为空"));
				return result;
			}
		}
		if (StringUtils.isBlank(loginModel.getPasswd())) {
			result.setMessage(requestContext.getMessage(I18NMessageCode.PARAMETER_NOT_NULL, new String[]{"密码"}, "密码不能为空"));
			return result;
		}
		String password = loginModel.getPasswd();
		// 密码如果不在指定范围内 错误
		if (password.length() < Constants.PASSWORD_MIN_LENGTH || password.length() > Constants.PASSWORD_MAX_LENGTH) {
			logger.info("密码不正确，长度需在{}~{}位", Constants.PASSWORD_MIN_LENGTH, Constants.PASSWORD_MAX_LENGTH);
			result.setMessage(requestContext.getMessage(I18NMessageCode.LENGTH_NOT_VALID, new Integer[]{Constants.PASSWORD_MIN_LENGTH, Constants.PASSWORD_MAX_LENGTH}, "密码不正确"));
			return result;
		}

		String userName = loginModel.getUserName();
		// 用户名不在指定范围内 错误
		if (userName.length() < Constants.USERNAME_MIN_LENGTH || userName.length() > Constants.USERNAME_MAX_LENGTH) {
			logger.info("用户名不正确，长度需在{}~{}位", Constants.USERNAME_MIN_LENGTH, Constants.USERNAME_MAX_LENGTH);
			result.setMessage(requestContext.getMessage(I18NMessageCode.LENGTH_NOT_VALID, new Integer[]{Constants.USERNAME_MIN_LENGTH, Constants.USERNAME_MAX_LENGTH}, "用户名不正确"));
			return result;
		}
		// TODO 自定义其他规则校验
		result.setFlag(true);
		return result;
	}
	
	/**
	 * 启用验证码校验
	 * 
	 * @param model
	 * @param loginModel
	 * @param session
	 * @return
	 */
	private CheckResult checkVerifyCode(LoginModel loginModel, HttpSession session, RequestContext requestContext) {
		/*Object needVerify = session.getAttribute(NEED_VERIFY);
		if (null != needVerify) {
			if (StringUtils.isBlank(loginModel.getVerifyCode())) {
				model.put(PAGE_ERROR_TARGET_CODE, PARAM_VERIFY_CODE);
				model.put(PAGE_ERROR_MESSAGE_CODE, requestContext.getMessage(I18NMessageCode.PARAMETER_NOT_NULL, new String[]{"验证码"}, "验证码不能为空"));
				return LOGIN_FRAME_URL;
			}
			String expendVerifyCode = session.getAttribute(PARAM_VERIFY_CODE) + "";
			if (!expendVerifyCode.equalsIgnoreCase(loginModel.getVerifyCode())) {
				logger.info("期望的验证码是{},输入的是{}", expendVerifyCode, loginModel.getVerifyCode());
				model.put(PAGE_ERROR_TARGET_CODE, PARAM_VERIFY_CODE);
				model.put(PAGE_ERROR_MESSAGE_CODE, requestContext.getMessage(I18NMessageCode.PARAMETER_NOT_CORRECT, new String[]{"验证码"}, "验证码不正确"));
				return LOGIN_FRAME_URL;
			}
		}
		return null;*/
		CheckResult result = new CheckResult();
		Integer loginTime = NumberUtils.toInt(session.getAttribute("loginTime")+"", 0);
		
		if(overVerifyCount>0 && loginTime > overVerifyCount){
			//当前session的登录次数超过配置的验证值,就说明需要验证码校验
			String expendVerifyCode = session.getAttribute("verifyCode")+"";
			if(!expendVerifyCode.equalsIgnoreCase(loginModel.getVerifyCode())){
				logger.info("期望的验证码是{},输入的是{}" , expendVerifyCode , loginModel.getVerifyCode());
				result.setFlag(false);
				result.setMessage("验证码不正确,请重新输入");
			}
			
		}
		loginTime++;
		session.setAttribute("loginTime", loginTime);
		result.setFlag(true);
		return result;
	}
	
	/**
	 * 登录验证请求次数校验，严格来说应该需要在数据库层面或者缓存层面验证以满足浏览器多开的情况
	 * 
	 * @param session
	 */
	/*private void checkLoginTimes(HttpSession session) {
		if (overVerifyCount > 0) {
			Integer loginTime = NumberUtils.toInt(session.getAttribute("loginTime") + "", 0);
			loginTime++;
			logger.debug("loginTime:{} , overVerifyCount:{}", loginTime, overVerifyCount);
			session.setAttribute("loginTime", loginTime);
			if (loginTime >= overVerifyCount) {
				session.setAttribute(NEED_VERIFY, true);
			}
		}
	}*/
	
	/**
	 * 设备登录次数校验
	 * 
	 * @param model
	 * @param loginModel
	 * @param request
	 * @return
	 */
	private CheckResult checkDeviceLoginTimes(LoginModel loginModel, HttpServletRequest request) {
		String deviceTypeStr = request.getHeader("device");
		if (StringUtils.isBlank(deviceTypeStr)) {
			deviceTypeStr = "PC";
		}
		CheckResult result = new CheckResult();
		String deviceLogin = PropertyLoader.getInstance().getProperty(deviceTypeStr + ".count", "-1");
		Integer deviceLoginCount = Integer.parseInt(deviceLogin);
		if (deviceLoginCount > 0) {
			// 检查到当前登录设备的登录有次数限制
			//从缓存中获取当前登录名的登录情况,检查当前用户的已登录次数
			GlobalUserModel userModel = tokenService.findUserModel(loginModel.getUserName(), loginModel.getTenantCode());
			if (userModel != null) {
				Integer loginedTime = userModel.findLoginTime(deviceTypeStr);
				// 当当前已经登录的次数大于配置的次数
				if (loginedTime >= deviceLoginCount && overStrategy.equalsIgnoreCase("forbidden")) {
//					model.put(PAGE_ERROR_MESSAGE_CODE, "当前用户登录超过次数,允许登录[" + deviceLoginCount + "]次,请联系管理员");
//					return LOGIN_FRAME_URL;
					result.setFlag(false);
					result.setMessage("当前用户登录超过次数,允许登录["+deviceLoginCount+"]次,请联系管理员");
				}
			}
		}
		result.setFlag(true);
		return result;
	}
	
	/**
	 * 组装登录用户具体信息
	 * 
	 * @param user
	 */
	private void findUserDetail(SSOUser user) {
		// 登录用户所属机构
		if (null != user.getBelongDept() && StringUtils.isNotBlank(user.getBelongDept().getId())) {
			DeptInfo dept = deptService.selectDeptById(user.getBelongDept().getId());
			if (null != dept) {
				user.setBelongDept(Assembler.convertDeptInfo(dept, user.getBelongDept()));
			}
		}
		// 系统超级管理员登录机构和所属机构都是虚拟的
//		if (UserUtils.isAdmin(user)) {
//			user.setLoginDept((UserDept) BeanUtils.propertiesCopy(user.getBelongDept(), new UserDept()));
//			user.setLoginDept( new UserDept());
//		}
		// 登录用户角色信息
//		List<RoleInfo> roles = roleService.selectUserRolesByUserId(user.getUserId());
//		if (CollectionUtils.isNotEmpty(roles)) {
//			List<UserRole> userRoles = BeanUtils.propertiesCopy(roles, new UserRole());
//			user.setRoles(userRoles);
//		}
	}
	
	/**
	 * 最终的跳转处理
	 * 
	 * @param model
	 * @param response
	 * @param token
	 * @return
	 */
//	@RequestMapping("loginSuccess")
	public String loginSuccess(ModelMap model , SSOUser userInfo , HttpServletRequest request , HttpServletResponse response) {
		String token = tokenService.generateToken(userInfo);
		UserOnlineInfo userOnlineInfo = new UserOnlineInfo();
		UserAgent userAgent = UserAgent.parseUserAgentString(request.getHeader("User-Agent"));
		userOnlineInfo.setBrowser(userAgent.getBrowser().getName());
		userOnlineInfo.setIpaddr(WebCommonUtils.getIpAddr(request));
		userOnlineInfo.setLoginName(userInfo.getUserName());
		userOnlineInfo.setOs(userAgent.getOperatingSystem().getName());
		userOnlineInfo.setSessionId(token);
		
		userOnlineInfo.setStatus(Integer.valueOf(Enumration.getInstance().findEnumValueByCode(DICT_TYPE_SYS_YES_NO, DICT_CODE_SYS_YES_NO_YES)));
		
//		userOnlineInfo.setTenantCode(userInfo.getTenantCode());
		if(userInfo.getLoginDept() != null) {
//			userOnlineInfo.setDeptCode(userInfo.getLoginDept().getId());
		}
		asycRecord.userOnlineRecord(userOnlineInfo);
		//登录成功
		//将token写入浏览器
		if(StringUtils.isNotBlank(token)){
			if(storeType.equalsIgnoreCase("cookie")){
				WebCommonUtils.addCookie(response, tokenName, token, null,-1 , request.getContextPath());
			}else{
				model.put("token", token);
				model.put("tokenName", tokenName);
				model.put("setPage", true);
			}
			//跳转到登录页面
//			model.put("targetUrl", baseUrl+loginSuccessUrl);
			model.put("targetUrl", WebCommonUtils.contactPath(baseUrl, loginSuccessUrl));
			return "login/redirect";
		}else{
			model.put("msg", "当前用户已登录,");
			return "login/loginFrame";
		}
	}
	
}

package com.huateng.user.web.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.core.security.InnerTokenService;
import com.huateng.user.core.service.AsycRecordService;
import com.huateng.user.core.service.TenantInfoService;
import com.huateng.user.web.util.WebCommonUtils;

@Controller
@RequestMapping("pre")
public class PreLoginController {

	private static final Logger logger = LoggerFactory.getLogger(PreLoginController.class);
	
	@Value("${app.base.url}")
	private String baseUrl;
	
	@Value("${sso.login.url}")
	private String loginUrl;

	@Value("${sso.login.success.url}")
	private String loginSuccessUrl;

	@Value("${sso.token.name:HTtoken}")
	private String tokenName;
	
	@Value("${sso.lastmenu.auto:false}")
	private Boolean autoOpenLastMenu;

	@Value("${sso.token.storeType:cookie}")
	private String storeType;
	
	@Value("${sso.login.verify.count:3}")
	private Integer overVerifyCount;
	
	@Value("${multiple.corporate:false}")
	private boolean multipleCorporate;
	
	@Autowired
	private InnerTokenService tokenService;
	
	@Autowired
	private TenantInfoService tenantService;
	
	@Autowired
	private AsycRecordService asycRecord;
	
	/**
	 * 控制多iframe显示的后台页面,在最外层的window进行展示登录页面
	 * 如果是正常的退出,也是跳转到toLogin,在最外层的window渲染登录页面
	 * 如果是非正常的退出,比如在打开iframe页面的内部出现,是需要toLogin在浏览器上进行window的切换
	 * 注意toLogin的时候,需要对fromurl进行传递,否则登录页面在登录完成以后,就不能顺利的打开后面的页面
	 * 
	 * @return
	 */
	@RequestMapping("toLogin")
	public String toLogin(ModelMap model, String fromUrl, HttpServletRequest request) {
		String targetUrl = request.getContextPath() + "/pre/preLogin.do";
		if (StringUtils.isNotBlank(fromUrl)) {
			targetUrl = WebCommonUtils.generateFromUrl(targetUrl, "fromUrl", fromUrl);
		}
		return toRedirect(model, targetUrl);
	}

	@RequestMapping("redirect")
	public String toRedirect(ModelMap model, String targetUrl) {
		model.put("targetUrl", targetUrl);
		return "login/redirect";
	}

	/**
	 * 展示登录首页 登录的输入信息以iframe的方式展示,在iframe的外面,都是应用程序自己的事情,和sso无关
	 * 不是默认就展示,如果用户被封了,展示小黑屋页面,不允许用户操作
	 * 
	 * @param model
	 * @param fromUrl
	 * @return
	 */
	@RequestMapping("preLogin")
	public String preLogin(ModelMap model, String fromUrl) {
		if (StringUtils.isNotBlank(fromUrl)) {
			model.put("fromUrl", fromUrl);
		}
		return "login/login";
	}

	/**
	 * 展示登录的iframe信息 传递fromUrl 在这个controller内部,需要对登录信息进行判断
	 * 如果已经包含登录信息的请求,将不会展示登录输入框,而是直接进行跳转到登录成功后的页面 如果已经包含token,而且token是有效的
	 * 在这个页面,会给fromurl生成ticket
	 * 
	 * @param model
	 * @param fromUrl
	 * @return
	 */
	@RequestMapping("showLogin")
	public String showLogin(ModelMap model, HttpServletRequest request, HttpServletResponse response, String fromUrl) {
		if (StringUtils.isNotBlank(fromUrl)) {
			model.put("fromUrl", fromUrl);
		}

/*		Object needVerify = request.getSession(true).getAttribute("needVerify");
		if (needVerify == null) {
			if (overVerifyCount == 0) {
				needVerify = true;
				request.getSession(true).setAttribute("needVerify", needVerify);
			}
		}
		model.put("needVerify", needVerify);

		// 在展示登录输入框之前,判断当前的请求是否包含登录信息
		String token = WebCommonUtils.findToken(request, tokenName);
		logger.debug("find the token:[{}] in the request", token);

		if (StringUtils.isNotBlank(token)) {
			SSOUser ssoUser = tokenService.verify(token);
			if (ssoUser != null) {
				logger.debug("verify token success , the user:{}", ssoUser);
				SSOClientUtils.getInstance().setCurrent(token);

				// 判断当前的fromUrl是否和当前的sso在同一个域里面,如果不再同一个域里面,需要生成ticket再跳转
				// 如果是SSO,需要判断当前的跳转连接是否可以被生成ticket,如果可以,则生成,如果不行,则跳转到登录页面
				return toRedirect(model, baseUrl + loginSuccessUrl);
			} else {
				// 携带的token无效,比如重启后
				// 删除token
				if (storeType.equalsIgnoreCase(Constants.COOKIE)) {
					for (Cookie cookie : request.getCookies()) {
						WebCommonUtils.removeCookie(response, cookie.getName());
					}
				} else {
					model.put("clearPage", true);
				}
			}
		}*/

		HttpSession session = request.getSession(true);
		Integer loginTime = NumberUtils.toInt(session.getAttribute("loginTime")+"", 0);
		logger.debug("showLogin  -====== loginTime:{} , overVerifyCount:{}" , loginTime , overVerifyCount);
		if(overVerifyCount>0 && loginTime >= overVerifyCount){
			model.put("needVerify", true);
		}
		
		//在展示登录输入框之前,判断当前的请求是否包含登录信息
		String token = WebCommonUtils.findToken(request , tokenName);
		logger.debug("find the token:[{}] in the request" , token);
		
		if(StringUtils.isNotBlank(token)){
			SSOUser ssoUser = tokenService.verify(token);
			if(ssoUser != null){
				logger.debug("verify token success , the user:{}" , ssoUser);
				SSOClientUtils.getInstance().setCurrent(token);
				
				//如果是SSO的showLogin,需要判断fromUrl是否在自己的登录授权下面,如果是,则需要通过token给fromUrl生成ticket进行跳转,而不是生成登录页面
				/*String targetDomain = request.getServerName();
				if(StringUtils.isBlank(targetDomain)) {
					targetDomain = request.getServerName(); 
				}*/
				
//				return toRedirect(model, baseUrl+loginSuccessUrl);
				return toRedirect(model, WebCommonUtils.contactPath(baseUrl, loginSuccessUrl));
			}
		}
		
		if (multipleCorporate) {
			model.put("tenants", tenantService.selectTenants());
		}
		
		return "login/loginFrame";
	}

	/**
	 * sso的登出 所有的登出必须交给sso的登出 由sso负责调用外部的登出逻辑
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping("logout")
	public String logout(ModelMap model, HttpServletRequest request, HttpServletResponse response) {
		String token = WebCommonUtils.findToken(request, tokenName);
		if (StringUtils.isNotBlank(token)) {
			SSOUser ssoUser = tokenService.verify(token);
			if (ssoUser != null) {
				SSOClientUtils.getInstance().setCurrent(token);
				// 清空服务器的token,以及所有的ticket
				tokenService.invalidToken(token);
				SSOClientUtils.getInstance().remove(token);
			}
		}

		// 将token从浏览器清除
		if (storeType.equalsIgnoreCase(Constants.COOKIE)) {
			if(request.getCookies() != null){
				for (Cookie cookie : request.getCookies()) {
					if (autoOpenLastMenu && ("lastMenu".equals(cookie.getName()))) {
						continue;
					}
					WebCommonUtils.removeCookie(response, cookie.getName());
				}
			}
		} else {
			model.put("clearPage", true);
		}

		// 用户下线
		asycRecord.userOnlineRemove(token);
		
//		return toRedirect(model, baseUrl + loginUrl);
		return toRedirect(model, WebCommonUtils.contactPath(baseUrl, loginUrl));
	}

}

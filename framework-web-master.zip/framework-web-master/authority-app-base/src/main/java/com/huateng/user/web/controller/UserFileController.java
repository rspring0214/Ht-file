package com.huateng.user.web.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Calendar;
import java.util.Iterator;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.base.export.annotation.Exporter;
import com.huateng.common.idgen.LocalGuidGenerator;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.utils.Echo;
import com.huateng.user.core.exception.DataInvalidException;
import com.huateng.user.core.service.UserFileService;
import com.huateng.user.dal.model.UserFileInfo;

/**
 * 上传下载
 * 
 * @author liushiyu
 * @date 2019年9月10日
 */
@RequestMapping("/userFile")
@Controller
public class UserFileController {

	private static final Logger logger = LoggerFactory.getLogger(UserFileController.class);

	private static ResourceBundle resources = ResourceBundle.getBundle("i18n.MimeMap");
	
	@Value("${file.base.path:/apps/user/upload}")
	private String fileBasePath;

	@Autowired
	private UserFileService service;

	@RequestMapping("/showList")
	public String menu() {
		return "file/list";
	}
	
	/**
	 * 新增
	 */
	@RequestMapping("/addPre")
	public String add() {
		return "file/add";
	}
	
	@RequestMapping("upload")
	@ResponseBody
	public ApiBaseResponse<String[]> upload(HttpServletRequest request, HttpServletResponse response)
			throws IllegalStateException, IOException {
		UserFileInfo info = doUpload(request);
		if(info != null){
			return new ApiBaseResponse<String[]>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
					Constants.API_RESPONSE_SUCCESS_MESSAGE, new String[]{info.getId()});
		}else{
			return new ApiBaseResponse<String[]>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL,
					Constants.API_RESPONSE_FAIL_MESSAGE, null);
		}
	}

	private UserFileInfo doUpload(HttpServletRequest request) throws IllegalStateException, IOException {
		CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(
				request.getSession().getServletContext());
		UserFileInfo info = null;
		if (multipartResolver.isMultipart(request)) {
			MultipartRequest multiRequest = (MultipartRequest) request;
			Iterator<String> iter = multiRequest.getFileNames();

			while (iter.hasNext()) {// SCUBE UI控件只支持单个文件上传
				MultipartFile file = multiRequest.getFile(iter.next());
				if (file != null) {
					long fileId = LocalGuidGenerator.getInstance().nextId();
					info = new UserFileInfo();
					String fileName = file.getOriginalFilename();
					// 建父文件夹
					String filePath = mkPicDir() + File.separator + fileId + fileName;
					File localFile = new File(filePath);
					file.transferTo(localFile);
					info.setPath(localFile.getPath());
					info.setName(fileName);
					info.setType(fileName.substring(fileName.lastIndexOf(".") + 1));
					info.setId(fileId + "");
					service.saveFileInfo(info);
					logger.info("上传成功：" + info);
				}
			}
		}
		return info;
	}
	
	@RequestMapping("download")
	public void download(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		doDownload(request, response);
	}
	
	@RequestMapping("/remove")
	@ResponseBody
	public ApiBaseResponse<?> remove(String id) {
		try {
			service.deletFileById(id);
		} catch (Exception e) {
			logger.error("delete post info exception ", e);
			return Echo.toFail(e);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}
	
	private void doDownload(HttpServletRequest request, HttpServletResponse response) throws IOException{
		String fileId = request.getParameter("id");
		UserFileInfo info = service.queryFileInfo(fileId);
		if(info != null){
			response.setContentType(getMimeType(info.getName()));
			response.setHeader("Content-Disposition","attachment;fileName=\"" + URLEncoder.encode(info.getName(),"UTF-8"));
			OutputStream out = response.getOutputStream();
			File file = new File(info.getPath());
			if(!file.exists()){
				throw new DataInvalidException("文件不存在！");
			}
			FileInputStream fis = null; 
			fis = new FileInputStream(file);
			int fileReaderLength = 0;
			byte[] fileData = new byte[4096];
			while((fileReaderLength = fis.read(fileData)) > 0){
				out.write(fileData,0,fileReaderLength);
			}
			if(out != null){
				out.flush();
			}
			if(fis != null){
				fis.close();
			}
			if(out != null){
				out.close();
			}
		}
	}
	
	@RequestMapping("/search")
	@Exporter("UserFile")
	@ResponseBody
	public ApiBaseResponse<PageInfo<UserFileInfo>> search(
			UserFileInfo info, PageInfo<UserFileInfo> page) {
		if (page == null) {
			page = new PageInfo<UserFileInfo>();
		}
		service.selectFileListByPage(info, page);
		return new ApiBaseResponse<PageInfo<UserFileInfo>>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, page);
	}
	
	private String getMimeType(String fileName){
        String responseHeader = "application/octet-stream";
        int i = fileName.lastIndexOf(".");
        String extendFileName = fileName.substring(i+1);
        if(extendFileName.length()>0){
        	try{
        		if(resources==null){
        			resources = ResourceBundle.getBundle("MimeMap");
        		}
        		responseHeader = resources.getString(extendFileName.toLowerCase());
        	}catch(Exception e){
        		
           	}
        }
        return responseHeader;
    }

	private String mkPicDir() {
		Calendar now = Calendar.getInstance();// 当前日期
		String basePath = fileBasePath + File.separator + now.get(Calendar.YEAR) + File.separator
				+ (now.get(Calendar.MONTH) + 1);
		File file = new File(basePath);
		if (!file.exists()) {
			file.mkdirs();
		}
		return file.getPath();
	}
	
	
	@RequestMapping("/mockFormSave")
	@ResponseBody
	public ApiBaseResponse<?> mockFormSave(HttpServletRequest request) {
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}

}

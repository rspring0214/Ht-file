package com.huateng.user.web.filter;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.alibaba.fastjson.TypeReference;
import com.huateng.base.cache.CacheService;
import com.huateng.base.cache.LoadCacheCallback;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.api.model.UserDept;
import com.huateng.user.api.utils.UserUtils;
import com.huateng.user.core.security.InnerTokenService;
import com.huateng.user.core.service.AsycRecordService;
import com.huateng.user.core.service.MenuInfoService;
import com.huateng.user.core.service.PasswordRecordService;
import com.huateng.user.core.service.UserDeptRoleService;
import com.huateng.user.core.util.BeanUtils;
import com.huateng.user.dal.model.PasswordRecord;
import com.huateng.user.web.util.WebCommonUtils;

/**
 * controller的拦截器
 * 
 * 存在一种情况,登录以后,不能访问主页面,需要额外的选择 场景有 
 * 1.密码过期,强制修改密码
 * 2.同一个用户,在不同机构/角色下面有不同的菜单权限,需要额外选择机构/角色
 * 
 * 主要拦截所有验证请求中的,对controller的拦截 拦截所有的controller,对登录用户的权限进行赋权和验证
 * 
 * 不检查当前登陆的user是否能满足当前的url
 * 
 * @author senvon
 *
 */
public class AuthorizationInterceptor extends HandlerInterceptorAdapter {

	private static final Logger logger = LoggerFactory.getLogger(AuthorizationInterceptor.class);
	
	@Value("${interceptor.ignorRegx}")
	private String interceptorIgnorRegx = "";

	@Value("${sso.token.name:HTtoken}")
	private String tokenName;
	
	@Value("${sso.token.storeType:cookie}")
	private String storeType;
	
	@Value("${app.base.url}")
	private String baseUrl;
	
	@Value("${sso.login.url}")
	private String loginUrl;
	
	@Autowired
	private MenuInfoService menuInfoService;

	@Autowired
	private InnerTokenService tokenService;
	
	@Autowired
	private PasswordRecordService passwordService;
	
	@Autowired
	private CacheService cacheService;
	
	@Autowired
	private UserDeptRoleService userDeptRoleService;
	
	@Autowired
	private AsycRecordService asycRecord;
	
	@Resource(name="viewResolver")
	private ViewResolver resolver;
	
	private static final String FORCE_RESET_PASSWORD_URL = "/s/userInfo/forceResetPwdPre.do";
	
	private static final String SELECT_LOGIN_DEPT_URL = "/s/userDeptRole/showLoginDept.do";
	
	private final String REDIRECT_URL = "login/redirect";
	
	private final String UpdateUserAccessTimeKey = "UpdateUserAccessTimeKey_";

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

		String url = WebCommonUtils.findAccessUrl(request);
		logger.info("AuthorizationInterceptor handle the request:{}", url);
		if (url.matches(interceptorIgnorRegx)) {
			// 如果输入的url,可以匹配到忽略的正则表达式,则跳过当前的url访问
			logger.debug("the request url matched with the regx ");
			return true;
		}

		final SSOUser ssoUser = SSOClientUtils.getInstance().findCurrentUser();
		if (ssoUser == null) {
			// 到了权限验证的时候,发现没有ssouser的信息，跳转到登录页面
			return false;
		}

		// 用户状态权限实时拦截，当前通过缓存存放，可靠性一般，可按需要自行调整
		// FIXED 用户状态变更不对,应该不能登录,不应该不能赋权 
		/*Integer status = (Integer) cacheManager.getObj(ssoUser.getUserId());
		if (null != status && status.intValue() == Constants.COMMON_INVALID.intValue()) {
			// 当前用户已被禁用或锁定，当前是让强退用户、可按需自行调整
			logger.warn("user invalid, id : {}", ssoUser.getUserId());
			tokenService.invalidToken(ssoUser.getToken());
			response.sendRedirect(baseUrl + loginUrl);
			return false;
		}*/
		
		// 1.用户密码验证：是否首次登录，是否过期
		boolean handleResult = prePasswordHandle(request, response, handler, ssoUser);
		if (!handleResult) {
			return handleResult;
		}
		
		// 2.用户机构选择，此处限定登录成功进入主页面前拦截
		handleResult = preDeptHandle(request, response, handler, ssoUser);
		if (!handleResult) {
			return handleResult;
		}
		
		prePermissionHandle(request, response, handler, ssoUser);
		
		cacheService.getObject(UpdateUserAccessTimeKey+ssoUser.getUserId(), new TypeReference<Integer>(){}, 10L, new LoadCacheCallback<Integer>(){

			@Override
			public Integer load() {
				asycRecord.updateOnlineAccessTime(ssoUser.getToken());
				return 1;
			}
			
		});
		
		tokenService.saveTokenModel(ssoUser);
		
		return super.preHandle(request, response, handler);
	}

	/**
	 * 用户机构选择
	 * @throws IOException 
	 */
	private boolean preDeptHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			SSOUser ssoUser) throws Exception {
		if (UserUtils.isAdmin(ssoUser)) {
			if(ssoUser.getLoginDept() == null){
				ssoUser.setLoginDept( new UserDept());
			}
			return true;
		}
		
		//第二次进入过滤器,不做处理 
		if (null != ssoUser.getLoginDept()) {
			return true;
		}
		
		int count = userDeptRoleService.countUserDepts(ssoUser.getUserId());
		if (count > 1) {
			logger.info("redirect to select login dept page, userId : {}", ssoUser.getUserId());
			// 在多个机构/部门下任职、需要进入选择机构页面
			// 查询具体的机构和角色信息
//			response.sendRedirect(request.getContextPath() + "/pre/redirect?targetUrl=" + request.getContextPath() + SELECT_LOGIN_DEPT_URL);
			View view = resolver.resolveViewName(REDIRECT_URL, request.getLocale());
			Map<String , Object> paramMap = new HashMap<String , Object>();
//			paramMap.put("targetUrl", request.getContextPath()+SELECT_LOGIN_DEPT_URL);
			paramMap.put("targetUrl", WebCommonUtils.contactPath(request.getContextPath(), SELECT_LOGIN_DEPT_URL));
			view.render(paramMap, request, response);
			return false;
		} else {
			UserDept dept = BeanUtils.propertiesCopy(ssoUser.getBelongDept(), new UserDept());
			ssoUser.setLoginDept(dept);
			// 只有一个机构，直接更新登录信息
			asycRecord.updateLoginLog(ssoUser);
		}
		
		return true;
	}

	/**
	 * 用户密码验证：是否首次登录，是否过期
	 */
	private boolean prePasswordHandle(HttpServletRequest request, HttpServletResponse response, Object handler, SSOUser ssoUser) throws Exception {
		if (UserUtils.isAdmin(ssoUser)) {
			return true;
		}
		PasswordRecord passwd = passwordService.selectLatestRecordByUserId(ssoUser.getUserId());
		boolean change = false;
		boolean expire = false;
		
		if (null == passwd) {
			logger.warn("Login first time, must change password, user : {}", ssoUser.getUserName());
			change = true;
		} else if (passwd.getExpireTime().compareTo(new Date()) < 0) {
			logger.warn("Password expired, must change password, user : {}", ssoUser.getUserName());
			change = true;
			expire = true;
		}
		
		if (change || expire) {
			logger.info("redirect to forceResetPassword page, userId : {}", ssoUser.getUserId());
			/*response.setCharacterEncoding(CharsetKit.UTF_8);
			String redirectUrl = request.getContextPath() + FORCE_RESET_PASSWORD_URL + "?expire=" + expire;
			if (StringUtils.equals(storeType, Constants.PAGE)) {
				redirectUrl = redirectUrl + "&_token=" + WebCommonUtils.findToken(request, tokenName);
			}
			response.sendRedirect(redirectUrl);*/
			View view = resolver.resolveViewName(REDIRECT_URL, request.getLocale());
			Map<String , Object> paramMap = new HashMap<String , Object>();
//			paramMap.put("targetUrl", request.getContextPath()+FORCE_RESET_PASSWORD_URL);
			paramMap.put("targetUrl", WebCommonUtils.contactPath(request.getContextPath(), FORCE_RESET_PASSWORD_URL));
			view.render(paramMap, request, response);
			return false;
		}
		
		return true;
	}
	
	/**
	 * 用户资源处理
	 */
	private void prePermissionHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			SSOUser ssoUser) throws Exception {
		// 如果是超级管理员，认为拥有全部权限，不需要设置
		if (UserUtils.isAdmin(ssoUser)) {
//			super.preHandle(request, response, handler);
			return;
		}else{
			if (ssoUser.getPermissions() == null || ssoUser.getPermissions().isEmpty()) {
				// TODO 如果用户有多个机构的权限,需要进入选择机构页面,等到用户可以绑定多个机构以后再做开发
				// 如果用户没有权限信息，有可能是因为用户是第一次登录,准备赋权
				logger.info("ready to load user permiss======================");
				UserDept dept = ssoUser.getLoginDept();
				String deptId = null;
				if (null != dept) {
					deptId = dept.getId();
				}
				List<String> permList = menuInfoService.findPermByUserId(ssoUser.getUserId(), deptId);
				if (CollectionUtils.isNotEmpty(permList)) {
					ssoUser.getPermissions().addAll(permList);
				}
				tokenService.saveTokenModel(ssoUser);
			}
		}
	}
}

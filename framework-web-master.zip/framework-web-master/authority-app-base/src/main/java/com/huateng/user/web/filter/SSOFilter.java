package com.huateng.user.web.filter;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

import com.alibaba.fastjson.JSON;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.api.service.TokenService;
import com.huateng.user.web.util.CharsetKit;
import com.huateng.user.web.util.WebCommonUtils;

/**
 * sso的filter,用于识别请求里面的登录标识
 * 如果没有登录标识,则跳转到sso登录页页面
 * 
 * @author senvon
 *
 */
public class SSOFilter implements Filter {
	
	private static final Logger logger = LoggerFactory.getLogger(SSOFilter.class);
	
	/**
	 * 忽略的请求正则表达式
	 */
	@Value("${sso.filter.ignorRegx}")
	private String ignorRegx = "";

	/**
	 * 登录标识的存储key 不管登录标识存储在什么地方,都需要一个key来作为获取的标识 这个就是获取的key
	 */
	@Value("${sso.token.name:HTtoken}")
	private String tokenName = "";

	@Value("${app.base.url}")
	private String baseUrl;
	
	/**
	 * 登录页面所在的url
	 */
	@Value("${sso.login.url}")
	private String loginUrl;

	@Autowired
	private TokenService tokenService;
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	/**
	 * 过滤判断 , 判断步骤如下
	 * 1.对正则表达式判断,是否跳过当前的登录标识判断
	 * 2.获取当前的登录标识,如果能获取登录标识,则对登录标识进行判断,识别登录标识,获取登录信息
	 * 3.如果没有登录标识,则生成fromurl,跳转到sso的登录页面
	 * 
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;
		httpResponse.setCharacterEncoding(CharsetKit.UTF_8);
		String url = WebCommonUtils.findAccessUrl(httpRequest);
//		logger.debug("request===={}" , httpRequest);
		if (url.matches(ignorRegx)) {
			// 如果输入的url,可以匹配到忽略的正则表达式,则跳过当前的url访问
			logger.debug("the request url matched with the regx===={}" , httpRequest);
//			logger.debug("the request url matched with the regx ");
			chain.doFilter(httpRequest, response);
			return;
		}
		
		logger.info("SSOFilter handle the request:{}", url);
		String token = WebCommonUtils.findToken(httpRequest, tokenName);
		if (StringUtils.isNotBlank(token)) {
			logger.debug("find the token [{}] in the request", token);
			// 如果当前的请求能获取token,则进入token的有效性验证
			SSOUser ssoUser = tokenService.verify(token);
			logger.debug("token verify result:{}", null != ssoUser ? ssoUser.getUserName() + " login success" : false);
			if (ssoUser != null) {
				// 如果ssoUser不是null,认为token有效
				// XXX 这边不需要设置登录信息,如果使用threadlocal变量是需要设置的,如果使用singleton单例,可以不用设置,直接从缓存读取
				SSOClientUtils.getInstance().setCurrent(token);
				
				chain.doFilter(httpRequest, response);
				return;
			}
//			WebCommonUtils.removeCookie(httpResponse, tokenName);
		}
		
		// 下面的代码,就是代表无法获取登录标识
		// 需要生成fromurl,跳转到sso的登录页面
		logger.debug("current request will be interapted , the direct url :{}", baseUrl + loginUrl);
		// 判断当前的请求是不是ajax请求
		boolean isAjax = WebCommonUtils.isAjax(httpRequest);
		if(isAjax){
			// 如果是ajax,返回401,由前端负责跳转到登录页面
			httpResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
//			Map<String , Object> resultMap = generateLoginMap(baseUrl + loginUrl);
			Map<String , Object> resultMap = generateLoginMap(WebCommonUtils.contactPath(baseUrl, loginUrl));
			httpResponse.setContentType("application/json");
			httpResponse.getWriter().println(JSON.toJSONString(resultMap));
			httpResponse.getWriter().flush();
			return;
		}
		
//		httpResponse.sendRedirect(baseUrl + loginUrl);
		httpResponse.sendRedirect(WebCommonUtils.contactPath(baseUrl, loginUrl));
	}
	
	/**
	 * ajax请求需要生成跳转地址 要么在前端写死
	 * 
	 * @return
	 */
	private Map<String, Object> generateLoginMap(String loginUrl) {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("url", loginUrl);
		return result;
	}
	
	@Override
	public void destroy() {

	}

}

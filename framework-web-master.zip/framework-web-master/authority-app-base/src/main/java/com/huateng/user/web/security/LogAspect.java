package com.huateng.user.web.security;

import java.lang.reflect.Method;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.alibaba.fastjson.JSON;
import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.base.enumration.Enumration;
import com.huateng.common.web.MultiReadFilter;
import com.huateng.user.api.annotations.OperLog;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.core.service.AsycRecordService;
import com.huateng.user.dal.model.OperLogInfo;
import com.huateng.user.web.util.WebCommonUtils;

@Aspect
public class LogAspect {
	
	@Autowired
	private AsycRecordService asycRecord;

	@AfterReturning(value = "within(@org.springframework.stereotype.Controller *) && @annotation(com.huateng.user.api.annotations.OperLog)", argNames="pjp, result", returning = "result")
	public void recordReturn(JoinPoint pjp, Object result) throws Throwable {
		recordLog(pjp, null, result, null);
	}

	@AfterThrowing(value = "within(@org.springframework.stereotype.Controller *) && @annotation(com.huateng.user.api.annotations.OperLog)", argNames="pjp, ex", throwing = "ex")
	public void recordThrow(JoinPoint pjp, Throwable ex) throws Throwable {
		recordLog(pjp, null, null, ex);
	}

	private void recordLog(JoinPoint pjp, OperLog operLog, Object returnObj, Throwable ex) {
		try {
			if (operLog == null) {
				operLog = findLogAnnotation(pjp);
			}

			OperLogInfo logInfo = new OperLogInfo();
			logInfo.setOperRemark(operLog.functionName());
			logInfo.setTitle(operLog.menuName());
			logInfo.setOperTime(new Date());

			String targetClassName = pjp.getTarget().getClass().getSimpleName();
			String methodName = pjp.getSignature().getName();
			logInfo.setOperMethod(targetClassName + "." + methodName + "()");

//			HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
			HttpServletRequest request = MultiReadFilter.findRequest();
			if (request != null) {
				logInfo.setOperUrl(WebCommonUtils.findAccessUrl(request));
				if (operLog.saveRequestData()) {
					if (!CollectionUtils.sizeIsEmpty(request.getParameterMap())) {
						String paramStr = JSON.toJSONString(request.getParameterMap());
						logInfo.setOperParam(StringUtils.substring(paramStr, 0, 1800));
					}
				}
				logInfo.setOperIp(WebCommonUtils.getIpAddr(request));
			}

			SSOUser ssoUser = SSOClientUtils.getInstance().findCurrentUser();
			if (ssoUser != null) {
				if (null != ssoUser.getLoginDept()) {
					logInfo.setDeptId(ssoUser.getLoginDept().getId());
					logInfo.setDeptName(ssoUser.getLoginDept().getDeptName());
				} else if (null != ssoUser.getBelongDept()) {
					logInfo.setDeptId(ssoUser.getBelongDept().getId());
					logInfo.setDeptName(ssoUser.getBelongDept().getDeptName());
				}
				logInfo.setOperName(ssoUser.getUserName());
			}

			if (ex != null) {
				// 如果出现异常
				logInfo.setStatus(Integer.parseInt(Enumration.getInstance().findEnumValueByCode("sys_yes_no", "sys_yes_no_no")));
				logInfo.setErrorMsg(ex.getMessage());
			} else {
				String resultCode = "sys_yes_no_yes";
				if (returnObj instanceof ApiBaseResponse) {
					resultCode = ((ApiBaseResponse<?>) returnObj).getRetStatus() == RetStatusEnum.SUCCESS ? resultCode : "sys_yes_no_no";
					logInfo.setErrorMsg(((ApiBaseResponse<?>) returnObj).getMessage());
				}
				logInfo.setStatus(Integer.parseInt(Enumration.getInstance().findEnumValueByCode("sys_yes_no", resultCode)));
			}
			asycRecord.operatorRecord(logInfo);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private OperLog findLogAnnotation(JoinPoint jp) throws Exception {
		MethodSignature signature = (MethodSignature) jp.getSignature();
		Method method = signature.getMethod();
		if (method != null) {
			return method.getAnnotation(OperLog.class);
		}
		return null;
	}
}

/**
 * 
 */
package com.huateng.user.web.security;

import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.api.service.SSOUserService;

/**
 * @author senvon
 *
 */
public class MockSSOUserService implements SSOUserService {

	public ApiBaseResponse<SSOUser> checkPasswd(String userName, String passwd, String tenantCode) {
		SSOUser user = new SSOUser();
		user.setUserId("1");
		user.setTenantId(tenantCode);;
		user.setUserName(userName);
		return new ApiBaseResponse<SSOUser>("", RetStatusEnum.SUCCESS, "", user);
	}

}

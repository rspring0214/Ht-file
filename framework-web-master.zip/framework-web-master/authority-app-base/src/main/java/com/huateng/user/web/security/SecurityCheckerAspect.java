package com.huateng.user.web.security;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

import com.alibaba.fastjson.JSON;
import com.huateng.common.web.MultiReadFilter;
import com.huateng.user.api.annotations.SecurityChecker;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.web.util.WebCommonUtils;

/**
 * @author 权限标签认证
 * 权限的认证在controller里面,controller已经是在业务层面
 * 通过@SecurityChecker的注解,拦截所有的注解方法,验证注解内的权限标识
 * 如果没有权限,不能调用controller方法,直接返回
 * 本权限验证,如果不通过,只返回403
 */
@Aspect
public class SecurityCheckerAspect {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Value("${sso.token.storeType:cookie}")
	private String storeType;
	
	@Value("${sso.token.name:HTtoken}")
	private String tokenName;
	
	@Around(value="within(@org.springframework.stereotype.Controller *) && @annotation(SecurityChecker)", argNames="SecurityChecker")
	public Object check(ProceedingJoinPoint pjp, SecurityChecker checkAnnotation) throws Throwable {
		
		String permissStr = checkAnnotation.value();
		logger.info("================the annotation str :{}=========" , permissStr);
		if(hasPermission(permissStr)) {
			//如果配置的权限标识在用户的赋权标识里面
			return pjp.proceed();
		}else {
			//向response里面写入403
			logger.info("the permissStr:{} , current can't has the permiss" , permissStr);
			
			HttpServletRequest request = (HttpServletRequest) MultiReadFilter.findRequest();
			HttpServletResponse response = (HttpServletResponse) MultiReadFilter.findResponse();
			
			writeResponse(request , response);
		}
		return null;
	}
	
	public void writeResponse(HttpServletRequest request , HttpServletResponse response) throws Exception {
		boolean isAjax = WebCommonUtils.isAjax(request);
		String token = WebCommonUtils.findToken(request, "HTtoken");
		String forbiddenUrl = request.getContextPath() + "/common/forbidden";
		if(isAjax){
			//如果是ajax,返回403,由前端负责跳转到登录页面
			response.setStatus(HttpStatus.FORBIDDEN.value());
			Map<String , Object> resultMap = new HashMap<String, Object>();
			resultMap.put("forbiddenUrl", forbiddenUrl);
			
			response.setContentType("application/json");
			response.getWriter().println(JSON.toJSONString(resultMap));
			response.getWriter().flush();
			return;
		}
		
		if (StringUtils.equals(storeType, Constants.PAGE)) {
			forbiddenUrl = forbiddenUrl + "?HTtoken=" + token;
		}
		
		response.sendRedirect(forbiddenUrl);
	}
	
	public static boolean isAjax(HttpServletRequest request){
		return (request.getHeader("X-Requested-With") != null  && "XMLHttpRequest".equals( request.getHeader("X-Requested-With"))) ;
	}
	
	private boolean hasPermission(String permiss) {
		return SSOClientUtils.getInstance().hasPermiss(permiss);
	}
}

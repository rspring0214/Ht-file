/**
 * 
 */
package com.huateng.user.web.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.huateng.common.web.MultiReadFilter;
import com.huateng.user.api.service.StorageService;

/**
 * 使用session作为内部存储机制 需要在web.xml中配置
 * 
 * 需要配置XssSqlFilter,这个filter可以缓存request和response  
 * 
 * @author senvon
 *
 */
public class SessionStorageService implements StorageService {

	@Override
	public void putObject(String token, String key, Object object) {
		putObject(token, key, object, null);

	}

	@Override
	public void putObject(String token, String key, Object object, Long expireSecond) {
		HttpServletRequest request = (HttpServletRequest) MultiReadFilter.findRequest();
		HttpSession session = request.getSession(true);
		session.setAttribute(key, object);
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T getObject(String token, String key, Class<T> clazz) {
		HttpServletRequest request = (HttpServletRequest) MultiReadFilter.findRequest();
		if (request == null) {
			return null;
		}
		HttpSession session = request.getSession(true);
		if (session == null) {
			return null;
		}
		return (T) session.getAttribute(key);
	}

	@Override
	public <T> T getObject(String token, String key, Class<T> clazz, Long expireSecond) {
		return (T) getObject(token, key, clazz);
	}

	@Override
	public void removeObject(String token, String key) {
		HttpServletRequest request = (HttpServletRequest) MultiReadFilter.findRequest();
		if (request == null) {
			return;
		}
		HttpSession session = request.getSession(true);
		if (session == null) {
			return;
		}
		session.removeAttribute(key);
	}

	@Override
	public void removeAll(String token) {
		HttpServletRequest request = (HttpServletRequest) MultiReadFilter.findRequest();
		if (request == null) {
			return;
		}
		HttpSession session = request.getSession(true);
		if (session == null) {
			return;
		}
		session.invalidate();
	}

}

package com.huateng.user.web.translate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.huateng.user.api.translate.TranslateCallback;
import com.huateng.user.dal.dao.UserInfoMapper;
import com.huateng.user.dal.model.UserInfo;
import com.huateng.user.dal.model.UserInfoExample;
import com.huateng.user.web.util.SpringContextHolder;

/**
 * 传入用户的loginName列表
 * 得到用户列表
 * @author senvon
 *
 */
public class LoginNameTranslateCallback implements TranslateCallback {

	@Override
	public Map<Object, Object> translate(List codeList) {
		if(codeList != null && codeList.size()>0) {
			UserInfoMapper userInfoMapper = SpringContextHolder.getInstance().getBean(UserInfoMapper.class);
			UserInfoExample example = new UserInfoExample();
			UserInfoExample.Criteria criteria = example.createCriteria();
			criteria.andLoginNameIn(codeList);
			List<UserInfo> userList = userInfoMapper.selectByExample(example);
			
			Map<Object,Object> result = new HashMap<Object , Object>();
			if(userList != null) {
				for(UserInfo userInfo : userList) {
					result.put(userInfo.getLoginName(), userInfo);
				}
			}
			return result;
		}
		return null;
	}

}

package com.huateng.user.web.util;

import com.huateng.user.core.util.Configs;

/**
 * 页面上获得动态配置的方法
 * @author senvon
 *
 */
public class ConfigTag {

	public String findByKey(String key){
		return Configs.getInstance().findByKey(key);
	}
}

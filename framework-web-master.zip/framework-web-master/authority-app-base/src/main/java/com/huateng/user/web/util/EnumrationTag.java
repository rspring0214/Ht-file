package com.huateng.user.web.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.huateng.base.enumration.Enumration;
import com.huateng.base.enumration.model.EnumrationItem;
import com.huateng.user.core.enumration.EnumrationItemExt;

/**
 * 页面上获取枚举类型
 * @author senvon
 *
 */
public class EnumrationTag {

	/**得到某一个type的所有数据字典项
	 * @param type
	 * @return
	 */
	public List<EnumrationItem> findEnumByType(String type){
		return Enumration.getInstance().findEnumByType(type);
	}
	
	public String findEnumJsonByType(String type){
		List<EnumrationItem> itemList = findEnumByType(type);
		return JSON.toJSONString(itemList);
	}
	
	/**通过编号得到某一个数据字典项的描述
	 * 如果找不到,则返回null
	 * @param type 数据字典类型
	 * @param code 数据字典项编号
	 * @return
	 */
	public String findEnumTextByCode(String type , String code){
		return Enumration.getInstance().findEnumTextByCode(type, code);
	}
	
	/**通过编号得到某一个数据字典项的值
	 * @param type 数据字典类型
	 * @param code 数据字典项编号
	 * @return
	 */
	public String findEnumValueByCode(String type , String code){
		return Enumration.getInstance().findEnumValueByCode(type, code);
	}
	
	/**通过编号得到某一个数据字典项的描述
	 * @param type 数据字典类型
	 * @param value 数据字典项值
	 * @return
	 */
	public String findEnumTextByValue(String type , Object value){
		return Enumration.getInstance().findEnumTextByValue(type, String.valueOf(value));
	}

	public String enumValueTextMap(String type) {
		Map<String, Map<String, String>> map = new HashMap<>();
		for(EnumrationItem enumrationItem : Enumration.getInstance().findEnumByType(type)) {
			map.put(enumrationItem.getValue(), getEnumMap(enumrationItem));
		}

		return JSON.toJSONString(map);
	}

	private Map<String, String> getEnumMap(EnumrationItem enumrationItem) {
		Map<String, String> map = new HashMap <>();
		map.put("value", enumrationItem.getValue());
		map.put("text", enumrationItem.getText());
		map.put("code", enumrationItem.getCode());

		if ( enumrationItem instanceof EnumrationItemExt ) {
			map.put("class", ((EnumrationItemExt)enumrationItem).getListClass());
		} else {
			map.put("class", "primary");
		}

		return map;
	}

}

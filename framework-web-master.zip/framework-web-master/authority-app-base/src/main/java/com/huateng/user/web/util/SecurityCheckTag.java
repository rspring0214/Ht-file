package com.huateng.user.web.util;

import com.huateng.user.api.client.SSOClientUtils;

/**
 * velocity 安全标签,对权限标识进行验证
 * 返回boolean
 * @author senvon
 *
 */
public class SecurityCheckTag {

	public boolean hasPermission(String permission) {
		return SSOClientUtils.getInstance().hasPermiss(permission);
	}
}

package com.huateng.user.web.util;

import com.huateng.common.utils.PropertyLoader;

public class ServerPropertyTag {

	public String findProperty(String name , String defaultValue){
		return PropertyLoader.getInstance().getProperty(name, defaultValue);
	}
}

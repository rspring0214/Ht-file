package com.huateng.user.web.util;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class SpringContextHolder implements ApplicationContextAware{

	private static class SingletonHolder{
		public static SpringContextHolder instance = new SpringContextHolder();
	}
	
	public static SpringContextHolder getInstance(){
		return SingletonHolder.instance;
	}
	
	private ApplicationContext context;
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.context = applicationContext;
	}

	public <T> T getBean(Class<T> clazz){
		return context.getBean(clazz);
	}
	
	public Object getBean(String beanName){
		return context.getBean(beanName);
	}
}

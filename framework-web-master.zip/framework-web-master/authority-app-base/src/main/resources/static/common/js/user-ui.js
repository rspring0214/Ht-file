/**
 * 通用js方法封装处理
 * Copyright (c) 2019 user
 */

window.seltreeArr = {};

(function ($) {
    $.extend({
		scubeui_select:function(option){
			var scubeui_select = new ScubeUI.Select(option);
		},
    	_treeTable: {},
    	_tree: {},
    	// 表格封装处理
    	table: {
            _option: {},
            _params: {},
            // 初始化表格参数
            init: function(options) {
                $.table._option = options;
                $.table._params = $.common.isEmpty(options.queryParams) ? $.table.queryParams : options.queryParams;
                _sidePagination = $.common.isEmpty(options.sidePagination) ? "server" : options.pagination;
                _sortOrder = $.common.isEmpty(options.sortOrder) ? "asc" : options.sortOrder;
                _sortName = $.common.isEmpty(options.sortName) ? "" : options.sortName;
                _pageSize = $.common.isEmpty(options.pageSize) ? 10 : options.pageSize;
                _striped = $.common.isEmpty(options.striped) ? false : options.striped;
                _escape = $.common.isEmpty(options.escape) ? false : options.escape;
                _showFooter = $.common.isEmpty(options.showFooter) ? false : options.showFooter;
                _fixedColumns = $.common.isEmpty(options.fixedColumns) ? false : options.fixedColumns;
                _fixedNumber = $.common.isEmpty(options.fixedNumber) ? 0 : options.fixedNumber;
                _rightFixedColumns = $.common.isEmpty(options.rightFixedColumns) ? false : options.rightFixedColumns;
                _rightFixedNumber = $.common.isEmpty(options.rightFixedNumber) ? 0 : options.rightFixedNumber;
                $('#bootstrap-table').bootstrapTable({
                    url: options.url,                                   // 请求后台的URL（*）
                    contentType: "application/x-www-form-urlencoded",   // 编码类型
                    method: 'post',                                     // 请求方式（*）
                    cache: false,                                       // 是否使用缓存
                    striped: _striped,                                  // 是否显示行间隔色
                    sortable: true,                                     // 是否启用排序
                    sortStable: true,                                   // 设置为 true 将获得稳定的排序
                    sortName: _sortName,                                // 排序列名称
                    sortOrder: _sortOrder,                              // 排序方式  asc 或者 desc
                    pagination: $.common.visible(options.pagination),   // 是否显示分页（*）
                    pageNumber: 1,                                      // 初始化加载第一页，默认第一页
                    pageSize: _pageSize,                                // 每页的记录行数（*） 
                    pageList: [10, 20, 30],                             // 可供选择的每页的行数（*）
                    escape: _escape,                                    // 转义HTML字符串
                    showFooter: _showFooter,                            // 是否显示表尾
                    iconSize: 'outline',                                // 图标大小：undefined默认的按钮尺寸 xs超小按钮sm小按钮lg大按钮
                    toolbar: '#toolbar',                                // 指定工作栏
                    sidePagination: _sidePagination,                    // server启用服务端分页client客户端分页
                    search: $.common.visible(options.search),           // 是否显示搜索框功能
                    showSearch: $.common.visible(options.showSearch),   // 是否显示检索信息
                    showRefresh: $.common.visible(options.showRefresh), // 是否显示刷新按钮
                    showColumns: $.common.visible(options.showColumns), // 是否显示隐藏某列下拉框
                    showToggle: $.common.visible(options.showToggle),   // 是否显示详细视图和列表视图的切换按钮
                    showExport: $.common.visible(options.showExport),   // 是否支持导出文件
                    fixedColumns: _fixedColumns,                        // 是否启用冻结列（左侧）
                    fixedNumber: _fixedNumber,                          // 列冻结的个数（左侧）
                    rightFixedColumns: _rightFixedColumns,              // 是否启用冻结列（右侧）
                    rightFixedNumber: _rightFixedNumber,                // 列冻结的个数（右侧）
                    queryParams: $.table._params,                       // 传递参数（*）
                    columns: options.columns,                           // 显示列信息（*）
                    responseHandler: $.table.responseHandler,           // 在加载服务器发送来的数据之前处理函数
                    onLoadSuccess: $.table.onLoadSuccess               // 当所有数据被加载时触发处理函数
                });
            },
            // 查询条件
            queryParams: function(params) {
            	return {
        			// 传递参数查询参数
                    limit:       params.limit,
                    current:        params.offset / params.limit + 1,
                    searchValue:    params.search,
                    orderByColumn:  params.sort,
                    isAsc:          params.order
        		}; 
            },
            // 请求获取数据后处理回调函数
            responseHandler: function(res) {
                if (res.code == 'S' && res.result) {
                    if ($.common.isNotEmpty($.table._option.sidePagination) && $.table._option.sidePagination === 'client') {
                    	return res.result;
                    } else {
                        return { rows: res.result.data, total: res.result.totalRecord };
                    }
                } else {
                    $.modal.alertWarning(res.message);
                    return { rows: [], total: 0 };
                }
            },
            // 当所有数据被加载时触发
            onLoadSuccess: function(data) {
            	$("[data-toggle='tooltip']").tooltip();
            },
            // 序列号生成
            serialNumber: function (index) {
				var table = $('#bootstrap-table').bootstrapTable('getOptions');
				var pageSize = table.pageSize;
				var pageNumber = table.pageNumber;
				return pageSize * (pageNumber - 1) + index + 1;
			},
			// 列超出指定长度浮动提示
			tooltip: function (value, length) {
				var _length = $.common.isEmpty(length) ? 20 : length;
				var _text = "";
				var _value = $.common.nullToStr(value);
				if (_value.length > _length) {
					_text = _value.substr(0, _length) + "...";
				} else {
					_text = _value;
				}
				return '<a href="#" class="tooltip-show" data-toggle="tooltip" title="' + _value + '">' + _text +'</a>';
			},
            // 搜索-默认第一个form
            search: function(formId) {
            	var currentId = $.common.isEmpty(formId) ? $('form').attr('id') : formId;
    		    var params = $("#bootstrap-table").bootstrapTable('getOptions');
    		    params.queryParams = function(params) {
                    var search = {};
                    $.each($("#" + currentId).serializeArray(), function(i, field) {
                        search[field.name] = field.value;
                    });
                    search.limit = params.limit;
                    search.current = params.offset / params.limit + 1;
                    search.searchValue = params.search;
                    search.orderByColumn = params.sort;
                    search.isAsc = params.order;
    		        return search;
    		    }
    		    $("#bootstrap-table").bootstrapTable('refresh', params);
    		},
    		// 导出数据
    		//modify by senvon 
    		/*exportExcel: function(formId) {
    			var currentId = $.common.isEmpty(formId) ? $('form').attr('id') : formId;
    		    var params = $.table._option;
                var search = {};
                    $.each($("#" + currentId).serializeArray(), function(i, field) {
                        search[field.name] = field.value;
                    });
                    search._userExportFileType = "XLSX";
    			var exportUrl = $.common.convertUrl($.table._option.url);
    			window.ScubeUI.commonFun.download(exportUrl, search);
    		},*/
    		exportExcel: function(formId) {
    			var currentId = $.common.isEmpty(formId) ? $('form').attr('id') : formId;
    			$.modal.loading("正在导出数据，请稍后...");
    			var exportUrl = $.common.convertUrl($.table._option.url);
    			$.ajax({
    				type: "POST",
    				url: exportUrl,
    				data: $("#" + currentId).serializeArray(),
    				dataType:"json",
    				headers: {
    					exportType: "XLSX"
    			    },
    			    success: function(result) {
        				if (result.code == web_status.SUCCESS) {
        					var url = ctx + "/s/common/tempDownload.do?fileId=" + result.fileId;
        			        window.location.href = $.common.convertUrl(url);
        				} else {
        					$.modal.alertError(result.msg);
        				}
        				$.modal.closeLoading();
    			    },
    			    error:function(){
    			    	$.modal.alertError("导出失败");
    			    	$.modal.closeLoading();
    			    }
    			});
    		},
    		// 下载模板
    		importTemplate: function() {
    			$.get($.table._option.importTemplateUrl, function(result) {
    				if (result.code == web_status.SUCCESS) {
    			        window.location.href = ctx + "common/download.do?fileName=" + result.msg + "&delete=" + true;
    				} else {
    					$.modal.alertError(result.msg);
    				}
    			});
            },
            // 导入数据
            importExcel: function(formId) {
            	var currentId = $.common.isEmpty(formId) ? 'importForm' : formId;
            	$.form.reset(currentId);
            	layer.open({
            		type: 1,
            		area: ['400px', '230px'],
            		fix: false,
            		//不固定
            		maxmin: true,
            		shade: 0.3,
            		title: '导入' + $.table._option.modalName + '数据',
            		content: $('#' + currentId),
            		btn: ['<i class="fa fa-check"></i> 导入', '<i class="fa fa-remove"></i> 取消'],
            		// 弹层外区域关闭
            		shadeClose: false,
            		btn1: function(index, layero){
            			var file = layero.find('#file').val();
            			if (file == '' || (!$.common.endWith(file, '.xls') && !$.common.endWith(file, '.xlsx'))){
            				$.modal.msgWarning("请选择后缀为 “xls”或“xlsx”的文件。");
            				return false;
            			}
            			var index = layer.load(2, {shade: false});
            			$.modal.disable();
            			var formData = new FormData();
            			formData.append("file", $('#file')[0].files[0]);
            			formData.append("updateSupport", $("input[name='updateSupport']").is(':checked'));
            			$.ajax({
            				url: $.table._option.importUrl,
            				data: formData,
            				cache: false,
            				contentType: false,
            				processData: false,
            				type: 'POST',
            				success: function (result) {
            					if (result.code == web_status.SUCCESS) {
            						$.modal.closeAll();
            						$.modal.alertSuccess(result.msg);
            						$.table.refresh();
            					} else {
            						layer.close(index);
            						$.modal.enable();
            						$.modal.alertError(result.msg);
            					}
            				}
            			});
            		}
            	});
            },
            // 刷新表格
            refresh: function() {
                $("#bootstrap-table").bootstrapTable('refresh', {
                    silent: true
                });
            },
            // 查询表格指定列值
            selectColumns: function(column) {
            	return $.map($('#bootstrap-table').bootstrapTable('getSelections'), function (row) {
        	        return row[column];
        	    });
            },
            // 查询表格首列值
            selectFirstColumns: function() {
            	return $.map($('#bootstrap-table').bootstrapTable('getSelections'), function (row) {
        	        return row[$.table._option.columns[1].field];
        	    });
            },
            // 回显数据字典
            selectDictLabel: function(datas, value) {
            	var actions = [];
                $.each(datas, function(index, dict) {
                    if (dict.value == value) {
                    	actions.push("<span class='badge badge-" + dict.listClass + "'>" + dict.text + "</span>");
                        return false;
                    }
                });
                return actions.join('');
            },
            // 显示表格指定列
            showColumn: function(column) {
                $("#bootstrap-table").bootstrapTable('showColumn', column);
            },
            // 隐藏表格指定列
            hideColumn: function(column) {
            	$("#bootstrap-table").bootstrapTable('hideColumn', column);
            }
        },
        // 表格树封装处理
        treeTable: {
            _option: {},
            // 初始化表格
            init: function(options) {
                $.table._option = options;
                _striped = $.common.isEmpty(options.striped) ? false : options.striped;
                _expandColumn = $.common.isEmpty(options.expandColumn) ? '1' : options.expandColumn;
                var treeTable = $('#bootstrap-tree-table').bootstrapTreeTable({
                	code: options.code,                                 // 用于设置父子关系
        		    parentCode: options.parentCode,                     // 用于设置父子关系
        	    	type: 'get',                                        // 请求方式（*）
        	        url: options.url,                                   // 请求后台的URL（*）
        	        ajaxParams: {},                                     // 请求数据的ajax的data属性
        			expandColumn: _expandColumn,                        // 在哪一列上面显示展开按钮
        			striped: _striped,                                  // 是否显示行间隔色
        			bordered: true,                                     // 是否显示边框
        			toolbar: '#toolbar',                                // 指定工作栏
        			showRefresh: $.common.visible(options.showRefresh), // 是否显示刷新按钮
        			showColumns: $.common.visible(options.showColumns), // 是否显示隐藏某列下拉框
        			expandAll: $.common.visible(options.expandAll),     // 是否全部展开
        			expandFirst: $.common.visible(options.expandFirst), // 是否默认第一级展开--expandAll为false时生效
        	        columns: options.columns
        	    });
                $._treeTable = treeTable;
            },
            // 条件查询
            search: function(formId) {
            	var currentId = $.common.isEmpty(formId) ? $('form').attr('id') : formId;
            	var params = {myrandom:Math.random()};
            	$.each($("#" + currentId).serializeArray(), function(i, field) {
            		params[field.name] = field.value;
		        });
            	$._treeTable.bootstrapTreeTable('refresh', params);
            },
            // 刷新
            refresh: function() {
            	$._treeTable.bootstrapTreeTable('refresh', {myrandom:Math.random()});
            }
        },
        // 表单封装处理
    	form: {
    		// 表单重置
    		reset: function(formId) {
            	var currentId = $.common.isEmpty(formId) ? $('form').attr('id') : formId;
            	$("#" + currentId)[0].reset();
            },
            // 获取选中复选框项
            selectCheckeds: function(name) {
            	var checkeds = "";
        	    $('input:checkbox[name="' + name + '"]:checked').each(function(i) {
        	        if (0 == i) {
        	        	checkeds = $(this).val();
        	        } else {
        	        	checkeds += ("," + $(this).val());
        	        }
        	    });
        	    return checkeds;
            },
            // 获取选中下拉框项
            selectSelects: function(name) {
            	var selects = "";
        	    $('#' + name + ' option:selected').each(function (i) {
        	        if (0 == i) {
        	        	selects = $(this).val();
        	        } else {
        	        	selects += ("," + $(this).val());
        	        }
        	    });
        	    return selects;
            },
            // 获取选中下拉框项，ScubeUI中将下列列表提交值组装成了数组，将下拉树列表组装成了字符串
            selectScubeSelects: function(name) {
            	var selects = "";
            	var val = window.seltreeArr[name];
            	var valArr = val.data__;
            	for (var i = 0, len = valArr.length; i < len ; i++) {
            		if (0 == i) {
            			selects = valArr[i];
            		} else {
            			selects += ("," + valArr[i]);
            		}
            	}
        	    return selects;
            }
        },
        // 弹出层封装处理
    	modal: {
    		// 显示图标
    		icon: function(type) {
            	var icon = "";
        	    if (type == modal_status.WARNING) {
        	        icon = 0;
        	    } else if (type == modal_status.SUCCESS) {
        	        icon = 1;
        	    } else if (type == modal_status.FAIL) {
        	        icon = 2;
        	    } else {
        	        icon = 3;
        	    }
        	    return icon;
            },
    		// 消息提示
            msg: function(content, type) {
            	if (type != undefined) {
                    layer.msg(content, { icon: $.modal.icon(type), time: 1000, shift: 5 });
                } else {
                    layer.msg(content);
                }
            },
            // 错误消息
            msgError: function(content) {
            	$.modal.msg(content, modal_status.FAIL);
            },
            // 成功消息
            msgSuccess: function(content) {
            	$.modal.msg(content, modal_status.SUCCESS);
            },
            // 警告消息
            msgWarning: function(content) {
            	$.modal.msg(content, modal_status.WARNING);
            },
    		// 弹出提示
            alert: function(content, type) {
        	    layer.alert(content, {
        	        icon: $.modal.icon(type),
        	        title: "系统提示",
        	        btn: ['确认'],
        	        btnclass: ['btn btn-primary']
        	    });
            },
            // 消息提示并刷新父窗体
            msgReload: function(msg, type) {
            	layer.msg(msg, {
            	    icon: $.modal.icon(type),
            	    time: 500,
            	    shade: [0.1, '#8F8F8F']
            	},
            	function() {
            	    $.modal.reload();
            	});
            },
            // 错误提示
            alertError: function(content) {
            	$.modal.alert(content, modal_status.FAIL);
            },
            // 成功提示
            alertSuccess: function(content) {
            	$.modal.alert(content, modal_status.SUCCESS);
            },
            // 警告提示
            alertWarning: function(content) {
            	$.modal.alert(content, modal_status.WARNING);
            },
            // 关闭窗体
            close: function () {
            	var index = parent.layer.getFrameIndex(window.name);
                parent.layer.close(index);
            },
            // 关闭全部窗体
            closeAll: function () {
                layer.closeAll();
            },
            // 确认窗体
            confirm: function (content, callBack) {
            	layer.confirm(content, {
        	        icon: 3,
        	        title: "系统提示",
        	        btn: ['确认', '取消'],
        	        btnclass: ['btn btn-primary', 'btn btn-danger']
        	    }, function (index) {
        	    	layer.close(index);
        	        callBack(true);
        	    });
            },
            // 弹出层指定宽度
            open: function (title, url, width, height, callback) {
            	//如果是移动端，就使用自适应大小弹窗
            	if (navigator.userAgent.match(/(iPhone|iPod|Android|ios)/i)) {
            	    width = 'auto';
            	    height = 'auto';
            	}
            	if ($.common.isEmpty(title)) {
                    title = false;
                };
                if ($.common.isEmpty(url)) {
                    url = "/404.html";
                };
                if ($.common.isEmpty(width)) {
                	width = 800;
                };
                if ($.common.isEmpty(height)) {
                	height = ($(window).height() - 50);
                };
                if ($.common.isEmpty(callback)) {
                    callback = function(index, layero) {
                        var iframeWin = layero.find('iframe')[0];
                        iframeWin.contentWindow.submitHandler();
                    }
                }
            	layer.open({
            		type: 2,
            		area: [width + 'px', height + 'px'],
            		fix: false,
            		//不固定
            		maxmin: true,
            		shade: 0.3,
            		title: title,
//            		content: url,
            		content:$.common.convertUrl(url),
            		btn: ['确定', '关闭'],
            	    // 弹层外区域关闭
            		shadeClose: false,
            		yes: callback,
            	    cancel: function(index) {
            	        return true;
            	    }
            	});
            },
            // 弹出层指定参数选项
            openOptions: function (options) {
            	var _url = $.common.isEmpty(options.url) ? "/404.html" : options.url; 
            	var _title = $.common.isEmpty(options.title) ? "系统窗口" : options.title; 
                var _width = $.common.isEmpty(options.width) ? "800" : options.width; 
                var _height = $.common.isEmpty(options.height) ? ($(window).height() - 50) : options.height;
                layer.open({
                    type: 2,
            		maxmin: true,
                    shade: 0.3,
                    title: _title,
                    fix: false,
                    area: [_width + 'px', _height + 'px'],
//                    content: _url,
                    content:$.common.convertUrl(_url),
                    shadeClose: false,
                    btn: ['<i class="fa fa-check"></i> 确认', '<i class="fa fa-close"></i> 关闭'],
                    yes: function (index, layero) {
                        options.callBack(index, layero)
                    }, cancel: function () {
                        return true;
                    }
                });
            },
            // 弹出层全屏
            openFull: function (title, url, width, height) {
            	//如果是移动端，就使用自适应大小弹窗
            	if (navigator.userAgent.match(/(iPhone|iPod|Android|ios)/i)) {
            	    width = 'auto';
            	    height = 'auto';
            	}
            	if ($.common.isEmpty(title)) {
                    title = false;
                };
                if ($.common.isEmpty(url)) {
                    url = "/404.html";
                };
                if ($.common.isEmpty(width)) {
                	width = 800;
                };
                if ($.common.isEmpty(height)) {
                	height = ($(window).height() - 50);
                };
                var index = layer.open({
            		type: 2,
            		area: [width + 'px', height + 'px'],
            		fix: false,
            		//不固定
            		maxmin: true,
            		shade: 0.3,
            		title: title,
//            		content: url,
            		content:$.common.convertUrl(url),
            		btn: ['确定', '关闭'],
            		// 弹层外区域关闭
            		shadeClose: false,
            		yes: function(index, layero) {
            	        var iframeWin = layero.find('iframe')[0];
            	        iframeWin.contentWindow.submitHandler();
            	    },
            	    cancel: function(index) {
            	        return true;
            	    }
            	});
                layer.full(index);
            },
            // 禁用按钮
            disable: function() {
            	var doc = window.top == window.parent ? window.document : window.parent.document;
	        	$("a[class*=layui-layer-btn]", doc).addClass("layer-disabled");
            },
            // 启用按钮
            enable: function() {
            	var doc = window.top == window.parent ? window.document : window.parent.document;
            	$("a[class*=layui-layer-btn]", doc).removeClass("layer-disabled");
            },
            // 打开遮罩层
            loading: function (message) {
            	$.blockUI({ message: '<div class="loaderbox"><div class="loading-activity"></div> ' + message + '</div>' });
            },
            // 关闭遮罩层
            closeLoading: function () {
            	setTimeout(function(){
            		$.unblockUI();
            	}, 50);
            },
            // 重新加载
            reload: function () {
            	parent.location.reload();
            }
        },
        // 操作封装处理
        operate: {
        	// 提交数据
        	submit: function(url, type, dataType, data) {
        		var config = {
        			url: $.common.convertUrl(url),
        	        type: type,
        	        dataType: dataType,
        	        data: data,
        	        beforeSend: function () {
        	        	$.modal.loading("正在处理中，请稍后...");
        	        },
        	        success: function(result) {
        	        	$.operate.ajaxSuccess(result);
        	        }
        	    };
        	    $.ajax(config)
            },
            // post请求传输
            post: function(url, data) {
            	$.operate.submit(url, "post", "json", data);
            },
            // get请求传输
            get: function(url) {
            	$.operate.submit(url, "get", "json", "");
            },
            // 详细信息
            detail: function(id, width, height) {
            	var _url = $.common.isEmpty(id) ? $.table._option.detailUrl : $.table._option.detailUrl.replace("{id}", id);
                var _width = $.common.isEmpty(width) ? "800" : width; 
                var _height = $.common.isEmpty(height) ? ($(window).height() - 50) : height;
            	//如果是移动端，就使用自适应大小弹窗
            	if (navigator.userAgent.match(/(iPhone|iPod|Android|ios)/i)) {
            	    _width = 'auto';
            	    _height = 'auto';
            	}
            	layer.open({
            		type: 2,
            		area: [_width + 'px', _height + 'px'],
            		fix: false,
            		//不固定
            		maxmin: true,
            		shade: 0.3,
            		title: $.table._option.modalName + "详细",
//            		content: _url,
            		content:$.common.convertUrl(_url),
            		btn: ['关闭'],
            	    // 弹层外区域关闭
            		shadeClose: false,
            		cancel: function(index){
            			return true;
         	        }
            	});
            },
            // 删除信息
            remove: function(id) {
            	$.modal.confirm("确定删除该条" + $.table._option.modalName + "信息吗？", function() {
	            	var url = $.common.isEmpty(id) ? $.table._option.removeUrl : $.table._option.removeUrl.replace("{id}", id);
	            	var data = { "ids": id };
	            	$.operate.submit(url, "post", "json", data);
            	});
            },
            // 批量删除信息
            removeAll: function() {
        		var rows = $.common.isEmpty($.table._option.uniqueId) ? $.table.selectFirstColumns() : $.table.selectColumns($.table._option.uniqueId);
        		if (rows.length == 0) {
        			$.modal.alertWarning("请至少选择一条记录");
        			return;
        		}
        		$.modal.confirm("确认要删除选中的" + rows.length + "条数据吗?", function() {
        			var url = $.table._option.removeUrl;
        			var data = { "ids": rows.join() };
        			$.operate.submit(url, "post", "json", data);
        		});
            },
            // 清空信息
            clean: function() {
            	$.modal.confirm("确定清空所有" + $.table._option.modalName + "吗？", function() {
	            	var url = $.table._option.cleanUrl;
	            	$.operate.submit(url, "post", "json", "");
            	});
            },
            // 添加信息
            add: function(id) {
            	var url = $.common.isEmpty(id) ? $.table._option.createUrl.replace("{id}", '') : $.table._option.createUrl.replace("{id}", id);
                $.modal.open("添加" + $.table._option.modalName, url);
            },
            // 修改信息
            edit: function(id) {
            	var url = "/404.html";
            	if ($.common.isNotEmpty(id)) {
            	    url = $.table._option.updateUrl.replace("{id}", id);
            	} else {
            	    var id = $.common.isEmpty($.table._option.uniqueId) ? $.table.selectFirstColumns() : $.table.selectColumns($.table._option.uniqueId);
            	    if (id.length == 0) {
            			$.modal.alertWarning("请至少选择一条记录");
            			return;
            		}
            	    url = $.table._option.updateUrl.replace("{id}", id);
            	}
            	$.modal.open("修改" + $.table._option.modalName, url);
            },
            // 工具栏表格树修改
            editTree: function() {
            	var row = $('#bootstrap-tree-table').bootstrapTreeTable('getSelections')[0];
            	if ($.common.isEmpty(row)) {
        			$.modal.alertWarning("请至少选择一条记录");
        			return;
        		}
                var url = $.table._option.updateUrl.replace("{id}", row[$.table._option.uniqueId]);
                $.modal.open("修改" + $.table._option.modalName, url);
            },
            // 添加信息 全屏
            addFull: function(id) {
            	var url = $.common.isEmpty(id) ? $.table._option.createUrl : $.table._option.createUrl.replace("{id}", id);
                $.modal.openFull("添加" + $.table._option.modalName, url);
            },
            // 修改信息 全屏
            editFull: function(id) {
            	var url = "/404.html";
            	if ($.common.isNotEmpty(id)) {
            	    url = $.table._option.updateUrl.replace("{id}", id);
            	} else {
            	    var row = $.common.isEmpty($.table._option.uniqueId) ? $.table.selectFirstColumns() : $.table.selectColumns($.table._option.uniqueId);
            	    url = $.table._option.updateUrl.replace("{id}", row);
            	}
            	$.modal.openFull("修改" + $.table._option.modalName, url);
            },
            // 保存信息
            save: function(url, data) {
            	var config = {
        	        url: $.common.convertUrl(url),
        	        type: "post",
        	        dataType: "json",
        	        data: data,
        	        beforeSend: function () {
        	        	$.modal.loading("正在处理中，请稍后...");
        	        	$.modal.disable();
        	        },
        	        success: function(result) {
        	        	$.operate.successCallback(result);
        	        }
        	    };
        	    $.ajax(config)
            },
            // 保存结果弹出msg刷新table表格
            ajaxSuccess: function (result) {
            	if (result.code == web_status.SUCCESS) {
                	$.modal.msgSuccess(result.message);
            		$.table.refresh();
                } else {
                	$.modal.alertError(result.message);
                }
            	$.modal.closeLoading();
            },
            // 成功结果提示msg（父窗体全局更新）
            saveSuccess: function (result) {
            	if (result.code == web_status.SUCCESS) {
            		$.modal.msgReload("保存成功,正在刷新数据请稍后……", modal_status.SUCCESS);
                } else {
                	$.modal.alertError(result.message);
                }
            	$.modal.closeLoading();
            },
            // 成功回调执行事件（父窗体静默更新）
            successCallback: function(result) {
		var parentWin=parent;
                if (result.code == web_status.SUCCESS) {
                    if (parentWin.$("#bootstrap-table").length > 0) {
                        $.modal.close();
                        parentWin.$.modal.msgSuccess(result.message);
                        parentWin.$.table.refresh();
                    } else if (parentWin.$("#bootstrap-tree-table").length > 0) {
                        $.modal.close();
                        parentWin.$.modal.msgSuccess(result.message);
                        parentWin.$.treeTable.refresh();
                    } else {
                        $.modal.msgReload("保存成功,正在刷新数据请稍后……", modal_status.SUCCESS);
                    }
                } else {
                    $.modal.alertError(result.message);
                }
                $.modal.closeLoading();
                $.modal.enable();
            }
        },
        // 校验封装处理
        validate: {
        	// 判断返回标识是否唯一 false 不存在 true 存在
        	unique: function (value) {
            	return value;
            },
            // 表单验证
            form: function (formId) {
            	var currentId = $.common.isEmpty(formId) ? $('form').attr('id') : formId;
                return $("#" + currentId).validate().form();
            }
        },
		//下拉树
		selectTree:{
			/**
			 * @class ScubeUI.Select
			 * @constructor
			 * @extends ScubeUI.UIComponent
			 * @param { object } option 配置参数对象
			 * @param {String} [option.type='text'] 下拉框的展示形式，type='tree'树形展示
			 * @param { array } [option.options] 数据源 优先级比dataSources高
			 * @param { array } [option.dataSources] 数据源，作用同上
			 * @param { array } [option.data] 数据源选中值
			 * @param { string } [option.sVal] 数据交互使用的 key 字段
			 * @param { string } [option.sPVal] 当属性type='tree'时,指定节点的父标识
			 * @param { string } [option.sName] 页面展示使用的 name 字段 
			 * @param { boolean } [option.multiple=false] 标识是否多选
			 * @param { boolean } [option.disabled=false] 是否可编辑
			 * @param {boolean} [option.hasDefaultOption = true] 是否显示默认 '请选择...'选项
			 * @param { string } [option.container] DOM容器的类名
			 * @param { string } [option.labelWidth] 设置标签宽度
			 * @param { string } [option.labelAlign] 设置标签方向
			 * @param { string } [option.labelName] 设置标签名称
			 * @param {Function} [options.onchange] 改变选项时调用的onchange回调函数
			 * @param { string } [option.name] 设置组件唯一名称
			 * @param { array } [option.validate] 设置验证规则
			 * @param { boolean } [option.placeholder] 设置placeholder
			 * @param { boolean } [option.sessionMode]  以输入值为条件筛选下拉项.<br>
			 * 若值为 false,则在已存在的下拉项中筛选;<br>
			 * 若值为 true,则异步加载筛选项.
			 * @param { string } [option.method = post] 当sessionMode=true时，异步提交方式
			 * @param { string } [option.url] 当sessionMode=true时，异步提交的url地址 
			 * @param { string } [option.dataUrl] 下拉数据源的url  有就从url取数据 没有则取传入的options
			 */
			init: function(options) {
				var dataSource=[],selectData=[];
				
				var default_options={
					container: "",
					name: 'select-tree-1',
					multiple: false,
					placeholder: '请选择...',
					options: dataSource,
					data: selectData,
					type: 'tree',
					sVal: 'id',
					//reflectVal: 'name',//type = 'tree'时有效
					sName: 'name',
					sPVal: 'pId',
					treeGrandKeyValue: '0',
					isSimpleData: true,
					isCheckable: true,
					isAllshow: false,
					isCheckRelation: false,
					isMultiSelection:true,
					hasDefaultOption:true
				}
				
				if (options.extendData) {
					// 作为额外的数据补充，数据结构是map
					$.each(options.extendData, function(key, value){
						if (key == options.sVal) {
							selectData.push(value);
						}
					});
					dataSource.push(options.extendData);
				}
				
				if (options.dataUrl) {
					$.ajax({
						type:"get",
						url:options.dataUrl,
						data:options.data,
						dataType:"JSON",
						success:function(data){
							$.each(data, function(i, item){
								var obj = {};
								obj["disabled"] = item["disabled"];
								obj[options.sVal] = item[options.sVal];
								obj[options.sName] = item[options.sName];
								if (options.type == "tree") {
									if (item["checked"]) {
										if ($.inArray(item[options.sVal]) == -1) {
											selectData.push(item[options.sVal]);
										}
									}
									obj[options.sPVal] = item[options.sPVal];
								}
								if (options.type == "text") {
									if (item["flag"]) {
										if ($.inArray(item[options.sVal]) == -1) {
											selectData.push(item[options.sVal]);
										}
									}
								}
								var add = true;
								// 排除因扩展数据带来的重复记录
								if (options.extendData && item[options.sVal] == options.extendData[options.sVal]) {
									$.each(dataSource, function(idx, dataObj){
										if (dataObj[options.sVal] == options.extendData[options.sVal]) {
											add = false;
											return;
										}
									});
								}
								if (add) {
									dataSource.push(obj);
								}
							});

							var _options=$.extend(default_options, options)
							window.seltreeArr[options.container] = new ScubeUI.Select(_options);
//							window.seltree = new ScubeUI.Select(_options);
						}
					});
				} else {
					var _options=$.extend(default_options, options)
					window.seltreeArr[options.container] = new ScubeUI.Select(_options);
//					window.seltree = new ScubeUI.Select(_options);
				}
				return window.seltreeArr[options.container];
			}
		},

		//下拉表格
		ConditionalFilter:{
			/**
			 * 一个带条件的查询控件，查询的结果存储在{{#crossLink "ScubeUI.DataGrid"}}DataGrid{{/crossLink}}中，构造函数中需要单独配置{{#crossLink "ScubeUI.DataGrid"}}DataGrid{{/crossLink}}的生成参数
			 * @class ScubeUI.ConditionalFilter
			 * @extends ScubeUI.UIComponent
			 * @constructor
			 * @param {Object} option
			 * @param {String} [option.labelName] 组件标签名
			 * @param {Number} [option.labelWidth=120] 标签宽度
			 * @param {String} [option.labelAlign=right] 标签对齐方式
			 * @param {String} [option.url] 表格数据
			 * @param {String} [option.placeholder] 在内容为空时组件显示的提示文字
			 * @param {Number} [option.colspan=2] 条件输入框一行排几列
			 * @param {String} [option.conditionalType] 指示条件输入组件的排列类型，为tiny时忽略colspan指定的值，所有组件排在一行,参考demo
			 * @param {Object} [option.tagOption] 选择结果的tag配置项
			 * @param {String} [option.labelTemplate] 选择结果的显示模板
			 * @param {Boolean} [option.autoFetch=false] 组件点击后是否自动查询
			 * @param {Object} [option.variables] 自定义要提交的表单控件项
			 * @param {[[Object]]} option.conditionals 配置条件输入组件
			 * @param {Function} option.conditionals.refType 条件组件类引用
			 * @param {Object} option.conditionals.params* 其他配置参数
			 * @param {Object} option.dataContainer 配置数据组件构造参数，目前是{{#crossLink "ScubeUI.DataGrid"}}DataGrid{{/crossLink}}，可选{{#crossLink "ScubeUI.Tree"}}Tree{{/crossLink}}
			 * @param {Object} option.dataContainer.refType 组件类型 可选ScubeUI.DataGrid与ScubeUI.Tree
			 * @param {Object} option.dataContainer.params* 其他配置参数
			 * @param {[ScubeUI.ValidateOption]} [option.validate] 验证规则,参考demo:validate
			 * @param {[[Object]]} [option.data] 组件默认值，包含了显示以及传输到后端必须的字段，参考demo
			 * @demo conditional1.html
			 */
			init: function(options) {
				var dataSource=[],selectData=[];
				
				var default_options={
					name: 'mycontrol',
					container: ".ConditionalFilter",
					labelName: '条件查询',
					labelAlign: 'left',
					labelWidth: 80,
					conditionalType: 'tiny',
					placeholder: '输入符合条件的人员',
					autoFetch: true,
					disabled: false,
					url:"",
					keepItSimple: true,
					onchange: function onchange() {
						//ScubeUI.exec('cchange');
					},
					conditionals: [{
						refType: ScubeUI.Input,
						labelName: '输入姓名',
						name: 'name',
						labelWidth: 80,
						data: 'hallb',
						validate: [{
							rule: 'required'
						}]
					}, {
						refType: ScubeUI.InputNumber,
						name: 'age',
						labelName: '输入年龄',
						min: 18,
						max: 88,
						labelWidth: 80
					}],
					dataContainer: {
						refType: ScubeUI.DataGrid,
						name: 'list',
						selectMode: 'multi',
						pageSize: 5,
						//key: 'id',
						columns: [{
							label: '姓名',
							prop: 'name'
						}, {
							label: '性别',
							prop: 'sex'
						}]
					}
					
				};
				var _options=$.extend(default_options, options)
				return new ScubeUI.ConditionalFilter(_options);
			}
		},
		
        // 树插件封装处理
        tree: {
        	_option: {},
        	_lastValue: {},
        	// 初始化树结构
        	init: function(options) {
        		$.tree._option = options;
        		// 属性ID
        		var _id = $.common.isEmpty(options.id) ? "tree" : options.id;
        		// 展开等级节点
        		var _expandLevel = $.common.isEmpty(options.expandLevel) ? 0 : options.expandLevel;
        		// 树结构初始化加载
        	    var setting = {
        	    	check: options.check,
        	        view: { selectedMulti: false, nameIsHTML: true },
        	        data: { key: { title: "title" }, simpleData: { enable: true } },
        	        callback: { onClick: options.onClick }
        	    };
        	    $.get(options.url, function(data) {
        	    	var treeName = $("#treeName").val();
        			var treeId = $("#treeId").val();
//        			tree = $.fn.zTree.init($("#" + _id), setting, JSON.parse(data));
        			tree = $.fn.zTree.init($("#" + _id), setting, data);
        			$._tree = tree;
        			// 展开第一级节点
        			var nodes = tree.getNodesByParam("level", 0);
        			for (var i = 0; i < nodes.length; i++) {
        				if(_expandLevel > 0) {
        					tree.expandNode(nodes[i], true, false, false);
        				}
    				    $.tree.selectByIdName(treeId, treeName, nodes[i]);
        			}
        			// 展开第二级节点
        			nodes = tree.getNodesByParam("level", 1);
        			for (var i = 0; i < nodes.length; i++) {
        				if(_expandLevel > 1) {
        					tree.expandNode(nodes[i], true, false, false);
        				}
    				    $.tree.selectByIdName(treeId, treeName, nodes[i]);
        			}
        			// 展开第三级节点
        			nodes = tree.getNodesByParam("level", 2);
        			for (var i = 0; i < nodes.length; i++) {
        				if(_expandLevel > 2) {
        					tree.expandNode(nodes[i], true, false, false);
        				}
    				    $.tree.selectByIdName(treeId, treeName, nodes[i]);
        			}
        		}, null, null, "正在加载，请稍后...");
        	},
        	// 搜索节点
        	searchNode: function() {
        		// 取得输入的关键字的值
        		var value = $.common.trim($("#keyword").val());
        		if ($.tree._lastValue === value) {
        		    return;
        		}
        		// 保存最后一次搜索名称
        		$.tree._lastValue = value;
        		var nodes = $._tree.getNodes();
        		// 如果要查空字串，就退出不查了。
        		if (value == "") {
        		    $.tree.showAllNode(nodes);
        		    return;
        		}
        		$.tree.hideAllNode(nodes);
        		// 根据搜索值模糊匹配
        		$.tree.updateNodes($._tree.getNodesByParamFuzzy("name", value));
        	},
        	// 根据Id和Name选中指定节点
        	selectByIdName: function(treeId, treeName, node) {
        		if ($.common.isNotEmpty(treeName) && $.common.isNotEmpty(treeId)) {
        			if (treeId == node.id && treeName == node.name) {
            			$._tree.selectNode(node, true);
            		}
        		}
        	},
        	// 显示所有节点
        	showAllNode: function(nodes) {
        		nodes = $._tree.transformToArray(nodes);
        		for (var i = nodes.length - 1; i >= 0; i--) {
        		    if (nodes[i].getParentNode() != null) {
        		    	$._tree.expandNode(nodes[i], true, false, false, false);
        		    } else {
        		    	$._tree.expandNode(nodes[i], true, true, false, false);
        		    }
        		    $._tree.showNode(nodes[i]);
        		    $.tree.showAllNode(nodes[i].children);
        		}
        	},
        	// 隐藏所有节点
        	hideAllNode: function(nodes) {
        	    var tree = $.fn.zTree.getZTreeObj("tree");
        	    var nodes = $._tree.transformToArray(nodes);
        	    for (var i = nodes.length - 1; i >= 0; i--) {
        	    	$._tree.hideNode(nodes[i]);
        	    }
        	},
        	// 显示所有父节点
        	showParent: function(treeNode) {
        		var parentNode;
        		while ((parentNode = treeNode.getParentNode()) != null) {
        			$._tree.showNode(parentNode);
        			$._tree.expandNode(parentNode, true, false, false);
        		    treeNode = parentNode;
        		}
        	},
        	// 显示所有孩子节点
        	showChildren: function(treeNode) {
        		if (treeNode.isParent) {
        		    for (var idx in treeNode.children) {
        		        var node = treeNode.children[idx];
        		        $._tree.showNode(node);
        		        $.tree.showChildren(node);
        		    }
        		}
        	},
        	// 更新节点状态
        	updateNodes: function(nodeList) {
        		$._tree.showNodes(nodeList);
        		for (var i = 0, l = nodeList.length; i < l; i++) {
        		    var treeNode = nodeList[i];
        		    $.tree.showChildren(treeNode);
        		    $.tree.showParent(treeNode)
        		}
        	},
        	// 获取当前被勾选集合
        	getCheckedNodes: function(column) {
        		var _column = $.common.isEmpty(column) ? "id" : column;
        		var nodes = $._tree.getCheckedNodes(true);
        		return $.map(nodes, function (row) {
        	        return row[_column];
        	    }).join();
        	},
        	// 不允许根父节点选择
        	notAllowParents: function(_tree) {
    		    var nodes = _tree.getSelectedNodes();
    		    for (var i = 0; i < nodes.length; i++) {
    		        if (nodes[i].level == 0) {
    		            $.modal.msgError("不能选择根节点（" + nodes[i].name + "）");
    		            return false;
    		        }
    		        if (nodes[i].isParent) {
    		            $.modal.msgError("不能选择父节点（" + nodes[i].name + "）");
    		            return false;
    		        }
    		    }
        		return true;
        	},
        	// 不允许根节点选择，只有是根节点就不允许
        	notAllowRoot: function(_tree) {
    		    var nodes = _tree.getSelectedNodes();
    		    for (var i = 0; i < nodes.length; i++) {
    		        if (nodes[i].level == 0) {
    		            $.modal.msgError("不能选择根节点（" + nodes[i].name + "）");
    		            return false;
    		        }
    		    }
        		return true;
        	},
        	// 不允许根节点(租户)选择，但是允许非顶级资源的树根节点--主要是用于排除选择租户
        	notAllowTop: function(url, _tree) {
    		    var nodes = _tree.getSelectedNodes();
    		    for (var i = 0; i < nodes.length; i++) {
    		    	if (nodes[i].level == 0) {
    		    		var name = nodes[i].name;
    		    		url = url + nodes[i].id;
    		    		var rst = true;
    		    		$.ajaxSettings.async = false;
    		    		$.post(
    		    			url, 
			                function(data) {
			                    if (data.code == 'S' && data.result) {
			                    	rst = false;
			                    	$.modal.msgError("根节点（" + name + "）不能选择");
			                    }
			                }
    		    		);
    		    		if (rst == false) {
    		    			return rst;
    		    		}
    		    		$.ajaxSettings.async = true;
    		        }
    		    }
        		return true;
        	},
        	// 不允许最后层级节点选择
        	notAllowLastLevel: function(_tree) {
    		    var nodes = _tree.getSelectedNodes();
    		    for (var i = 0; i < nodes.length; i++) {
    		    	if (nodes[i].level == nodes.length + 1) {
    		    		$.modal.msgError("不能选择最后层级节点（" + nodes[i].name + "）");
    		            return false;
    		        }
    		    }
        		return true;
        	},
        	// 隐藏/显示搜索栏
        	toggleSearch: function() {
        		$('#search').slideToggle(200);
        		$('#btnShow').toggle();
        		$('#btnHide').toggle();
        		$('#keyword').focus();
        	},
        	// 折叠
        	collapse: function() {
        		$._tree.expandAll(false);
        	},
        	// 展开
        	expand: function() {
        		$._tree.expandAll(true);
        	}
        },
        // 通用方法封装处理
    	common: {
    		// 判断字符串是否为空
            isEmpty: function (value) {
                if (value == null || this.trim(value) == "") {
                    return true;
                }
                return false;
            },
            // 判断一个字符串是否为非空串
            isNotEmpty: function (value) {
            	return !$.common.isEmpty(value);
            },
            // 空对象转字符串
            nullToStr: function(value) {
                if ($.common.isEmpty(value)) {
                    return "-";
                }
                return value;
            },
            // 是否显示数据 为空默认为显示
            visible: function (value) {
                if ($.common.isEmpty(value) || value == true) {
                    return true;
                }
                return false;
            },
            // 空格截取
            trim: function (value) {
                if (value == null) {
                    return "";
                }
                return value.toString().replace(/(^\s*)|(\s*$)|\r|\n/g, "");
            },
            // 指定随机数返回
            random: function (min, max) {
                return Math.floor((Math.random() * max) + min);
            },
            startWith: function(value, start) {
                var reg = new RegExp("^" + start);
                return reg.test(value)
            },
            endWith: function(value, end) {
                var reg = new RegExp(end + "$");
                return reg.test(value)
            },
            convertUrl:function(url){
            	if(serverStore){
            		if(url.indexOf(serverStore.tokenName)>0){
            			return url
            		}
            		
            		if(serverStore.tokenName && serverStore.type=="page"){
            			var token = window.sessionStorage.getItem(serverStore.tokenName);
            			if(token){
            				if(url.indexOf("?")>0){
            					url += "&";
            				}else{
            					url += "?";
            				}
            				url += serverStore.tokenName + "=" + token;
            			}
            		}
            		
            		return url;
            	}
            }
        }
    });
    
    $.validator.addMethod('deptCode', function(value, element){
    	var regex = /^[0-9a-zA-Z\-_]{0,100}$/;
    	return this.optional(element) || regex.test(value);
    },'不可输入特殊字符和汉字');
    
})(jQuery);

/** 消息状态码 */
web_status = {
    SUCCESS: "S",
    FAIL: "F"
};

/** 弹窗状态码 */
modal_status = {
    SUCCESS: "success",
    FAIL: "error",
    WARNING: "warning"
};
$.validator.setDefaults({
    submitHandler: function(form) {
    	$.modal.loading($("#btnSubmit").data("loading"));
    	form.submit();
    }
});

function login() {
	$.modal.loading($("#btnSubmit").data("loading"));
}

$("#btnSubmit").click(function check() {
	validateRule();
});

$('.imgcode').click(function() {
	var url = ctx + "captcha/writeImage.htm?s=" + Math.random();
	$(".imgcode").attr("src", url);
});

function validateRule() {
	var icon = "<i class='fa fa-times-circle'></i> ";
	$("#signupForm").validate({
        rules: {
        	userName: {
                required: true,
                minlength: 2,
                maxlength: 20
            },
            passwd: {
            	required: true,
                minlength: 6,
                maxlength: 20
            },
            verifyCode: {
            	required: true,
                minlength: 1,
                maxlength: 20
        	}
        },
        messages: {
        	userName: {
                required: icon + "请输入您的用户名",
            },
            passwd: {
                required: icon + "请输入您的密码",
            },
            verifyCode: {
                required: icon + "请输入验证码",
            },
        }
    })
}

package com.huateng.union.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.support.TransactionTemplate;

@Configuration
@ImportResource(locations = {"classpath*:applicationContext.xml","classpath*:spring/spring-property.xml"})
@EnableTransactionManagement
public class DataSourceConfig {

	//,classpath*:spring/spring-property.xml
	@Bean
	public TransactionTemplate injectTransactionTemplate(PlatformTransactionManager platformTransactionManager) {
		TransactionTemplate template = new TransactionTemplate(platformTransactionManager);
		return template;
	}
}

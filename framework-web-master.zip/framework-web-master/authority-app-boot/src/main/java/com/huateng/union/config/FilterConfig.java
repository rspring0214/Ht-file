package com.huateng.union.config;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.huateng.base.logTrace.servlet.filter.TraceNoFilter;
import com.huateng.common.web.DetectServlet;
import com.huateng.common.web.HtmlEscapeFilter;
import com.huateng.common.web.MultiReadFilter;
import com.huateng.common.web.SqlEscapeFilter;
import com.huateng.user.web.filter.SSOFilter;

@Configuration
public class FilterConfig {

	@Bean
	public FilterRegistrationBean xssFilterRegistration()
	{
		FilterRegistrationBean registrationBean = new FilterRegistrationBean();
		MultiReadFilter filter = new MultiReadFilter();
		List<Pattern> patternList = new ArrayList<Pattern>();
		patternList.add(Pattern.compile(".*/upload.*"));
		filter.setConfigExclude(patternList);
		
		registrationBean.setFilter(filter);
		List<String> urlPatterns = new ArrayList<String>();
	    urlPatterns.add("*.do");
	    registrationBean.setUrlPatterns(urlPatterns);
	    registrationBean.setOrder(1);
		return registrationBean;
	}
	
	@Bean
	public FilterRegistrationBean htmlFilterRegistration()
	{
		FilterRegistrationBean registrationBean = new FilterRegistrationBean();
		HtmlEscapeFilter filter = new HtmlEscapeFilter();
		List<Pattern> patternList = new ArrayList<Pattern>();
		patternList.add(Pattern.compile(".*/upload.*"));
		filter.setConfigExclude(patternList);
		
		registrationBean.setFilter(filter);
		List<String> urlPatterns = new ArrayList<String>();
	    urlPatterns.add("*.do");
	    registrationBean.setUrlPatterns(urlPatterns);
	    registrationBean.setOrder(2);
		return registrationBean;
	}
	
	@Bean
	public FilterRegistrationBean sqlFilterRegistration()
	{
		FilterRegistrationBean registrationBean = new FilterRegistrationBean();
		SqlEscapeFilter filter = new SqlEscapeFilter();
		List<Pattern> patternList = new ArrayList<Pattern>();
		patternList.add(Pattern.compile(".*/upload.*"));
		filter.setConfigExclude(patternList);
		
		registrationBean.setFilter(filter);
		List<String> urlPatterns = new ArrayList<String>();
	    urlPatterns.add("*.do");
	    registrationBean.setUrlPatterns(urlPatterns);
	    registrationBean.setOrder(3);
		return registrationBean;
	}
	
	@Bean
	public FilterRegistrationBean logFilterRegistration()
	{
		FilterRegistrationBean registrationBean = new FilterRegistrationBean();
		TraceNoFilter filter = new TraceNoFilter();
		registrationBean.setFilter(filter);
		List<String> urlPatterns = new ArrayList<String>();
	    urlPatterns.add("*.do");
	    registrationBean.setUrlPatterns(urlPatterns);
	    registrationBean.setOrder(4);
		return registrationBean;
	}
	
	@Bean
	public FilterRegistrationBean ssoFilterRegistration(SSOFilter filter)
	{
		FilterRegistrationBean registrationBean = new FilterRegistrationBean();
		registrationBean.setFilter(filter);
		List<String> urlPatterns = new ArrayList<String>();
	    urlPatterns.add("*.do");
	    registrationBean.setUrlPatterns(urlPatterns);
	    registrationBean.setOrder(5);
		return registrationBean;
	}
	
	@Bean
	public ServletRegistrationBean healthCheckRegistration(){
		ServletRegistrationBean bean = new ServletRegistrationBean();
		bean.setServlet(new DetectServlet());
		List<String> urlPatterns = new ArrayList<String>();
	    urlPatterns.add("/_health_check.ttt");
	    bean.setUrlMappings(urlPatterns);
		return bean;
	}
}

package com.huateng.union.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/pre")
public class LoadFileTestController {

	@RequestMapping("testToolbox")
	@ResponseBody
	public Map<String , Object> findFile(HttpServletRequest request){
		Map<String , Object> result = new HashMap<String , Object>();
		try{
			String str = request.getServletContext().getRealPath("toolbox.xml");
			result.put("url", str);
			
			String str2 = request.getServletContext().getRealPath("/public/toolbox.xml");
			result.put("url2", str2);
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
}

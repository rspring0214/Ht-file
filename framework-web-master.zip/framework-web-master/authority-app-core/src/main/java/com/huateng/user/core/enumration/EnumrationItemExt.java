/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.enumration;

import com.huateng.base.enumration.model.EnumrationItem;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: EnumrationItemExt.java, v 0.1 2019年7月17日 上午10:33:17 Heaven.tang Exp $
 */
public class EnumrationItemExt extends EnumrationItem {

	private String listClass;

	public String getListClass() {
		return listClass;
	}

	public void setListClass(String listClass) {
		this.listClass = listClass;
	}
	
}

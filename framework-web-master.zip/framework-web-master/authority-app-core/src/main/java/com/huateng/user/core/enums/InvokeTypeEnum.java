/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.enums;

/**
 * Description:执行方式
 *
 * @author Heaven.tang
 * @version $Id: InvokeTypeEnum.java, v 0.1 2019年5月9日 下午3:45:33 Heaven.tang Exp $
 */
public enum InvokeTypeEnum {
	SYNC,ASYN
}

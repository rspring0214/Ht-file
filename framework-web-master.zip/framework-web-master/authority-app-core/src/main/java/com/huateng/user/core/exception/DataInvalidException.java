/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.exception;

import com.huateng.user.api.model.BaseException;

/**
 * Description:数据无效异常
 *
 * @author Heaven.tang
 * @version $Id: DataInvalidException.java, v 0.1 2019年4月9日 下午5:58:18 Heaven.tang Exp $
 */
public class DataInvalidException extends BaseException {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = -8321924741142142305L;

	/**
	 *
	 * @param message
	 */
	public DataInvalidException(String message) {
		super(message);
	}
	
	/**
	 *
	 * @param message
	 */
	public DataInvalidException(String code, String message) {
		super(message);
	}

}

/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.exception;

import com.huateng.user.api.model.BaseException;

/**
 * Description:数据不存在异常
 * 根据某些字段查询理论上应该能够查询到数据记录
 *
 * @author Heaven.tang
 * @version $Id: DataNotFoundException.java, v 0.1 2019年4月9日 下午5:58:18 Heaven.tang Exp $
 */
public class DataNotFoundException extends BaseException {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = -8321924741142142305L;

	/**
	 *
	 * @param message
	 */
	public DataNotFoundException(String message) {
		super(message);
	}

}

/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.exception;

import com.huateng.user.api.model.BaseException;

/**
 * Description:数据重复异常
 * 根据某些字段查询理论上应该唯一而查询到多条记录
 *
 * @author Heaven.tang
 * @version $Id: DuplicateDataException.java, v 0.1 2019年4月9日 下午5:58:18 Heaven.tang Exp $
 */
public class DuplicateDataException extends BaseException {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = 4640104018621724871L;

	/**
	 *
	 * @param message
	 */
	public DuplicateDataException(String message) {
		super(message);
	}

}

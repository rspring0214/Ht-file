/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.exception;

import com.huateng.user.api.model.BaseException;

/**
 * Description:参数不合法异常
 *
 * @author Heaven.tang
 * @version $Id: IllegalParamException.java, v 0.1 2019年4月3日 下午8:19:25 Heaven.tang Exp $
 */
public class IllegalParamException extends BaseException {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = 8652405922392817209L;

	public IllegalParamException(String message) {
		super(message);
	}

}

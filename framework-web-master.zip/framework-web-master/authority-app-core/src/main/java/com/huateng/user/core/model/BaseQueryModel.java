/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.model;

import java.io.Serializable;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: BaseQueryModel.java, v 0.1 2019年4月3日 下午7:08:23 Heaven.tang Exp $
 */
public class BaseQueryModel implements Serializable {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = -2828872610036010951L;
	
	/**
	 * 租户ID
	 */
	private String tenantId;

	/** 
	 * 开始时间
	 */
	private String beginTime;
	
	/**
	 * 结束时间
	 */
	private String endTime;

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

}

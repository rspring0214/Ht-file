package com.huateng.user.core.model;

/**
 * @author senvon
 *
 */
public abstract class Constants {

	/**
	 * ajax结构返回码
	 */
	public static final String API_RESPONSE_SUCCESS_CODE = "S";
	public static final String API_RESPONSE_FAIL_CODE = "F";
	public static final String API_RESPONSE_SUCCESS_MESSAGE = "成功";
	public static final String API_RESPONSE_FAIL_MESSAGE = "失败";
	
	// 正常
	public static final Integer COMMON_VALID = 1;
	// 禁用/锁定
	public static final Integer COMMON_INVALID = 2;
	// 逻辑删除
	public static final Integer COMMON_DELETED = 2;
	
	/**
	 * 资源类型
	 */
	// 目录
	public static final Integer MENU_TYPE_DIC = 1;
	// 菜单
	public static final Integer MENU_TYPE_MENU = 2;
	// 按钮
	public static final Integer MENU_TYPE_BUTTON = 3;
	
	// 初始化租户资源的顶级ID，不允许删除或修改
	public static final String MENU_TENANT_ID = "102";
	
	// 租户缓存key
	public static final String TENANT_CACHE_KEY = "ALL_TENANTS";
	
	/**
	 * Super 参数
	 */
	public static final String SUPER_USER_NAME = "admin";
	// 树结构的根ID
	public static final String ROOT_ID = "0";
	public static final String ROOT_CONTENT_NAME = "主目录";
	
	/**
     * 用户名长度限制
     */
    public static final int USERNAME_MIN_LENGTH = 2;
    public static final int USERNAME_MAX_LENGTH = 20;
    
    /**
     * 密码长度限制
     */
    public static final int PASSWORD_MIN_LENGTH = 6;
    public static final int PASSWORD_MAX_LENGTH = 20;
    /**
     * 密码检查提示
     */
    public static final String FIRST_LOGIN_REST_PASSWORD = "首次登录请修改密码";
    public static final String EXPIRE_REST_PASSWORD = "密码已过期，请修改密码";
	
	/**
	 * 固定参数名称
	 */
	public static final String DEL_FLAG = "delFlag";
	public static final String TIME_SCOPE_BEGIN = "beginTime";
	public static final String TIME_SCOPE_END = "endTime";
	
	public static final String REQUEST_SRC_CHAR_REGEX = "^[{][a-zA-Z]+[}]$";
	
	/**
	 * token存储类型
	 */
	public static final String COOKIE = "cookie";
	public static final String PAGE = "page";
	
}

/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.model;

/**
 * Description:异常信息常量，编码和信息并未作对应关系
 *
 * @author Heaven.tang
 * @version $Id: ExceptionConstants.java, v 0.1 2019年4月3日 下午8:28:17 Heaven.tang Exp $
 */
public abstract class ExceptionConstants {

	/** -------------------异常编码信息------------------- */
	/**
	 * 登录返回的明细编码：编码存在复用的情况
	 */
	// 数据不存在
	public static final String DATA_NOT_FOUND_EXCEPTION_CODE = "F001";
	// 数据无效：禁用/锁定
	public static final String LOGIN_CHECK_USER_DISABLED_CODE = "F002";
	// 查询到多个用户
	public static final String LOGIN_CHECK_USER_DUPLICATE_CODE = "F003";
	// 用户名不正确
	public static final String LOGIN_CHECK_USERNAME_ERROR_CODE = "F004";
	// 密码不匹配
	public static final String LOGIN_CHECK_PASSWORD_NOT_MATCH_CODE = "F010";
	
	
	/** -------------------异常描述信息------------------- */
	/**
	 * 未知异常
	 */
	public static final String UNKHNOWN_EXCEPTION_MESSAGE = "未知异常";
	
	/**
	 * 登录检查返回的信息
	 */
	// 登录检查不通过统一返回的模糊信息
	public static final String LOGIN_CHECK_FAILED_MESSAGE = "用户名或密码不正确";
	// 登录检查用户状态不正常
	public static final String LOGIN_CHECK_USER_NOT_CORRECT_MESSAGE = "用户不存在";
	// 用户被锁定
	public static final String LOGIN_CHECK_USER_LOCKED_MESSAGE = "用户已被禁用";
	
	/**
	 * 数据操作出错
	 */
	public static final String DATA_INSERT_EXCEPTION_MESSAGE = "新增失败";
	public static final String DATA_UPDATE_EXCEPTION_MESSAGE = "更新失败";
	public static final String DATA_DELETE_EXCEPTION_MESSAGE = "删除失败";
	
	/**
	 * 自定义枚举使用不正确
	 */
	public static final String ANNOTATION_USE_ERROR_EXCEPTION_MESSAGE = "枚举使用不正确";
	
	/**
	 * 超级管理员用户操作异常信息
	 */
	public static final String SUPER_USER_UPDATE_NOT_ALLOW_MESSAGE = "不允许修改超级管理员用户";
	public static final String SUPER_USER_DELETE_NOT_ALLOW_MESSAGE = "不允许删除超级管理员用户";
	
	/**
	 * 校验密码异常
	 */
	public static final String NULL_OLD_PASSWORD_EXCEPTION_MESSAGE = "原密码不能为空";
	public static final String OLD_PASSWORD_ERROR_EXCEPTION_MESSAGE = "原密码不正确";
	public static final String PASSWORD_VERIFY_EXCEPTION_MESSAGE = "原密码验证异常";
	public static final String NULL_NEW_PASSWORD_EXCEPTION_MESSAGE = "新密码不能为空";
	public static final String NEW_PASSWORD_NOT_EQUALS_EXCEPTION_MESSAGE = "新密码两次输入不一致";
	public static final String NEW_SAME_AS_PASSWORD_EXCEPTION_MESSAGE = "新密码不能与原密码相同";
	
	public static final String USER_PASSWORD_NOT_MATCH_EXCEPTION_MESSAGE = "用户名或密码不正确";
	public static final String USER_NOT_EXISTS_EXCEPTION_MESSAGE = "用户不存在";
	
	public static final String AGENT_NOT_EXISTS_EXCEPTION_MESSAGE = "组织机构不存在";
}

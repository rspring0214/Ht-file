package com.huateng.user.core.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.huateng.user.api.model.SSOUser;

/**
 * 全局存储的用户缓存,该缓存主要控制一个用户,可以在一个设备上登录几次 是否要对之前的token进行剔除操作
 * 
 * 对登录用户,存储一个大的key,存储结构如下 key=_USER_ssoUser.tenantCode+ssoUser.userName
 * tokenMap:{ ,"PC":[{token1,time1},{token2,time2}]
 * ,"MOBLIE":[{token3,time3},{token4,time4}]
 * 
 * @author senvon
 *
 */
public class GlobalUserModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Map<String, List<String>> tokenMap = new HashMap<String, List<String>>();

	private String userName;
	private String tenantCode;

	public GlobalUserModel() {
		super();
	}

	public GlobalUserModel(SSOUser ssoUser) {
		this.userName = ssoUser.getUserName();
		this.tenantCode = ssoUser.getTenantCode();
	}

	public Map<String, List<String>> getTokenMap() {
		return tokenMap;
	}

	public void setTokenMap(Map<String, List<String>> tokenMap) {
		this.tokenMap = tokenMap;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getTenantCode() {
		return tenantCode;
	}

	public void setTenantCode(String tenantCode) {
		this.tenantCode = tenantCode;
	}

	/**
	 * 登录的时候,增加token
	 * 
	 * @param token
	 * @param deviceType
	 */
	public void addToken(String token, String deviceType) {
		List<String> tokenList = tokenMap.get(deviceType);
		if (tokenList == null) {
			tokenList = new ArrayList<String>(10);
		}
		if (!tokenList.contains(token)) {
			tokenList.add(token);
			tokenMap.put(deviceType, tokenList);
		}
	}

	public void removeToken(String token, String deviceType) {
		List<String> tokenList = tokenMap.get(deviceType);
		if (tokenList != null) {
			if (tokenList.contains(token)) {
				tokenList.remove(token);
				if (!tokenList.isEmpty()) {
					tokenMap.put(deviceType, tokenList);
				} else {
					tokenMap.remove(deviceType);
				}
			}
		}
	}

	/**
	 * 判断当前设备中的token数量是否小雨规定的数量 大于等于,返回false 小于,返回true
	 * 
	 * @param deviceType
	 * @param count
	 * @return
	 */
	public boolean tokenOverCount(String deviceType, Integer count) {
		if (count > 0) {
			if (tokenMap.containsKey(deviceType)) {
				return tokenMap.get(deviceType).size() < count;
			}
		}
		return true;
	}

	/**
	 * 判断一个token,在某一种登录设备下是否存在
	 * 
	 * @param token
	 * @param deviceType
	 * @return
	 */
	public boolean tokenExist(String token, String deviceType) {
		List<String> tokenSet = tokenMap.get(deviceType);
		if (tokenSet != null) {
			return tokenSet.contains(token);
		}
		return false;
	}

	/**
	 * 移除一个设备的token,因为存储使用map,移除操作将会随机完成
	 * 如果要支持移除最早登录的token,可以使用snowflake算法,随机生成增长的token,在内存排序移除
	 * 
	 * @param deviceType
	 * @return 返回被干掉的token
	 */
	public String removeOldestToken(String deviceType) {
		List<String> tokenList = tokenMap.get(deviceType);
		String token = tokenList.get(0);
		tokenList.remove(0);
		tokenMap.put(deviceType, tokenList);
		return token;
	}

	/**
	 * 随机删除一个设备里面的token
	 * 
	 * @param deviceType
	 * @return 返回被干掉的token
	 */
	public void removeRandomToken(String deviceType) {
		List<String> tokenList = tokenMap.get(deviceType);
		tokenList.remove(0);
		tokenMap.put(deviceType, tokenList);
	}

	/**
	 * 在当前的用户全局缓存里面,得到某个登录设备的登录次数
	 * 
	 * @param deviceType
	 * @return
	 */
	public Integer findLoginTime(String deviceType) {
		List<String> tokenSet = tokenMap.get(deviceType);
		if (tokenSet != null) {
			return tokenSet.size();
		}
		return 0;
	}

}

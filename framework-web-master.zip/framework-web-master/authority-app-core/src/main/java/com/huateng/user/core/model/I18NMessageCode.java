/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.model;

/**
 * Description:i18n国际化配置编号映射
 *
 * @author Heaven.tang
 * @version $Id: I18NMessageCode.java, v 0.1 2019年5月10日 下午2:27:25 Heaven.tang Exp $
 */
public final class I18NMessageCode {

	/**
	 * parameter check
	 */
	public static final String NOT_NULL = "not.null";
	public static final String PARAMETER_NOT_NULL = "parameter.not.null";
	public static final String PARAMETER_NOT_CORRECT = "parameter.not.correct";
	
	/**
	 * login
	 */
	public static final String USER_LOGIN_SUCCESS = "user.login.success";
	public static final String USER_NOTFOUND = "user.notfound";
	public static final String USER_FORCELOGOUT = "user.forcelogout";
	public static final String USER_LOGOUT_SUCCESS = "user.logout.success";
	
	/**
	 * data check
	 */
	public static final String AGENT_NOT_EXISTS = "agent.not.exists";
	public static final String USER_JCAPTCHA_ERROR = "user.jcaptcha.error";
	public static final String USER_NOT_EXISTS = "user.not.exists";
	public static final String USER_PASSWORD_NOT_MATCH = "user.password.not.match";
	public static final String USER_PASSWORD_DELETE = "user.password.delete";
	public static final String USER_BLOCKED = "user.blocked";
	public static final String ROLE_BLOCKED = "role.blocked";
	
	/**
	 * limit
	 */
	public static final String USER_PASSWORD_RETRY_LIMIT_COUNT = "user.password.retry.limit.count";
	public static final String USER_PASSWORD_RETRY_LIMIT_EXCEED = "user.password.retry.limit.exceed";
	
	/**
	 * not valid
	 */
	public static final String LENGTH_NOT_VALID = "length.not.valid";
	public static final String USER_USERNAME_NOT_VALID = "user_username.not.valid";
	public static final String USER_PASSWORD_NOT_VALID = "user.password.not.valid";
	public static final String USER_EMAIL_NOT_VALID = "user.email.not.valid";
	public static final String USER_MOBILE_PHONE_NUMBER_NOT_VALID = "user.mobile.phone.number.not.valid";
	public static final String USER_UNKNOWN_ERROR = "user.unknown.error";
	
	/**
	 * no permission
	 */
	public static final String NO_PERMISSION = "no.permission";
	public static final String NO_CREATE_PERMISSION = "no.create.permission";
	public static final String NO_UPDATE_PERMISSION = "no.update.permission";
	public static final String NO_DELETE_PERMISSION = "no.delete.permission";
	public static final String NO_EXPORT_PERMISSION = "no.export.permission";
	public static final String NO_VIEW_PERMISSION = "no.view.permission";
	
}

package com.huateng.user.core.model;

/**
 * 登录模型 主要用于收集登录页面的输入信息
 * 
 * @author senvon
 *
 */
public class LoginModel {

	/**
	 * 页面输入的用户名
	 */
	private String userName;
	/**
	 * 页面输入的密码
	 */
	private String passwd;
	/**
	 * 页面输入的租户编号
	 */
	private String tenantCode;
	/**
	 * 页面输入的验证码
	 */
	private String verifyCode;

	/**
	 * 页面传递的fromUrl
	 */
	private String fromUrl;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public String getTenantCode() {
		return tenantCode;
	}

	public void setTenantCode(String tenantCode) {
		this.tenantCode = tenantCode;
	}

	public String getVerifyCode() {
		return verifyCode;
	}

	public void setVerifyCode(String verifyCode) {
		this.verifyCode = verifyCode;
	}

	public String getFromUrl() {
		return fromUrl;
	}

	public void setFromUrl(String fromUrl) {
		this.fromUrl = fromUrl;
	}
}

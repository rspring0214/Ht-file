package com.huateng.user.core.model.dictInfo;

import java.util.ArrayList;
import java.util.List;

import com.huateng.user.dal.model.DictDataInfo;
import com.huateng.user.dal.model.DictTypeInfo;

public class DictTypeData extends DictTypeInfo{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<DictDataInfo> dataList = new ArrayList<DictDataInfo>();

	public List<DictDataInfo> getDataList() {
		return dataList;
	}

	public void setDataList(List<DictDataInfo> dataList) {
		this.dataList = dataList;
	}
	
}

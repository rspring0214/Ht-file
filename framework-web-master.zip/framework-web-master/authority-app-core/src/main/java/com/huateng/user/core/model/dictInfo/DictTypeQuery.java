package com.huateng.user.core.model.dictInfo;

public class DictTypeQuery {

	private String dictType;
	private String dictName;
	private Integer status;
	private String beignTime;
	private String endTime;
	public String getDictType() {
		return dictType;
	}
	public void setDictType(String dictType) {
		this.dictType = dictType;
	}
	public String getDictName() {
		return dictName;
	}
	public void setDictName(String dictName) {
		this.dictName = dictName;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getBeignTime() {
		return beignTime;
	}
	public void setBeignTime(String beignTime) {
		this.beignTime = beignTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
}

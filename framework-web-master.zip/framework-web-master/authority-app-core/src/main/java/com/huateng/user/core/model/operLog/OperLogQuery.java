package com.huateng.user.core.model.operLog;

import com.huateng.user.core.model.BaseQueryModel;

public class OperLogQuery extends BaseQueryModel {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = -8073825223846463755L;
	
	private String title;
	private String operMethod;
	private String operName;
	private String operRemark;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getOperMethod() {
		return operMethod;
	}
	public void setOperMethod(String operMethod) {
		this.operMethod = operMethod;
	}
	public String getOperName() {
		return operName;
	}
	public void setOperName(String operName) {
		this.operName = operName;
	}
	public String getOperRemark() {
		return operRemark;
	}
	public void setOperRemark(String operRemark) {
		this.operRemark = operRemark;
	}
	
}

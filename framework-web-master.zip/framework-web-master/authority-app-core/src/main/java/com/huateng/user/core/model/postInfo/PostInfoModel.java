/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.model.postInfo;

import com.huateng.user.dal.model.PostInfo;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: PostInfoModel.java, v 0.1 2019年4月4日 下午8:15:41 Heaven.tang Exp $
 */
public class PostInfoModel extends PostInfo {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = 8032519400452870898L;

	/** 
	 * 用户是否存在此岗位标识 默认不存在
	 */
    private boolean flag = false;

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}
    
}

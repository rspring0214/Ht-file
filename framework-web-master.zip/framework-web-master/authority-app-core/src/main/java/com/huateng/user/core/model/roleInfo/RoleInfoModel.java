/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.model.roleInfo;

import com.huateng.user.dal.model.RoleInfo;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: RoleInfoModel.java, v 0.1 2019年4月3日 下午7:07:40 Heaven.tang Exp $
 */
public class RoleInfoModel extends RoleInfo {

    /**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = -6631511015159014587L;

	/** 
     * 用户是否存在此角色标识 默认不存在
     */
    private boolean flag = false;

    /** 
     * 菜单组
     */
    private String[] menuIds;

    /** 
     * 组织机构组（数据权限）
     */
    private String[] deptIds;

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public String[] getMenuIds() {
		return menuIds;
	}

	public void setMenuIds(String[] menuIds) {
		this.menuIds = menuIds;
	}

	public String[] getDeptIds() {
		return deptIds;
	}

	public void setDeptIds(String[] deptIds) {
		this.deptIds = deptIds;
	}

}

/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.model.roleInfo;

import com.huateng.user.core.model.BaseQueryModel;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: RoleInfoQueryModel.java, v 0.1 2019年4月9日 上午10:10:42 Heaven.tang Exp $
 */
public class RoleInfoQueryModel extends BaseQueryModel {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = -8281636261741062089L;

	/**
     * 角色名称
     */
    private String roleName;

    /**
     * 角色权限字符串
     */
    private String roleKey;
    
    /**
     * 数据范围
     */
    private Integer dataScope;

    /**
     * 角色状态:1正常,2禁用
     */
    private Integer status;

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleKey() {
		return roleKey;
	}

	public void setRoleKey(String roleKey) {
		this.roleKey = roleKey;
	}

	public Integer getDataScope() {
		return dataScope;
	}

	public void setDataScope(Integer dataScope) {
		this.dataScope = dataScope;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
    
}

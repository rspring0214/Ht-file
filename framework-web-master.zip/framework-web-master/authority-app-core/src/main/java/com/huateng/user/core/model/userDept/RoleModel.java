/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.model.userDept;

import java.io.Serializable;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: RoleModel.java, v 0.1 2019年8月6日 上午11:06:22 Heaven.tang Exp $
 */
public class RoleModel implements Serializable {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = -1653731701799194127L;

	private String id;
	
	private String roleName;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
}

/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.model.userDept;

import com.huateng.user.dal.model.ext.ExtUserDeptInfo;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: UserDeptQueryModel.java, v 0.1 2019年8月6日 上午11:45:25 Heaven.tang Exp $
 */
public class UserDeptQueryModel extends ExtUserDeptInfo {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = -2607100602949815468L;

}

/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.model.userDept;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;

import com.huateng.user.api.model.UserRole;
import com.huateng.user.dal.model.ext.ExtUserDeptInfo;

/**
 * Description:多机构下的用户、机构与角色关联对象
 *
 * @author Heaven.tang
 * @version $Id: UserDeptRole.java, v 0.1 2019年8月6日 上午10:54:01 Heaven.tang Exp $
 */
public class UserDeptRole implements Serializable {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = 4270675940022184274L;

	private String deptId;
	private String userName;
	private String deptName;
	
	private ExtUserDeptInfo userDept;
	
	private List<UserRole> roles;
	
	public ExtUserDeptInfo getUserDept() {
		return userDept;
	}

	public void setUserDept(ExtUserDeptInfo userDept) {
		this.userDept = userDept;
	}

	public List<UserRole> getRoles() {
		return CollectionUtils.isNotEmpty(roles) ? roles : new ArrayList<UserRole>();
	}

	public void setRoles(List<UserRole> roles) {
		this.roles = roles;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

}

/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.model.userDept;

/**
 * Description:用户机构角色绑定请求对象（委任时的数据请求对象）
 *
 * @author Heaven.tang
 * @version $Id: UserDeptRoleBinding.java, v 0.1 2019年8月9日 下午4:35:09 Heaven.tang Exp $
 */
public class UserDeptRoleBinding {

	private String userId;
	
	private String deptId;
	
	private String[] roleIds;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String[] getRoleIds() {
		return roleIds;
	}

	public void setRoleIds(String[] roleIds) {
		this.roleIds = roleIds;
	}

}

/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.model.userInfo;

import com.huateng.user.core.model.BaseQueryModel;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: UserInfoQueryModel.java, v 0.1 2019年4月4日 下午2:57:11 Heaven.tang Exp $
 */
public class UserInfoQueryModel extends BaseQueryModel {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = -7479997071678712794L;

	/**
	 * 登录名
	 */
	private String loginName;
	
	/**
	 * 用户名
	 */
	private String userName;
	
	/**
	 * 状态
	 */
	private Integer status;
	
	/**
	 * 电话号码
	 */
	private String phoneNumber;
	
	/**
	 * 选择条件，多选deptIds
	 */
	private String deptIds;
	/**
	 * 所属组织机构编号
	 */
	private String deptId;
	
	/**
	 * 所属机构名称
	 */
	private String deptName;

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getDeptIds() {
		return deptIds;
	}

	public void setDeptIds(String deptIds) {
		this.deptIds = deptIds;
	}

}

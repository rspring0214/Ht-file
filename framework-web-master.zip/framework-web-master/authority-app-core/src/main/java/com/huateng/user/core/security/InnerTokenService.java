package com.huateng.user.core.security;

import com.huateng.user.api.model.SSOUser;
import com.huateng.user.api.service.TokenService;
import com.huateng.user.core.model.GlobalUserModel;

/**
 * 内部的tokenService
 * @author senvon
 *
 */
public interface InnerTokenService extends TokenService {

	/**生成一个token,并存储
	 * @param ssoUser
	 * @return
	 */
	public String generateToken(SSOUser ssoUser);
	
	/**保存token的存储模型
	 * @param tokenModel
	 */
	public void saveTokenModel(SSOUser ssoUser);
	
	/**将当前token设置为失效
	 * 退出是调用,确保存储里面的token及和token相关的数据失效
	 * @param token
	 */
	public void invalidToken(String token);
	
	/**得到一个全局的用户缓存
	 * @param ssoUser
	 * @return
	 */
	public GlobalUserModel findUserModel(String userName , String tenantNo);
	
}

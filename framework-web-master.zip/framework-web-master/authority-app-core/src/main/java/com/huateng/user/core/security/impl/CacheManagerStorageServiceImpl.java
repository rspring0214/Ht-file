package com.huateng.user.core.security.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import com.huateng.base.cache.CacheManager;
import com.huateng.common.utils.PropertyLoader;
import com.huateng.user.api.service.StorageService;

public class CacheManagerStorageServiceImpl implements StorageService {

	@Autowired
	private CacheManager cacheManager;

	/**
	 * 存储结构 token:[key1,key2] 用于表示,当前的token,一共存储了多少key的缓存
	 */
	private Map<String, Set<String>> keyMap = new ConcurrentHashMap<String, Set<String>>();

	public Map<String, Set<String>> getKeyMap() {
		return keyMap;
	}

	private void putKey(String token, String key) {
		Set<String> keySet = keyMap.get(token);
		if (keySet == null) {
			keySet = new HashSet<String>();
		}
		keySet.add(key);
		if (!keyMap.containsKey(token)) {
			keyMap.put(token, keySet);
		}
	}

	private void removeKey(String token, String key) {
		Set<String> keySet = keyMap.get(token);
		if (keySet != null) {
			keySet.remove(key);
			if (keySet.isEmpty()) {
				keyMap.remove(token);
			}
		}
	}

	@Override
	public <T> T getObject(String token, String key, Class<T> clazz) {
		/*Object obj = cacheManager.getObj(token + key);
		if (obj == null) {
			return null;
		}
		return JSON.parseObject((String) obj, clazz);*/
		return getObject(token , key, clazz , Long.parseLong(PropertyLoader.getInstance().getProperty("sso.token.expire.time", "1800")));
	}
	
	@Override
	public <T> T getObject(String token, String key, Class<T> clazz, Long expireSecond) {
		/*Object obj = cacheManager.getAndTouch(token + key, expireSecond);
		if (obj == null) {
			return null;
		}
		return JSON.parseObject((String) obj, clazz);*/
		return (T)cacheManager.getAndTouch(token + key, clazz , expireSecond);
	}

	/**
	 * 限于memcached只支持字符存储，需要做转换
	 */
	@Override
	public void putObject(String token, String key, Object obj) {
		putObject(token, key, obj, Long.parseLong(PropertyLoader.getInstance().getProperty("sso.token.expire.time", "1800")));
	}

	@Override
	public void putObject(String token, String key, Object obj, Long expireSecond) {
		if (StringUtils.isNotBlank(token)) {
			putKey(token, key);
		}
//		String jsonStr = JSON.toJSONString(obj);
		cacheManager.putObj(token + key, obj, expireSecond);
	}

	@Override
	public void removeObject(String token, String key) {
		if (StringUtils.isNotBlank(token)) {
			removeKey(token, key);
		}
		cacheManager.removeObj(token + key);
	}

	@Override
	public void removeAll(String token) {
		if (StringUtils.isNotBlank(token)) {
			Set<String> keySet = keyMap.get(token);
			if (CollectionUtils.isEmpty(keySet)) {
				return;
			}
			List<String> keyList = new ArrayList<String>(keySet);
			if (keyList != null && !keyList.isEmpty()) {
				for (String key : keyList) {
					removeObject(token, key);
				}
			}
		}
	}

}

/**
 * 
 */
package com.huateng.user.core.security.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.huateng.common.utils.PropertyLoader;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.api.service.StorageService;
import com.huateng.user.core.model.GlobalUserModel;
import com.huateng.user.core.security.InnerTokenService;
import com.huateng.user.core.service.AsycRecordService;

/**
 * @author senvon
 *
 */
@Repository
public class InnerTokenServiceImpl implements InnerTokenService {

	private static final Logger logger = LoggerFactory.getLogger(InnerTokenServiceImpl.class);
	
	@Autowired
	private StorageService storageService;
	
	@Autowired
	private AsycRecordService asycRecord;

	@Value("${sso.token.over.strategy:'forbidden'}")
	private String overStrategy = "forbidden";

	@Value("${sso.token.expire.time:1800}")
	private Long tokenExpire;

	// 60 * 60 * 24 * 30
	@Value("${sso.global.expire.time:2592000}")
	private Long globalExpire;

	public void setStorageService(StorageService storageService) {
		this.storageService = storageService;
	}

	/**
	 * 得到一个全局的用户缓存
	 * 
	 * @param ssoUser
	 * @return
	 */
	public GlobalUserModel findUserModel(String userName, String tenantNo) {
		String globalUserKey = SSOClientUtils.KEY_SSO_USER + tenantNo + userName;
		return storageService.getObject("", globalUserKey, GlobalUserModel.class , globalExpire);
	}
	
	/**
	 * 得到一个全局的用户缓存
	 * 
	 * @param ssoUser
	 * @return
	 */
	public GlobalUserModel findUserModel(String userName, String tenantNo, Long expireTime) {
		String globalUserKey = SSOClientUtils.KEY_SSO_USER + tenantNo + userName;
		return storageService.getObject("", globalUserKey, GlobalUserModel.class, expireTime);
	}

	/**
	 * 保存一个全局的用户缓存
	 * 
	 * @param userModel
	 */
	public void saveGlobalUserModel(GlobalUserModel userModel) {
		String globalUserKey = SSOClientUtils.KEY_SSO_USER + userModel.getTenantCode() + userModel.getUserName();
		storageService.putObject("", globalUserKey, userModel, globalExpire);
	}

	@Override
	public SSOUser verify(String token) {
		// token验证得到ssoUser不一定代表验证成功,还需要判断globalUserModel中是否存在该token
		// web用户只要在操作，就应该更新失效时间，只有用户开着页面一直没有操作直到超过有效时间才会自动退出
//		String tokenKey = SSOClientUtils.KEY_TOKEN + token;
//		SSOUser ssoUser = storageService.getObject(token, tokenKey, SSOUser.class, tokenExpire);
		SSOUser ssoUser = findTokenModel(token);
		boolean tokenExist = false;
		if (ssoUser != null) {
			GlobalUserModel globalUser = findUserModel(ssoUser.getUserName(), ssoUser.getTenantCode(), tokenExpire);
			tokenExist = globalUser.tokenExist(token, ssoUser.getDeviceType());
		}
		if (tokenExist) {
			return ssoUser;
		} else {
			logger.debug("SSOUser not found, token : {}", token);
			// 在校验token的过程中对缓存做清除操作,利国利民,神不知鬼不觉
			if (ssoUser != null) {
				invalidGlobalToken(ssoUser.getUserName(), ssoUser.getTenantCode());
			}
		}
		return null;
	}

	public String generateToken(SSOUser userInfo) {
		String token = RandomStringUtils.randomAlphanumeric(20);

		// 操作globalUser的cache部分
		GlobalUserModel globalUser = findUserModel(userInfo.getUserName(), userInfo.getTenantCode());

		if (globalUser == null) {
			globalUser = new GlobalUserModel(userInfo);
		}

		// 先对globalusermodel里面的token进行验证和删除
		// 不做删除会导致当前的登录失败
		String count = PropertyLoader.getInstance().getProperty(userInfo.getDeviceType() + ".count", "-1");
		if (userInfo != null) {
			invalidGlobalToken(userInfo.getUserName(), userInfo.getTenantCode());
		}
		if (!globalUser.tokenOverCount(userInfo.getDeviceType(), Integer.parseInt(count))) {
			if (overStrategy.equalsIgnoreCase("old")) {
				String removedToken = globalUser.removeOldestToken(userInfo.getDeviceType());
				invalidToken(removedToken);
			}
		}

		globalUser.addToken(token, userInfo.getDeviceType());
		saveGlobalUserModel(globalUser);

		// 操作token的cache部分
		userInfo.setLoginTime(new Date());
		userInfo.setToken(token);
		saveTokenModel(userInfo);
		// 这边应该通知用户上线
		return token;
	}

	public SSOUser findTokenModel(String token) {
		String tokenKey = SSOClientUtils.KEY_TOKEN + token;
		return storageService.getObject(token, tokenKey, SSOUser.class , tokenExpire);
	}

	public void saveTokenModel(SSOUser ssoUser) {
		if (ssoUser != null) {
			String tokenKey = SSOClientUtils.KEY_TOKEN + ssoUser.getToken();
			storageService.putObject(ssoUser.getToken(), tokenKey, ssoUser, tokenExpire);
		}
	}

	/**
	 * 当前设计的存储逻辑,只有GlobalUserModel中的token会出现缓存并发问题引发的用户的缓存删除不掉的情况
	 * 适当的时候,对缓存做一些校验操作,删除一些无效的token,有利于统计和限制登录次数
	 * 
	 * @param ssoUser
	 */
	public void invalidGlobalToken(String userName, String tenantNo) {
		GlobalUserModel globalUserModel = findUserModel(userName, tenantNo);
		if (globalUserModel != null) {
			Map<String, List<String>> map = new HashMap<String, List<String>>();
			for (Entry<String, List<String>> entry : globalUserModel.getTokenMap().entrySet()) {
				List<String> tokenSet = entry.getValue();
				List<String> targetSet = new ArrayList<String>(10);
				for (String tokenModel : tokenSet) {
					SSOUser tokenUserModel = findTokenModel(tokenModel);
					if (tokenUserModel != null) {
						targetSet.add(tokenModel);
					}
				}
				map.put(entry.getKey(), targetSet);
			}
			globalUserModel.setTokenMap(map);
			saveGlobalUserModel(globalUserModel);
		}
	}

	@Override
	public void invalidToken(String token) {
//		String tokenKey = SSOClientUtils.KEY_TOKEN + token;
		// 检查token是否有ticket,token失效需要连带ticket失效
		SSOUser tokenUserModel = findTokenModel(token);
		if (tokenUserModel != null) {
			// 移除GlobalUser里面的对应的token信息
			GlobalUserModel globalUserModel = findUserModel(tokenUserModel.getUserName(),
					tokenUserModel.getTenantCode());
			if (globalUserModel != null) {
				globalUserModel.removeToken(token, tokenUserModel.getDeviceType());
			}

			// 删除所有使用SSOClientUtil新增的和token相关的缓存
			storageService.removeAll(token);
			SSOClientUtils.getInstance().remove(token);
			// 用户下线
			asycRecord.userOnlineRemove(new String[] { token });
		}
	}
}

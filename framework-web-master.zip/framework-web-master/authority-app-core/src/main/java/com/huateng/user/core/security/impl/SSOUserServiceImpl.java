package com.huateng.user.core.security.impl;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.constants.ExceptionConstants;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.api.model.UserDept;
import com.huateng.user.api.service.SSOUserService;
import com.huateng.user.api.utils.UserUtils;
import com.huateng.user.core.exception.DataInvalidException;
import com.huateng.user.core.service.DeptInfoService;
import com.huateng.user.core.service.UserInfoService;
import com.huateng.user.core.util.MD5Utils;
import com.huateng.user.dal.model.DeptInfo;
import com.huateng.user.dal.model.UserInfo;

public class SSOUserServiceImpl implements SSOUserService {

	private static final Logger logger = LoggerFactory.getLogger(SSOUserServiceImpl.class);
	
	@Autowired
	private UserInfoService userInfoService;
	
	@Autowired
	private DeptInfoService deptInfoService;
	
	@Override
	//通过传入的登录参数,校验用户的密码,默认实现是查询数据库
	public ApiBaseResponse<SSOUser> checkPasswd(String tenantCode, String userName, String password) {
		List<UserInfo> userList = userInfoService.selectUserByKeyCode(tenantCode, userName);
		
		if (CollectionUtils.isEmpty(userList)) {
			logger.warn("user not exists, tenantCode : {}, userName : {}", tenantCode, userName);
        	return new ApiBaseResponse<SSOUser>(ExceptionConstants.DATA_NOT_FOUND_EXCEPTION_CODE, RetStatusEnum.FAIL, ExceptionConstants.LOGIN_CHECK_FAILED_MESSAGE);
		}
		
		if (userList.size() > 1) {
			logger.warn("expect 1 but found " + userList.size() + " user info, tenantCode : {}, userName : {}", tenantCode, userName);
			return new ApiBaseResponse<SSOUser>(ExceptionConstants.LOGIN_CHECK_USER_DUPLICATE_CODE, RetStatusEnum.FAIL, ExceptionConstants.LOGIN_CHECK_FAILED_MESSAGE);
		}
		
//		statusValidate(userList.get(0));
		
		return verify(tenantCode, userName, password, userList.get(0));
//		return check(tenantCode, userName, password, userList.get(0));
	}

	/*private ApiBaseResponse<SSOUser> check(String tenantCode, String userName, String password, UserInfo user) {
		try {
			statusValidate(user);
		} catch (DataInvalidException e) {
			return new ApiBaseResponse<SSOUser>(e.getCode(), RetStatusEnum.FAIL, e.getMessage());
		}
		
		return verify(tenantCode, userName, password, user);
	}*/

	private ApiBaseResponse<SSOUser> verify(String tenantCode, String userName, String password, UserInfo user) {
		
		// 检查用户状态
		userStatusCheck(user);
		// 检查组织机构状态
//		deptStatusCheck(user.getLoginName(), user.getDeptId());
		
		String key = userName + password;
		if (StringUtils.isNotBlank(user.getSalt())) {
			key = key + user.getSalt();
		}
		boolean correct = MD5Utils.verifySaltMD5(key, user.getPassword());
		correct = true;
		if (correct) {
			
			DeptInfo dept = null;
			if(!UserUtils.isAdmin(user.getLoginName())){
				dept = deptInfoService.selectDeptById(user.getDeptId());
				if (null == dept) {
					logger.warn("user dept invalid, userName : {}", userName);
					throw new DataInvalidException(ExceptionConstants.LOGIN_CHECK_USER_DISABLED_CODE, ExceptionConstants.AGENT_NOT_EXISTS_EXCEPTION_MESSAGE);
				}
				if (!Constants.COMMON_VALID.equals(dept.getStatus())) {
					logger.warn("user dept invalid, deptName : {}, userName : {}", dept.getDeptName(), userName);
					throw new DataInvalidException(ExceptionConstants.LOGIN_CHECK_USER_DISABLED_CODE, ExceptionConstants.AGENT_NOT_EXISTS_EXCEPTION_MESSAGE);
				}
				int count = deptInfoService.countInvalidDeptListByIds(Arrays.asList(dept.getAncestors().split(",")));
				if (count > 0) {
					logger.warn("user ancestors dept invalid, userName : {}", userName);
					throw new DataInvalidException(ExceptionConstants.LOGIN_CHECK_USER_DISABLED_CODE, ExceptionConstants.AGENT_NOT_EXISTS_EXCEPTION_MESSAGE);
				}
			}
			
			SSOUser ssoUser = loadSSOUser(tenantCode, user , dept);
			return new ApiBaseResponse<SSOUser>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, ssoUser);
		}
		return new ApiBaseResponse<SSOUser>(ExceptionConstants.LOGIN_CHECK_PASSWORD_NOT_MATCH_CODE, RetStatusEnum.FAIL, ExceptionConstants.LOGIN_CHECK_FAILED_MESSAGE);
	}

	/*private void statusValidate(UserInfo user) {
		
	}*/

	/*private void deptStatusCheck(String userName, String deptId) {
		
	}*/

	private void userStatusCheck(UserInfo user) {
		if (Constants.COMMON_INVALID.equals(user.getStatus())) {
			logger.warn("user is disabled, id : {}", user.getId());
			throw new DataInvalidException(ExceptionConstants.LOGIN_CHECK_USER_DISABLED_CODE, ExceptionConstants.LOGIN_CHECK_USER_LOCKED_MESSAGE);
		}
	}

	/**
	 * 获取数据源中的基本信息，其他信息应该是在返回认证通过后由调用方自行在各自数据源查询
	 * 
	 * @param user
	 * @return
	 */
	private SSOUser loadSSOUser(String tenantCode, UserInfo user , DeptInfo dept) {
		SSOUser ssoUser = new SSOUser();
		ssoUser.setUserId(user.getId());
		ssoUser.setLoginName(user.getLoginName());
		ssoUser.setUserName(user.getUserName());
		ssoUser.setTenantId(user.getTenantId());
		ssoUser.setTenantCode(tenantCode);
		ssoUser.setLoginTime(new Date());
		if (!UserUtils.isAdmin(user.getLoginName()) && dept!= null) {
			UserDept belongDept = new UserDept();
			belongDept.setId(dept.getId());
			belongDept.setDeptCode(dept.getDeptCode());
			belongDept.setDeptName(dept.getDeptName());
			belongDept.setTenantCode(dept.getTenantCode());
			belongDept.setTenantId(dept.getTenantId());
			ssoUser.setBelongDept(belongDept);
		}else{
			ssoUser.setBelongDept( new UserDept());
		}
		return ssoUser;
	}

}

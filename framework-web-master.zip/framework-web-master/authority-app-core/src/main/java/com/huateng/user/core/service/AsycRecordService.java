/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.service;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Repository;

import com.huateng.user.api.model.SSOUser;
import com.huateng.user.dal.model.LoginInfo;
import com.huateng.user.dal.model.OperLogInfo;
import com.huateng.user.dal.model.UserOnlineInfo;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: AsycRecordService.java, v 0.1 2019年7月11日 上午10:02:36 Heaven.tang Exp $
 */
@Repository
public class AsycRecordService {

	private static final Logger logger = LoggerFactory.getLogger(AsycRecordService.class);
	
	@Resource(name = "asycRecordExecutor")
	private ThreadPoolTaskExecutor executor;

	@Autowired
	private UserOnlineInfoService userOnlineInfoService;
	
	@Autowired
	private LoginInfoService loginInfoService;
	
	@Autowired
	private OperLogInfoService operLogInfoService;

	public void loginRecord(final LoginInfo login) {
		if (executor != null) {
			executor.submit(new Runnable() {

				@Override
				public void run() {
					try {
						loginInfoService.saveLoginfor(login);
					} catch (Exception e) {
						logger.info("addLoginfor exception ", e);
					}

				}

			});
		}
	}

	public void operatorRecord(final OperLogInfo operLog) {
		if (executor != null) {
			executor.submit(new Runnable() {

				@Override
				public void run() {

					try {
						operLogInfoService.addOperLog(operLog);
					} catch (Exception e) {
						logger.info("addOperLog exception ", e);
					}
				}

			});
		}
	}

	public void userOnlineRecord(final UserOnlineInfo userOnline) {
		if (executor != null) {
			executor.submit(new Runnable() {

				@Override
				public void run() {
					try {
						userOnlineInfoService.saveUserOnlineInfo(userOnline);
					} catch (Exception e) {
						logger.info("saveUserOnlineInfo exception ", e);
					}

				}

			});
		}
	}
	
	public void updateOnlineAccessTime(final String sessionId){
		if (executor != null) {
			executor.submit(new Runnable() {

				@Override
				public void run() {
					try {
						userOnlineInfoService.updateAccessTimeBySessionId(sessionId);
					} catch (Exception e) {
						logger.info("saveUserOnlineInfo exception ", e);
					}

				}

			});
		}
	}

	public void userOnlineRemove(final String... tokenArray) {
		if (executor != null) {
			executor.submit(new Runnable() {
				@Override
				public void run() {
					try {
						userOnlineInfoService.remveUserOnlineInfo(tokenArray);
					} catch (Exception e) {
						logger.info("remveUserOnlineInfo exception ", e);
					}

				}

			});
		}
	}
	
	public void updateLoginLog(SSOUser user) {
		/*LoginInfo loginInfo = new LoginInfo();
		loginInfo.setSessionId(user.getToken());
		loginInfo.setTenantId(StringUtils.isNotBlank(user.getTenantId()) ? user.getTenantId() : "");
		loginInfo.setDeptId(user.getLoginDept().getId());
		loginInfo.setDeptName(user.getLoginDept().getDeptName());
		loginRecord(loginInfo);*/
		UserOnlineInfo onlineInfo = new UserOnlineInfo();
		onlineInfo.setSessionId(user.getToken());
		onlineInfo.setDeptId(user.getLoginDept().getId());
		onlineInfo.setDeptName(user.getLoginDept().getDeptName());
		userOnlineRecord(onlineInfo);
	}
}

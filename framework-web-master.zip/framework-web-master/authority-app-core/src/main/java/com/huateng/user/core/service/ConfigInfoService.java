package com.huateng.user.core.service;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import com.huateng.base.cache.DeleteCache;
import com.huateng.base.cache.UseCache;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.dal.dao.ConfigInfoMapper;
import com.huateng.user.dal.model.ConfigInfo;
import com.huateng.user.dal.model.ConfigInfoExample;

@Repository("ConfigInfoService")
public class ConfigInfoService {

	@Autowired
	private ConfigInfoMapper configInfoMapper;
	
	public List<ConfigInfo> findConfigInfo(ConfigInfo configInfo , PageInfo<ConfigInfo> page){
		ConfigInfoExample example = new ConfigInfoExample();
		ConfigInfoExample.Criteria criteria = example.createCriteria();
		
		if (configInfo != null) {
			if(StringUtils.isNotBlank(configInfo.getConfigKey())) {
				criteria.andConfigKeyLike("%" + configInfo.getConfigKey() + "%");
			}
			
			if(StringUtils.isNotBlank(configInfo.getConfigName())) {
				criteria.andConfigNameLike("%" + configInfo.getConfigName() + "%");
			}
		}
		
		example.setOrderByClause(" CREATE_TIME DESC");
		
		return configInfoMapper.selectByExample(example, page);
	}
	
	public ConfigInfo findById(String id) {
		return configInfoMapper.selectByPrimaryKey(id);
	}
	
	@UseCache(key = "'CONFIG_'+#key")
	public ConfigInfo findByKey(String key){
		ConfigInfoExample example = new ConfigInfoExample();
		ConfigInfoExample.Criteria criteria = example.createCriteria();
		criteria.andConfigKeyEqualTo(key);
		
		List<ConfigInfo> configList = configInfoMapper.selectByExample(example);
		if(configList != null && configList.size()>0){
			return configList.get(0);
		}
		return null;
	}
	
	@DeleteCache(key = "'CONFIG_'+#configInfo.configKey")
	public void saveConfigInfo(ConfigInfo configInfo) {
		if(configInfo != null) {
			if(StringUtils.isNotBlank(configInfo.getId())) {
				configInfo.setUpdateTime(new Date());
				configInfo.setUpdateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
				configInfoMapper.updateByPrimaryKeySelective(configInfo);
			}else {
				configInfo.setCreateTime(new Date());
				configInfo.setCreateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
				configInfo.setUpdateBy(configInfo.getCreateBy());
				configInfoMapper.insertSelective(configInfo);
			}
		}
	}
	
	public boolean checkConfigKeyUnique(String id , String configKey){
		ConfigInfoExample example = new ConfigInfoExample();
		ConfigInfoExample.Criteria criteria = example.createCriteria();
		
		criteria.andIdNotEqualTo(id);
		criteria.andConfigKeyEqualTo(configKey);
		
		return configInfoMapper.countByExample(example) == 0;
	}
	
	/**
	 * 删除配置
	 * 
	 * @param ids
	 */
	public int deleteConfigByIds(List<String> ids) {
		Assert.notEmpty(ids, "ID 不能为空");
		if (ids.size() == 1) {
			return configInfoMapper.deleteByPrimaryKey(ids.get(0));
		} else {
			ConfigInfoExample example = new ConfigInfoExample();
			example.createCriteria().andIdIn(ids);
			return configInfoMapper.deleteByExample(example);
		}
	}
}

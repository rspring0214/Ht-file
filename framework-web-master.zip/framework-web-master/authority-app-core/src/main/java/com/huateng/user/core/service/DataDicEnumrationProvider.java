package com.huateng.user.core.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.huateng.base.cache.UseCache;
import com.huateng.base.enumration.EnumrationProvider;
import com.huateng.base.enumration.model.EnumrationItem;
import com.huateng.user.core.enumration.EnumrationItemExt;
import com.huateng.user.dal.dao.DictDataInfoMapper;
import com.huateng.user.dal.model.DictDataInfo;
import com.huateng.user.dal.model.DictDataInfoExample;

@Repository("DataDicEnumrationProvider")
public class DataDicEnumrationProvider implements EnumrationProvider {

	@Autowired
	private DictDataInfoMapper mapper;

	@Override
	@UseCache(key = "#type", expireTime = 60 * 60 * 24)
	public List<EnumrationItem> findEnumByType(String type) {
		DictDataInfoExample example = new DictDataInfoExample();
		DictDataInfoExample.Criteria criteria = example.createCriteria();
		criteria.andDictTypeEqualTo(type);
		example.setOrderByClause(" DICT_SORT ASC, CREATE_TIME ASC");
		List<DictDataInfo> dictDataList = mapper.selectByExample(example);
		if (dictDataList != null && dictDataList.size()>0) {
			List<EnumrationItem> result = new ArrayList<EnumrationItem>(10);
			for (DictDataInfo dataInfo : dictDataList) {
				EnumrationItemExt item = new EnumrationItemExt();
				item.setCode(dataInfo.getDictCode());
				item.setText(dataInfo.getDictLabel());
				item.setValue(dataInfo.getDictValue());
				item.setListClass(dataInfo.getListClass());
				result.add(item);
			}
			return result;
		}
		return null;
	}

}

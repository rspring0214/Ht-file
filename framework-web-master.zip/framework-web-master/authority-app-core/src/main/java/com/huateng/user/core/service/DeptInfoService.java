/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.enums.YesOrNoEnum;
import com.huateng.user.api.model.BaseException;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.api.utils.UserUtils;
import com.huateng.user.core.util.Assembler;
import com.huateng.user.core.util.ExampleCriteriaUtils;
import com.huateng.user.dal.dao.DeptInfoMapper;
import com.huateng.user.dal.dao.TenantInfoMapper;
import com.huateng.user.dal.dao.UserInfoMapper;
import com.huateng.user.dal.dao.ext.ExtDeptInfoMapper;
import com.huateng.user.dal.model.DeptInfo;
import com.huateng.user.dal.model.DeptInfoExample;
import com.huateng.user.dal.model.RoleInfo;
import com.huateng.user.dal.model.TenantInfo;
import com.huateng.user.dal.model.TenantInfoExample;
import com.huateng.user.dal.model.UserInfoExample;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: DeptInfoService.java, v 0.1 2019年4月3日 下午12:17:34 Heaven.tang Exp $
 */
@Repository
@Transactional
public class DeptInfoService {

	@Autowired
	private DeptInfoMapper deptInfoMapper;
	
	@Autowired
	private ExtDeptInfoMapper extDeptInfoMapper;
	
	@Autowired
	private TenantInfoMapper tenantInfoMapper;
	
	@Autowired
	private UserInfoMapper userInfoMapper;
	
	@Autowired
	private TenantInfoService tenantService;
	
	@Value("${multiple.corporate:false}")
	private boolean multipleCorporate;
	
	/**
	 * 根据条件查询组织机构信息
	 * 
	 * @param deptInfo
	 * @return
	 */
	public List<DeptInfo> search(DeptInfo deptInfo) {
		
		// 根据条件筛选
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		
		DeptInfoExample example = new DeptInfoExample();
		DeptInfoExample.Criteria criteria = example.createCriteria();
		
		ExampleCriteriaUtils.criteriaEqualsSet(criteria, deptInfo, "deptName");
		if (StringUtils.isNotBlank(deptInfo.getDeptName())) {
			criteria.andDeptNameLike("%" + deptInfo.getDeptName() + "%");
		}
		
		List<String> ids = new ArrayList<String>();
		
		if(UserUtils.isAdmin(user)){
		
		} else {
			getAncestorId(user.getLoginDept().getId(), ids);
			getChildrenId(Arrays.asList(new String[]{user.getLoginDept().getId()}), ids);
			criteria.andIdIn(ids);
		}
		example.setOrderByClause(" ORDER_NUM ASC, CREATE_TIME ASC");
		List<DeptInfo> list = deptInfoMapper.selectByExample(example);
		if(org.apache.commons.collections4.CollectionUtils.isEmpty(list)){
			return list;
		}
		// ---------------------------------------------------------------
		DeptInfoExample example2 = new DeptInfoExample();
		DeptInfoExample.Criteria criteria2 = example2.createCriteria();
		
		List<String> idsFinal = new ArrayList<String>();
		List<String> ids2 = new ArrayList<String>();
		
		for(DeptInfo t1 : list){
			idsFinal.add(t1.getId());
		}
		
		getAncestorIds(idsFinal, ids2);
//		getChildrenId(idsFinal, ids2);
		if(org.apache.commons.collections4.CollectionUtils.isNotEmpty(ids2)){
			criteria2.andIdIn(ids2);
		}
		List<DeptInfo> list2 = deptInfoMapper.selectByExample(example2);
		
		return list2;
	}
	
	/**
	 * 插入组织机构信息
	 * 
	 * @param deptInfo
	 * @return
	 */
	public int insertDept(DeptInfo deptInfo) {
		
		deptInfo.setCreateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
		
		String parentId = deptInfo.getParentId();
		
		TenantInfo tenantInfo = null;
		
		DeptInfo pDeptInfo = selectDeptById(parentId);
		
		if(pDeptInfo == null){
			tenantInfo = tenantService.selectByPrimaryKey(parentId);
			deptInfo.setParentId("0");
		} else {
			tenantInfo = tenantService.selectByPrimaryKey(pDeptInfo.getTenantId());
		} 
		
		// TENANT_ID,TENANT_CODE
		deptInfo.setTenantId(tenantInfo.getId());
		deptInfo.setTenantCode(tenantInfo.getTenantCode());
		deptInfo.setStatus(Constants.COMMON_VALID);
		deptInfo.setDelFlag(Integer.valueOf(YesOrNoEnum.YES.getCode()));
		
		deptInfo.setCreateTime(new Date());
		int rows = deptInfoMapper.insertSelective(deptInfo);
		
		// ANCESTORS,ANCESTORS_CODES
		String ancestors = pDeptInfo == null ? deptInfo.getId() : pDeptInfo.getAncestors() + "," + deptInfo.getId();
		String ancestorsCodes = pDeptInfo == null ? deptInfo.getDeptCode() : pDeptInfo.getAncestorsCodes() + "," + deptInfo.getDeptCode();
		deptInfo.setAncestors(ancestors);
		deptInfo.setAncestorsCodes(ancestorsCodes);
		
		deptInfoMapper.updateByPrimaryKeySelective(deptInfo);
		
		return rows;
	}

	private String getAncestorsOfParent(DeptInfo dept) {
		DeptInfo parent = deptInfoMapper.selectByPrimaryKey(dept.getParentId());
		if (parent == null) {
			TenantInfo tenant = tenantInfoMapper.selectByPrimaryKey(dept.getParentId());
			if (tenant == null) {
				return "";
			}
			if (Constants.COMMON_INVALID == tenant.getStatus()) {
				throw new BaseException("租户已停用，禁止操作");
			}
			return "0";
		}
		
		if (StringUtils.equals(YesOrNoEnum.NO.getCode(), parent.getStatus().toString())) {
			throw new BaseException("组织机构已停用，禁止操作");
		}
		return parent.getAncestors();
	}
	
	/**
	 * 更新组织机构信息
	 * 
	 * @param menu
	 * @return
	 */
	public int updateDept(DeptInfo dept) {
		

		DeptInfo info = deptInfoMapper.selectByPrimaryKey(dept.getParentId());
		if (null != info) {
			dept.setAncestorsCodes(info.getAncestorsCodes() + "," + dept.getDeptCode());
			
//			String ancestors = info.getAncestors() + "," + info.getId();
//			dept.setAncestors(ancestors);
//			updateDeptChildren(dept.getId(), ancestors);
		}  else {
			dept.setAncestorsCodes(dept.getDeptCode());
		}
		updateChildrenAncestorCodes(dept);
		
		dept.setUpdateTime(new Date());
		int result = deptInfoMapper.updateByPrimaryKeySelective(dept);
		
		if (StringUtils.equals(YesOrNoEnum.YES.getCode(), dept.getStatus().toString())) {
			// 如果该组织机构是启用状态，则启用该组织机构的所有上级组织机构
			updateParentDeptStatus(dept);
		}
		
		return result;
	}
	
	private void updateChildrenAncestorCodes(DeptInfo dept){
		
		DeptInfoExample example = new DeptInfoExample();
		example.createCriteria().andParentIdEqualTo(dept.getId());
		List<DeptInfo> childs = deptInfoMapper.selectByExample(example);
		
		for(DeptInfo tmp : childs){
			tmp.setAncestorsCodes(dept.getAncestorsCodes() + "," + tmp.getDeptCode());
			deptInfoMapper.updateByPrimaryKeySelective(tmp);
			updateChildrenAncestorCodes(tmp);
		}
	}
	

	/**
	 * 修改子组织机构关系
	 * 
	 * @param deptId
	 * @param ancestors
	 */
	private void updateDeptChildren(String deptId, String ancestors) {
		DeptInfoExample example = new DeptInfoExample();
		example.createCriteria().andParentIdEqualTo(deptId);
		List<DeptInfo> childrens = deptInfoMapper.selectByExample(example);
		for (DeptInfo children : childrens) {
			children.setAncestors(ancestors + "," + deptId);
		}
		if (childrens.size() > 0) {
			extDeptInfoMapper.updateDeptChildren(childrens);
		}
	}
	
	private void updateParentDeptStatus(DeptInfo dept) {
		DeptInfo record = new DeptInfo();
		record.setStatus(dept.getStatus());
		record.setUpdateBy(dept.getUpdateBy());
		record.setUpdateTime(new Date());
		DeptInfoExample example = new DeptInfoExample();
		if (StringUtils.isNotBlank(dept.getAncestors())) {
			example.createCriteria().andIdIn(Arrays.asList(dept.getAncestors().split(",")));
		}
		deptInfoMapper.updateByExampleSelective(record, example);
	}

	/**
	 * 统计子组织机构数量
	 * 
	 * @param parentId
	 * @return
	 */
	public int countDeptByParentId(String parentId) {
		DeptInfoExample example = new DeptInfoExample();
		example.createCriteria().andParentIdEqualTo(parentId).andStatusEqualTo(Constants.COMMON_VALID);
		return deptInfoMapper.countByExample(example);
	}

	/**
	 * 统计组织机构下用户数量
	 * 
	 * @param deptId
	 * @return
	 */
	public int countUsersByDeptId(String deptId) {
		UserInfoExample example = new UserInfoExample();
		example.createCriteria().andDeptIdEqualTo(deptId).andStatusEqualTo(Constants.COMMON_VALID);
		return userInfoMapper.countByExample(example);
	}

	/**
	 * 根据组织机构ID删除组织机构信息
	 * 
	 * @param id
	 * @return
	 */
	public int deleteDeptById(String id) {
		// 并不实际删除数据，只是将标识更改为无效
		DeptInfo dept = new DeptInfo();
		dept.setId(id);
		dept.setStatus(Integer.valueOf(YesOrNoEnum.NO.getCode()));
		dept.setUpdateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
		dept.setUpdateTime(new Date());
		return deptInfoMapper.updateByPrimaryKeySelective(dept);
	}

	/**
	 * 检查组织机构名称是否唯一
	 * 
	 * @param deptInfo
	 * @return
	 */
	public Boolean checkDeptNameUnique(DeptInfo deptInfo) {
		DeptInfoExample example = new DeptInfoExample();
		DeptInfoExample.Criteria criteria = example.createCriteria();
//		criteria.andParentIdEqualTo(deptInfo.getParentId());
		criteria.andDeptNameEqualTo(deptInfo.getDeptName());
		if (StringUtils.isNotBlank(deptInfo.getId())) {
			criteria.andIdNotEqualTo(deptInfo.getId());
		}
		return deptInfoMapper.countByExample(example) == 0;
	}
	/**
	 * 检查组织机构名称是否唯一
	 * 
	 * @param deptInfo
	 * @return
	 */
	public Boolean checkDeptCodeUnique(DeptInfo deptInfo) {
		DeptInfoExample example = new DeptInfoExample();
		DeptInfoExample.Criteria criteria = example.createCriteria();
//		criteria.andParentIdEqualTo(deptInfo.getParentId());
		criteria.andDeptCodeEqualTo(deptInfo.getDeptCode());
		if (StringUtils.isNotBlank(deptInfo.getId())) {
			criteria.andIdNotEqualTo(deptInfo.getId());
		}
		return deptInfoMapper.countByExample(example) == 0;
	}

	/**
	 * 查询组织机构树
	 * 
	 * @param ancestorId 父类组织机构ID
	 * @param tenantId 租户ID
	 * @return
	 */
	public List<Map<String, Object>> deptTreeData(String ancestorId, String tenantId, boolean tenantSupport) {
		DeptInfoExample example = new DeptInfoExample();
		DeptInfoExample.Criteria criteria = example.createCriteria();
		List<DeptInfo> deptList = new ArrayList<DeptInfo>(10);
		if (StringUtils.isNotBlank(ancestorId)) {
//			deptList.add(deptInfoMapper.selectByPrimaryKey(ancestorId));
			criteria.andAncestorsLike("%" + ancestorId + "%");
		}
		if (StringUtils.isBlank(tenantId)) {
			if (tenantSupport) {
				List<TenantInfo> tenants = tenantService.selectTenants(Constants.COMMON_VALID);
				for (TenantInfo tenant : tenants) {
					deptList.add(Assembler.buildDeptInfo(tenant));
				}
			}
		} else {
			criteria.andTenantIdEqualTo(tenantId);
		}
		example.setOrderByClause(" ORDER_NUM ASC, CREATE_TIME ASC");
		List<DeptInfo> list = deptInfoMapper.selectByExample(example);
		if (!CollectionUtils.isEmpty(list)) {
			deptList.addAll(list);
		}
		return getTrees(deptList, false, null);
	}
	
	/**
	 * 查询组织机构树
	 * 
	 * @param ancestorId 父类组织机构ID
	 * @param tenantId 租户ID
	 * @return
	 */
	public List<Map<String, Object>> deptTreeData4DeptNew(String ancestorId, String tenantId, boolean tenantSupport) {
		
		
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		
		List<DeptInfo> deptList = new ArrayList<DeptInfo>(10);
		
		
		List<TenantInfo> tenants = new ArrayList<TenantInfo>();
		
		
		DeptInfoExample example = new DeptInfoExample();
		DeptInfoExample.Criteria criteria = example.createCriteria();
		if (StringUtils.isBlank(tenantId)) {
//			if (tenantSupport) {
				tenants = tenantService.selectTenants(Constants.COMMON_VALID);
				for (TenantInfo tenant : tenants) {
					deptList.add(Assembler.buildDeptInfo(tenant));
				}
//			}
		} else {
			criteria.andTenantIdEqualTo(tenantId);
		}
		
		if(!UserUtils.isAdmin(user)){
			List<String> ids = new ArrayList<String>();
			getAncestorId(user.getLoginDept().getId(), ids);
			getChildrenId(Arrays.asList(new String[]{user.getLoginDept().getId()}), ids);
			criteria.andIdIn(ids);
		}
		
		example.setOrderByClause(" ORDER_NUM ASC, CREATE_TIME ASC");
		List<DeptInfo> list = deptInfoMapper.selectByExample(example);
		

		for(DeptInfo dept : list){
			if(dept.getParentId().equals("0")){
				for(TenantInfo tenant : tenants){
					if(dept.getTenantId().equals(tenant.getId())){
						dept.setParentId(dept.getTenantId());
						break;
					}
				}
			}
		}
		
		if (!CollectionUtils.isEmpty(list)) {
			deptList.addAll(list);
		}
		
		
//		boolean isCheck = false;
//		List<String> roleDeptList = null;
		
		List<Map<String, Object>> trees = new ArrayList<Map<String, Object>>(10);
		List<String> ids = new ArrayList<String>(10);
		for (DeptInfo dept : deptList) {
			//if (StringUtils.equals(YesOrNoEnum.YES.getCode(), dept.getStatus().toString())) {
				Map<String, Object> deptMap = new HashMap<String, Object>();
				ids.add(dept.getId());
				deptMap.put("id", dept.getId());
				deptMap.put("pId", dept.getParentId());
				deptMap.put("name", dept.getDeptName());
				deptMap.put("title", dept.getDeptName());
//				if (isCheck) {
//					deptMap.put("checked", roleDeptList.contains(dept.getId() + dept.getDeptName()));
//				} else {
					deptMap.put("checked", false);
//				}
				trees.add(deptMap);
			//}
		}
		for (Map<String, Object> map : trees) {
			if (!ids.contains(map.get("pId"))) {
				map.put("pId", Constants.ROOT_ID);
			}
		}
		return trees;
		
	}
	
	/**
	 * 查询组织机构树
	 * 
	 * @param ancestorId 父类组织机构ID
	 * @param tenantId 租户ID
	 * @return
	 */
	public List<Map<String, Object>> deptTree4UserQuery(String ancestorId, String tenantId, boolean tenantSupport) {
		
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		
		DeptInfoExample example = new DeptInfoExample();
		DeptInfoExample.Criteria criteria = example.createCriteria();
		List<DeptInfo> deptList = new ArrayList<DeptInfo>(10);
		
		List<TenantInfo> tenants = new ArrayList<TenantInfo>();
		
		if (StringUtils.isBlank(tenantId)) {
			if (tenantSupport) {
				tenants = tenantService.selectTenants(Constants.COMMON_VALID);
				for (TenantInfo tenant : tenants) {
					deptList.add(Assembler.buildDeptInfo(tenant));
				}
			}
		} else {
			criteria.andTenantIdEqualTo(tenantId);
		}
		
		if(!UserUtils.isAdmin(user)){
			List<String> ids = new ArrayList<String>();
//			getAncestorId(user.getBelongDept().getId(), ids);
			getChildrenId(Arrays.asList(new String[]{user.getLoginDept().getId()}), ids);
			ids.add(user.getLoginDept().getId());
			criteria.andIdIn(ids);
		}
		example.setOrderByClause(" ORDER_NUM ASC, CREATE_TIME ASC");
		List<DeptInfo> list = deptInfoMapper.selectByExample(example);
		

		for(DeptInfo dept : list){
			if(dept.getParentId().equals("0")){
				for(TenantInfo tenant : tenants){
					if(dept.getTenantId().equals(tenant.getId())){
						dept.setParentId(dept.getTenantId());
//						break;
					}
				}
			}
		}
		
		if (!CollectionUtils.isEmpty(list)) {
			deptList.addAll(list);
		}
//		boolean isCheck = false;
//		List<String> roleDeptList = null;
		
		List<Map<String, Object>> trees = new ArrayList<Map<String, Object>>(10);
		List<String> ids = new ArrayList<String>(10);
		for (DeptInfo dept : deptList) {
//			if (StringUtils.equals(YesOrNoEnum.YES.getCode(), dept.getStatus().toString())) {
				Map<String, Object> deptMap = new HashMap<String, Object>();
				ids.add(dept.getId());
				deptMap.put("id", dept.getId());
				deptMap.put("pId", dept.getParentId());
				deptMap.put("name", dept.getDeptName());
				deptMap.put("title", dept.getDeptName());
//				if (isCheck) {
//					deptMap.put("checked", roleDeptList.contains(dept.getId() + dept.getDeptName()));
//				} else {
					deptMap.put("checked", false);
//				}
				trees.add(deptMap);
//			}
		}
		for (Map<String, Object> map : trees) {
			if (!ids.contains(map.get("pId"))) {
				map.put("pId", Constants.ROOT_ID);
			}
		}
		return trees;
	}
	
	/**
	 * 查询组织机构树
	 * 
	 * @param ancestorId 父类组织机构ID
	 * @param tenantId 租户ID
	 * @return
	 */
	public List<Map<String, Object>> deptTreeData4UserNew(String ancestorId, String tenantId, boolean tenantSupport) {
		
		
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		
		List<DeptInfo> deptList = new ArrayList<DeptInfo>(10);
		
		
		List<TenantInfo> tenants = new ArrayList<TenantInfo>();
		
		
		DeptInfoExample example = new DeptInfoExample();
		DeptInfoExample.Criteria criteria = example.createCriteria();
		if (StringUtils.isBlank(tenantId)) {
			if (tenantSupport) {
				tenants = tenantService.selectTenants(Constants.COMMON_VALID);
				for (TenantInfo tenant : tenants) {
					deptList.add(Assembler.buildDeptInfo(tenant));
				}
			}
		} else {
			criteria.andTenantIdEqualTo(tenantId);
		}
		
		if(!UserUtils.isAdmin(user)){
			List<String> ids = new ArrayList<String>();
			getAncestorId(user.getLoginDept().getId(), ids);
			getChildrenId(Arrays.asList(new String[]{user.getLoginDept().getId()}), ids);
			criteria.andIdIn(ids);
		}
		
		example.setOrderByClause(" ORDER_NUM ASC, CREATE_TIME ASC");
		List<DeptInfo> list = deptInfoMapper.selectByExample(example);
		

		for(DeptInfo dept : list){
			if(dept.getParentId().equals("0")){
				for(TenantInfo tenant : tenants){
					if(dept.getTenantId().equals(tenant.getId())){
						dept.setParentId(dept.getTenantId());
						break;
					}
				}
			}
		}
		
		if (!CollectionUtils.isEmpty(list)) {
			deptList.addAll(list);
		}
		
		
		boolean isCheck = false;
		List<String> roleDeptList = null;
		
		List<Map<String, Object>> trees = new ArrayList<Map<String, Object>>(10);
		List<String> ids = new ArrayList<String>(10);
		for (DeptInfo dept : deptList) {
			//if (StringUtils.equals(YesOrNoEnum.YES.getCode(), dept.getStatus().toString())) {
				Map<String, Object> deptMap = new HashMap<String, Object>();
				ids.add(dept.getId());
				deptMap.put("id", dept.getId());
				deptMap.put("pId", dept.getParentId());
				deptMap.put("name", dept.getDeptName());
				deptMap.put("title", dept.getDeptName());
				if (isCheck) {
					deptMap.put("checked", roleDeptList.contains(dept.getId() + dept.getDeptName()));
				} else {
					deptMap.put("checked", false);
				}
				trees.add(deptMap);
			//}
		}
		/*for (Map<String, Object> map : trees) {
			if (!ids.contains(map.get("pId"))) {
				map.put("pId", Constants.ROOT_ID);
			}
		}*/
		return trees;
		
	}
	
	/**
	 * 对象转组织机构树
	 *
	 * @param deptList 组织机构列表
	 * @param isCheck 是否需要选中
	 * @param roleDeptList 角色已存在菜单列表
	 * @return
	 */
	public List<Map<String, Object>> getTrees(List<DeptInfo> deptList, boolean isCheck, List<String> roleDeptList) {
		List<Map<String, Object>> trees = new ArrayList<Map<String, Object>>(10);
		List<String> ids = new ArrayList<String>(10);
		for (DeptInfo dept : deptList) {
			if (StringUtils.equals(YesOrNoEnum.YES.getCode(), dept.getStatus().toString())) {
				Map<String, Object> deptMap = new HashMap<String, Object>();
				ids.add(dept.getId());
				deptMap.put("id", dept.getId());
				deptMap.put("pId", dept.getParentId());
				deptMap.put("name", dept.getDeptName());
				deptMap.put("title", dept.getDeptName());
				if (isCheck) {
					deptMap.put("checked", roleDeptList.contains(dept.getId() + dept.getDeptName()));
				} else {
					deptMap.put("checked", false);
				}
				trees.add(deptMap);
			}
		}
		for (Map<String, Object> map : trees) {
			if (!ids.contains(map.get("pId"))) {
				map.put("pId", Constants.ROOT_ID);
			}
		}
		return trees;
	}

	/**
	 * 根据角色ID查询组织机构（数据权限）
	 *
	 * @param role 角色对象
	 * @return 组织机构列表（数据权限）
	 */
	public List<Map<String, Object>> roleDeptTreeData(RoleInfo role) {
		String roleId = role.getId();
		/**
		 * 角色和租户不关联
		String tenantId = role.getTenantId();
		if (StringUtils.isBlank(tenantId)) {
			RoleInfo roleInfo = roleInfoMapper.selectByPrimaryKey(roleId);
			if (null != roleInfo) {
				tenantId = roleInfo.getTenantId();
			}
		}
		*/
		List<Map<String, Object>> trees = new ArrayList<Map<String, Object>>();
		List<DeptInfo> deptList = selectDeptList();
		if (StringUtils.isNotBlank(roleId)) {
			List<String> roleDeptList = extDeptInfoMapper.selectRoleDeptTree(roleId);
			trees = getTrees(deptList, true, roleDeptList);
		} else {
			trees = getTrees(deptList, false, null);
		}
		return trees;
	}

	/**
	 * 查询树结构需要的组织机构数据集合
	 * 
	 * @param deptInfo
	 * @return
	 */
	public List<DeptInfo> selectDeptTreeList(DeptInfo deptInfo) {
		List<DeptInfo> result = new ArrayList<DeptInfo>(10);
		
		// 一旦加入了查询条件就只能反馈出符合条件的数据及其祖先以组成完整的树数据
		boolean filter = false;
		if (StringUtils.isNotBlank(deptInfo.getDeptName()) || null != deptInfo.getStatus()) {
			filter = true;
		}
		
		result.addAll(queryAndAssemble(deptInfo));
		
		// 这里只区分不同租户下的机构数据，如果需要更精准的区分，需要在这里继续实现
		if (filter) {
			filter(result);
		}
		
		return result;
	}

	private List<DeptInfo> queryAndAssemble(DeptInfo deptInfo) {
		
		supplyQuery(deptInfo);
		
		List<DeptInfo> result = extDeptInfoMapper.selectDeptTree(deptInfo);
		
		// 额外添加租户（租户与组织机构分开了）
		addTenants(result, deptInfo);
		
		return result;
	}

	private void addTenants(List<DeptInfo> result, DeptInfo deptInfo) {
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		if (!UserUtils.isAdmin(user)) {
			return;
		}
		// 根据找到的机构查询租户
		queryTenants(result);
		// 查询条件是否只能命中租户数据
		queryTenants(result, deptInfo);
	}

	private void queryTenants(List<DeptInfo> result, DeptInfo deptInfo) {
		TenantInfoExample example = new TenantInfoExample();
		TenantInfoExample.Criteria criteria = example.createCriteria();
		if (StringUtils.isNotBlank(deptInfo.getDeptName())) {
			criteria.andTenantNameLike("%" + deptInfo.getDeptName() + "%");
		}
		if (null != deptInfo.getStatus()) {
			criteria.andStatusEqualTo(deptInfo.getStatus());
		}
		List<TenantInfo> tenants = tenantInfoMapper.selectByExample(example);
		if (!CollectionUtils.isEmpty(tenants)) {
			for (TenantInfo tenantInfo : tenants) {
				result.add(Assembler.buildDeptInfo(tenantInfo));
			}
		}
	}

	private void queryTenants(List<DeptInfo> result) {
		Set<String> ids = new HashSet<String>();
		TenantInfoExample example = null;
		for (DeptInfo dept : result) {
			ids.add(dept.getTenantId());
			if (ids.size() >= 1000) {
				example = new TenantInfoExample();
				example.createCriteria().andIdIn(new ArrayList<String>(ids));
				queryAndTransfer(result, example);
				ids.clear();
			}
		}
		if (ids.size() > 0) {
			example = new TenantInfoExample();
			example.createCriteria().andIdIn(new ArrayList<String>(ids));
			queryAndTransfer(result, example);
		}
	}

	private void queryAndTransfer(List<DeptInfo> result, TenantInfoExample example) {
		List<TenantInfo> tenants = tenantInfoMapper.selectByExample(example);
		for (TenantInfo tenantInfo : tenants) {
			result.add(Assembler.buildDeptInfo(tenantInfo));
		}
	}

	private void filter(List<DeptInfo> result) {
		// 查询祖先数据
		List<String> ids = new ArrayList<String>(10);
		Set<String> missedIds = new HashSet<String>(16);
		Set<String> ancestorIds = new HashSet<String>(16);
		for (DeptInfo dept : result) {
			setIds(ids, missedIds, ancestorIds, dept);
		}
		// 排除顶级ID和租户ID
		ancestorIds.remove("0");
		ancestorIds.removeAll(missedIds);
		
		// 如果当前登录用户不是超级管理员，查询当前登录用户机构的祖先数据，并排除
		if (!UserUtils.isAdmin()) {
			DeptInfo curDept = deptInfoMapper.selectByPrimaryKey(UserUtils.getCurUserDeptId());
			if (null != curDept) {
				ancestorIds.removeAll(Arrays.asList(curDept.getAncestors().split(",")));
			}
		}
		
		List<String> needQueryIds = new ArrayList<String>(10);
		for (String ancestorId : ancestorIds) {
			if (!ids.contains(ancestorId) && !needQueryIds.contains(ancestorId)) {
				needQueryIds.add(ancestorId);
			}
		}
		// 当前一次查询，如果数据很多，需要分批次查询
		if (needQueryIds.size() > 0) {
			DeptInfoExample example = new DeptInfoExample();
			DeptInfoExample.Criteria criteria = example.createCriteria();
			criteria.andIdIn(needQueryIds);
			List<DeptInfo> ancestors = deptInfoMapper.selectByExample(example);
			result.addAll(ancestors);
		}
	}

	private void setIds(List<String> ids, Set<String> missedIds, Set<String> ancestorIds,
			DeptInfo dept) {
		ids.add(dept.getId());
		missedIds.add(dept.getTenantId());
		ancestorIds.addAll(Arrays.asList(dept.getAncestors().split(",")));
	}

	/**
	 * 查询机构及子集列表
	 * 
	 * @return
	 */
	public List<DeptInfo> selectDeptList() {
		return queryAndAssemble(new DeptInfo());
	}
	
	private void supplyQuery(DeptInfo deptInfo) {
		// 租户和组织机构是分成两个表的，在更多情况下只会查询到组织机构表，为了避免不必要的多表联合查询，分拆为两个步骤的单表查询
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		if (!UserUtils.isAdmin(user)) {
			deptInfo.setId(user.getLoginDept().getId());
			// 非admin用户最多只能查看自己用户所在机构下的组织机构
			TenantInfo tenant = tenantService.selectByPrimaryKey(user.getTenantId());
			if (null != tenant) {
				deptInfo.setTenantId(tenant.getId());
			}
		}
	}
	
	/**
	 * 根据组织机构主键查询组织机构信息
	 * 
	 * @param id
	 * @return
	 */
	public DeptInfo selectDeptById(String id) {
		return deptInfoMapper.selectByPrimaryKey(id);
	}

	/**
	 * 
	 * @param tenantId
	 * @return
	 */
	public Boolean checkNoSon(String tenantId) {
		DeptInfoExample example = new DeptInfoExample();
		example.createCriteria().andTenantIdEqualTo(tenantId);
		return deptInfoMapper.countByExample(example) == 0;
	}

	/**
	 * 根据ID集合查询所有无效的组织机构
	 * 
	 * @param ids
	 * @return
	 */
	public int countInvalidDeptListByIds(List<String> ids) {
		DeptInfoExample example = new DeptInfoExample();
		example.createCriteria().andIdIn(ids).andStatusEqualTo(Constants.COMMON_INVALID);
		return deptInfoMapper.countByExample(example);
	}

	/**
	 * 根据ID统计符合状态的子集机构
	 * 
	 * @param id
	 * @param status
	 * @return
	 */
	public int countDeptByAncestorId(String id, Integer status) {
		DeptInfoExample example = new DeptInfoExample();
		DeptInfoExample.Criteria criteria = example.createCriteria();
		criteria.andAncestorsLike("%," + id + "%");
		criteria.andStatusEqualTo(status);
		return deptInfoMapper.countByExample(example);
	}
	
	public List<DeptInfo> getAncestors(String id){
		List<DeptInfo> list = new ArrayList<DeptInfo>();
		getAncestor(id, list);
		return list;
	}
	
	/**
	 * 根据机构ID, 递归查询所有上级机构，包含自己
	 * @param id
	 * @param list
	 */
	public void getAncestor(String id, List<DeptInfo> list){
		DeptInfo deptInfo = selectDeptById(id);
		if(deptInfo != null){
			if(!Constants.ROOT_ID.equals(deptInfo.getParentId())){
				getAncestor(deptInfo.getParentId(), list);
			}
			list.add(deptInfo);
		}
	}
	/**
	 * 根据机构ID, 递归查询所有上级机构，包含自己
	 * @param id
	 * @param list
	 */
	public void getAncestorId(String id, List<String> set){
		DeptInfo deptInfo = selectDeptById(id);
		if(deptInfo != null){
			if(!Constants.ROOT_ID.equals(deptInfo.getParentId())){
				getAncestorId(deptInfo.getParentId(), set);
			}
			set.add(deptInfo.getId());
		}
	}
	
	public void getAncestorIds(List<String> ids, List<String> set){
		for(String id : ids){
			getAncestorId(id, set);
		}
	}
	
	/**
	 * 根据机构ID, 递归查询所有上级机构，包含自己
	 * @param id
	 * @param list
	 */
	public void getChildren(List<String> ids, List<DeptInfo> list){
		
		DeptInfoExample example = new DeptInfoExample();
		DeptInfoExample.Criteria criteria = example.createCriteria();
		criteria.andParentIdIn(ids);
		List<DeptInfo> tmpList = deptInfoMapper.selectByExample(example);
		
		if(!CollectionUtils.isEmpty(tmpList)){
			list.addAll(tmpList);
			
			List<String> idsTmp = new ArrayList<String>();
			for(DeptInfo tmp : tmpList){
				idsTmp.add(tmp.getId());
			}
			getChildren(idsTmp, list);	
		}
	}
	/**
	 * 根据机构ID, 递归查询所有上级机构，包含自己
	 * @param id
	 * @param list
	 */
	public void getChildrenId(List<String> ids, List<String> list){
		
		DeptInfoExample example = new DeptInfoExample();
		DeptInfoExample.Criteria criteria = example.createCriteria();
		criteria.andParentIdIn(ids);
		List<DeptInfo> tmpList = deptInfoMapper.selectByExample(example);
		
		if(!CollectionUtils.isEmpty(tmpList)){
			
			List<String> idsTmp = new ArrayList<String>();
			for(DeptInfo tmp : tmpList){
				idsTmp.add(tmp.getId());
				list.add(tmp.getId());
			}
			getChildrenId(idsTmp, list);	
		}
	}

}

package com.huateng.user.core.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.huateng.base.cache.CacheManager;
import com.huateng.base.cache.DeleteCache;
import com.huateng.base.cache.UseCache;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.core.enumration.EnumrationItemExt;
import com.huateng.user.core.model.dictInfo.DictTypeData;
import com.huateng.user.core.model.dictInfo.DictTypeQuery;
import com.huateng.user.dal.dao.DictDataInfoMapper;
import com.huateng.user.dal.dao.DictTypeInfoMapper;
import com.huateng.user.dal.model.DictDataInfo;
import com.huateng.user.dal.model.DictDataInfoExample;
import com.huateng.user.dal.model.DictTypeInfo;
import com.huateng.user.dal.model.DictTypeInfoExample;

@Repository
public class DictInfoService {

	private static final Logger logger = LoggerFactory.getLogger(DictInfoService.class);
	
	@Autowired
	private DictTypeInfoMapper typeMapper;
	
	@Autowired
	private DictDataInfoMapper dataMapper;
	
	@Autowired
	private SqlSessionFactory sessionFactory;
	
	@Autowired
	private CacheManager cacheManager;
	
	public List<DictTypeInfo> findTypeList(DictTypeQuery typeQuery , PageInfo<DictTypeInfo> page){
		DictTypeInfoExample example = new DictTypeInfoExample();
		DictTypeInfoExample.Criteria criteria = example.createCriteria();

		if (typeQuery != null) {
			if (StringUtils.isNotBlank(typeQuery.getDictType())) {
				criteria.andDictTypeLike("%" + typeQuery.getDictType() + "%");
			}

			if (StringUtils.isNotBlank(typeQuery.getDictName())) {
				criteria.andDictNameLike("%" + typeQuery.getDictName() + "%");
			}

			if (StringUtils.isNotBlank(typeQuery.getBeignTime())) {
				Date beginTime;
				try {
					beginTime = DateUtils.parseDate(typeQuery.getBeignTime(), "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss");
					criteria.andCreateTimeGreaterThanOrEqualTo(beginTime);
				} catch (ParseException e) {
					logger.error("can't parser the date for beginTime:[{}]", typeQuery.getBeignTime());
				}
			}

			if (StringUtils.isNotBlank(typeQuery.getEndTime())) {
				Date endTime;
				try {
					endTime = DateUtils.parseDate(typeQuery.getEndTime(), "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss");
					criteria.andCreateTimeLessThan(endTime);
				} catch (ParseException e) {
					logger.error("can't parser the date for endTime:[{}]", typeQuery.getEndTime());
				}
			}

			if (typeQuery.getStatus() != null && typeQuery.getStatus() > 0) {
				criteria.andStatusEqualTo(typeQuery.getStatus());
			}
		}

		example.setOrderByClause(" ID DESC");
		return typeMapper.selectByExample(example, page);
	}
	
	@UseCache(key="'DICT_'+#type" , expireTime=60 *60 * 24)
	public List<EnumrationItemExt> findEnumByType(String type) {
		DictDataInfoExample example = new DictDataInfoExample();
		DictDataInfoExample.Criteria criteria = example.createCriteria();
		criteria.andDictTypeEqualTo(type);
		example.setOrderByClause(" DICT_SORT ASC, CREAT_TIME ASC");
		List<DictDataInfo> dictDataList = dataMapper.selectByExample(example);
		if (dictDataList != null) {
			List<EnumrationItemExt> result = new ArrayList<EnumrationItemExt>(10);
			for (DictDataInfo dataInfo : dictDataList) {
				EnumrationItemExt item = new EnumrationItemExt();
				item.setCode(dataInfo.getDictCode());
				item.setText(dataInfo.getDictLabel());
				item.setValue(dataInfo.getDictValue());
				result.add(item);
			}
			return result;
		}
		return null;
	}
	
	public DictTypeData findByTypeId(String id){
		DictTypeInfo info = typeMapper.selectByPrimaryKey(id);
		if (info != null) {

			DictTypeData result = new DictTypeData();
			BeanUtils.copyProperties(info, result);

			DictDataInfoExample dataExample = new DictDataInfoExample();
			DictDataInfoExample.Criteria criteria = dataExample.createCriteria();
			criteria.andDictTypeEqualTo(info.getDictType());
			dataExample.setOrderByClause(" DICT_SORT ASC, CREATE_TIME ASC");
			List<DictDataInfo> dataList = dataMapper.selectByExample(dataExample);
			result.setDataList(dataList);
			return result;
		}
		return null;
	}
	
	public boolean checkDictTypeUnique(String id , String type){
		DictTypeInfoExample example = new DictTypeInfoExample();
		DictTypeInfoExample.Criteria criteria = example.createCriteria();

		if (StringUtils.isNotBlank(id)) {
			criteria.andIdNotEqualTo(id);
		}
		criteria.andDictTypeEqualTo(type);

		return typeMapper.countByExample(example) == 0;
	}
	
	@Transactional
//	@DeleteCache
	public void removeType(String[] ids){
		DictTypeInfoExample example = new DictTypeInfoExample();
		DictTypeInfoExample.Criteria criteria = example.createCriteria();
		if (ids != null && ids.length > 0) {
			criteria.andIdIn(Arrays.asList(ids));
		}
		List<DictTypeInfo> deleteTypeList = typeMapper.selectByExample(example);
		if (deleteTypeList != null && deleteTypeList.size() > 0) {
			List<String> typeList = new ArrayList<String>(10);
			for (DictTypeInfo typeInfo : deleteTypeList) {
				typeList.add(typeInfo.getDictType());
				cacheManager.removeObj("DICT_" + typeInfo.getDictType());
			}

			if (typeList != null && typeList.size() > 0) {
				DictDataInfoExample dataExample = new DictDataInfoExample();
				DictDataInfoExample.Criteria dataCriteria = dataExample.createCriteria();
				dataCriteria.andDictTypeIn(typeList);
				dataMapper.deleteByExample(dataExample);
			}
		}
		typeMapper.deleteByExample(example);
	}
	
	@Transactional
	@DeleteCache(key="'DICT_'+#typeData.dictType")
	public void saveDictTypeData(DictTypeData typeData) throws Exception {
		SqlSession session = sessionFactory.openSession(ExecutorType.BATCH);
		
		DictTypeInfoMapper batchTypeMapper = session.getMapper(DictTypeInfoMapper.class);
		DictDataInfoMapper batchDataMapper = session.getMapper(DictDataInfoMapper.class);
		if (typeData != null) {
			List<DictDataInfo> dictDatas = null;
			if (StringUtils.isNotBlank(typeData.getId())) {
				typeData.setUpdateTime(new Date());
				batchTypeMapper.updateByPrimaryKeySelective(typeData);
				
				DictDataInfoExample example = new DictDataInfoExample();
				example.createCriteria().andDictTypeEqualTo(typeData.getDictType());
				dictDatas = dataMapper.selectByExample(example);
			} else {
				typeData.setCreateTime(new Date());
				typeData.setUpdateTime(new Date());
				batchTypeMapper.insertSelective(typeData);
			}

			Set<String> ids = new HashSet<String>(8);
			if (CollectionUtils.isNotEmpty(dictDatas)) {
				for (DictDataInfo info : dictDatas) {
					ids.add(info.getId());
				}
			}
			
			if (typeData.getDataList() != null && typeData.getDataList().size() > 0) {
				Set<String> upIds = new HashSet<String>(8);
				for (DictDataInfo dataInfo : typeData.getDataList()) {
					dataInfo.setDictType(typeData.getDictType());
					if (StringUtils.isNotBlank(dataInfo.getId()) && !StringUtils.startsWith(dataInfo.getId(), "new")) {
						upIds.add(dataInfo.getId());
						dataInfo.setUpdateTime(new Date());
						batchDataMapper.updateByPrimaryKeySelective(dataInfo);
					} else {
						dataInfo.setCreateTime(new Date());
						dataInfo.setUpdateTime(new Date());
						batchDataMapper.insertSelective(dataInfo);
					}
				}
				ids.removeAll(upIds);
			}
			
			if (ids.size() > 0) {
				DictDataInfoExample example = new DictDataInfoExample();
				example.createCriteria().andIdIn(Arrays.asList(ids.toArray(new String[]{})));
				dataMapper.deleteByExample(example);
			}
			
			session.flushStatements();
		}
	}
	
}

package com.huateng.user.core.service;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.core.model.loginLog.LoginLogQuery;
import com.huateng.user.core.util.HTDateUtils;
import com.huateng.user.dal.dao.LoginInfoMapper;
import com.huateng.user.dal.dao.ext.ExtDeptInfoMapper;
import com.huateng.user.dal.model.LoginInfo;
import com.huateng.user.dal.model.LoginInfoExample;

@Repository("LoginInfoService")
public class LoginInfoService {

	@Autowired
	private ExtDeptInfoMapper extDeptInfoMapper;
	
	@Autowired
	private LoginInfoMapper mapper;

	public void saveLoginfor(LoginInfo loginfor) {
		loginfor.setLoginTime(new Date());
		if (StringUtils.isNotBlank(loginfor.getId())) {
//			loginfor.setId(loginInfoList.get(0).getId());
			mapper.updateByPrimaryKeySelective(loginfor);
		} else {
			mapper.insertSelective(loginfor);
		}
	}

	public List<LoginInfo> search(LoginLogQuery query, PageInfo<LoginInfo> page) {
		if (query != null) {
			LoginInfoExample example = new LoginInfoExample();
			LoginInfoExample.Criteria criteria = example.createCriteria();

			if (StringUtils.isNotBlank(query.getBeginTime())) {
				Date beginTime = HTDateUtils.parseDate(query.getBeginTime());
				criteria.andLoginTimeGreaterThanOrEqualTo(beginTime);
			}

			/*SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
			if (!UserUtils.isAdmin(user)) {
				String accessorId = user.getLoginDept().getId();
				List<String> ids = extDeptInfoMapper.selectDeptIdsByAccessorId(accessorId);
				if (CollectionUtils.isNotEmpty(ids)) {
					// 认为正常情况子孙机构不会超过1000，否则这里需要修改
					criteria.andDeptIdIn(ids);
				}
			}*/
			
			if (StringUtils.isNotBlank(query.getEndTime())) {
				Date beginTime = HTDateUtils.parseDate(query.getEndTime());
				criteria.andLoginTimeLessThan(beginTime);
			}

			if (StringUtils.isNotBlank(query.getIpaddr())) {
				criteria.andIpaddrLike("%" + query.getIpaddr() + "%");
			}
			if (StringUtils.isNotBlank(query.getLoginName())) {
				criteria.andLoginNameLike("%" + query.getLoginName() + "%");
			}
			if (query.getStatus() != null) {
				criteria.andStatusEqualTo(query.getStatus());
			}

			example.setOrderByClause(" LOGIN_TIME DESC");
			mapper.selectByExample(example, page);
		}
		return null;
	}

	public void deleteByIds(String ids) {
		String[] idStrs = ids.split(",");
		if (idStrs.length == 1) {
			mapper.deleteByPrimaryKey(idStrs[0]);
		} else {
			LoginInfoExample example = new LoginInfoExample();
			LoginInfoExample.Criteria criteria = example.createCriteria();
			criteria.andIdIn(Arrays.asList(idStrs));
			mapper.deleteByExample(example);
		}
	}
}

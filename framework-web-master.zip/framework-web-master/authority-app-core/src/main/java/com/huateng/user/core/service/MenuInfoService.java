package com.huateng.user.core.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.enums.YesOrNoEnum;
import com.huateng.user.dal.dao.MenuInfoMapper;
import com.huateng.user.dal.dao.RoleMenuInfoMapper;
import com.huateng.user.dal.dao.ext.ExtMenuInfoMapper;
import com.huateng.user.dal.model.MenuInfo;
import com.huateng.user.dal.model.MenuInfoExample;
import com.huateng.user.dal.model.RoleInfo;
import com.huateng.user.dal.model.RoleMenuInfoExample;

@Repository
public class MenuInfoService {

	@Autowired
	private MenuInfoMapper menuInfoMapper;
	
	@Autowired
	private RoleMenuInfoMapper roleMenuInfoMapper;
	
	@Autowired
	private ExtMenuInfoMapper extMenuInfoMapper;
	
	public List<MenuInfo> findMenuInfoByUserId(String userId, String deptId){
		// 使用map是因为需要传递一些其他相关的配置化的固定参数
		Map<String, Object> params = createQueryByUserIdParamMap(userId, deptId);
		// 菜单查询不包含按钮
		params.put("menuType", new Integer[]{Constants.MENU_TYPE_DIC, Constants.MENU_TYPE_MENU});
		return extMenuInfoMapper.findMenuByUserId(params);
	}
	
	public List<MenuInfo> findAllMenu(){
		MenuInfoExample example = new MenuInfoExample();
		MenuInfoExample.Criteria criteria = example.createCriteria();
		
		criteria.andVisibleEqualTo(Constants.COMMON_VALID);
		criteria.andMenuTypeIn(Arrays.asList(new Integer[]{Constants.MENU_TYPE_DIC , Constants.MENU_TYPE_MENU}));
		
		example.setDistinct(true);
		example.setOrderByClause("PARENT_ID, ORDER_NUM");
		
		return menuInfoMapper.selectByExample(example);
	}
	
	public List<MenuInfo> findMenu(String menuName){
		MenuInfoExample example = new MenuInfoExample();
		MenuInfoExample.Criteria criteria = example.createCriteria();
		
		criteria.andMenuNameLike("%" + menuName + "%");
		criteria.andVisibleEqualTo(Constants.COMMON_VALID);
		criteria.andMenuTypeIn(Arrays.asList(new Integer[]{Constants.MENU_TYPE_DIC , Constants.MENU_TYPE_MENU}));
		
		example.setDistinct(true);
		example.setOrderByClause("PARENT_ID, ORDER_NUM");
		
		return menuInfoMapper.selectByExample(example);
	}
	
	public List<String> findPermByUserId(String userId, String deptId){
		// 使用map是因为需要传递一些其他相关的配置化的固定参数
		return extMenuInfoMapper.selectPermsByUserId(createQueryByUserIdParamMap(userId, deptId));
	}

	private Map<String, Object> createQueryByUserIdParamMap(String userId, String deptId) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("userId", userId);
		if (StringUtils.isNotBlank(deptId)) {
			params.put("deptId", deptId);
		}
		params.put("visible", Integer.valueOf(YesOrNoEnum.YES.getCode()));
		params.put("status", Constants.COMMON_VALID);
		params.put("menuId", Constants.MENU_TENANT_ID);
		params.put("menuParentId", Constants.MENU_TENANT_ID);
		return params;
	}
	
	/**超级管理员获得所有的授权标识
	 * @return
	 */
	public List<String> findAllPerm(){
		return extMenuInfoMapper.selectAllPerms();
	}

	/**
	 * 关联分页查询资源菜单
	 * 
	 * @param menuInfo
	 */
	public List<MenuInfo> selectMenuList(MenuInfo menuInfo) {
		MenuInfoExample example = new MenuInfoExample();
		MenuInfoExample.Criteria criteria = example.createCriteria();
		if (StringUtils.isNotBlank(menuInfo.getMenuName())) {
			criteria.andMenuNameLike("%" + menuInfo.getMenuName() + "%");
		}
		if (null != menuInfo.getVisible()) {
			criteria.andVisibleEqualTo(menuInfo.getVisible());
		}
		example.setOrderByClause(" ORDER_NUM ASC, CREATE_TIME ASC");
		return menuInfoMapper.selectByExample(example);
	}

	/**
	 * 根据父菜单ID查看子菜单数量
	 * 
	 * @param id
	 * @return
	 */
	public int countMenusByParentId(String id) {
		MenuInfoExample example = new MenuInfoExample();
		example.createCriteria().andParentIdEqualTo(id);
		return menuInfoMapper.countByExample(example);
	}

	/**
	 * 根据菜单ID查看菜单被分配角色数量
	 * 
	 * @param menuId
	 * @return
	 */
	public int countRolesByMenuId(String menuId) {
		RoleMenuInfoExample example = new RoleMenuInfoExample();
		example.createCriteria().andMenuIdEqualTo(menuId);
		return roleMenuInfoMapper.countByExample(example);
	}

	/**
	 * 根据ID删除菜单
	 * 
	 * @param id
	 * @return
	 */
	public int deleteMenuById(String id) {
		return menuInfoMapper.deleteByPrimaryKey(id);
	}

	/**
	 * 根据ID查询菜单
	 * 
	 * @param id
	 * @return
	 */
	public MenuInfo selectMenuById(String id) {
		return menuInfoMapper.selectByPrimaryKey(id);
	}

	/**
	 * 新增菜单
	 * 
	 * @param menuInfo
	 * @return
	 */
	public int insertMenu(MenuInfo menuInfo) {
		menuInfo.setCreateTime(new Date());
		return menuInfoMapper.insertSelective(menuInfo);
	}

	/**
	 * 修改菜单
	 * 
	 * @param menu
	 * @return
	 */
	public int updateMenu(MenuInfo menuInfo) {
		menuInfo.setUpdateTime(new Date());
		return menuInfoMapper.updateByPrimaryKeySelective(menuInfo);
	}

	/**
	 * 根据父菜单和本菜单名称检查名称是否已存在
	 * 
	 * @param menuInfo
	 * @return
	 */
	public boolean checkMenuNameUnique(MenuInfo menuInfo) {
		MenuInfoExample example = new MenuInfoExample();
		MenuInfoExample.Criteria criteria = example.createCriteria();
		criteria.andParentIdEqualTo(menuInfo.getParentId());
		criteria.andMenuNameEqualTo(menuInfo.getMenuName());
		if (StringUtils.isNotBlank(menuInfo.getId())) {
			criteria.andIdNotEqualTo(menuInfo.getId());
		}
		return menuInfoMapper.countByExample(example) == 0;
	}

	/**
	 * 查询菜单并组装数据
	 * 
	 * @param id 菜单ID，不为空的情况下会排除该菜单及其子菜单
	 * @return
	 */
	public List<Map<String, Object>> menuTreeData() {
		List<MenuInfo> menuList = selectMenuAll();
		return getTrees(menuList, false, null, false);
	}
	
	/**
	 * 查询菜单并组装数据
	 * 
	 * @param id 菜单ID，不为空的情况下会排除该菜单及其子菜单
	 * @return
	 */
	public List<Map<String, Object>> menuTreeData(String id) {
		List<MenuInfo> menuList = selectMenuAll();
		if (StringUtils.isNotBlank(id)) {
			removeMenuSubs(id, menuList);
		}
		return getTrees(menuList, false, null, false);
	}
	
	private void removeMenuSubs(String menuId, List<MenuInfo> all) {
		Set<String> idSet = new HashSet<String>();
		idSet.add(menuId);
		for (int i = 0; i < all.size(); i++) {
			Iterator<MenuInfo> ite = all.iterator();
			while (ite.hasNext()) {
				MenuInfo next = ite.next();
				if (idSet.contains(next.getId())) {
					ite.remove();
				} else if (idSet.contains(next.getParentId())) {
					idSet.add(next.getId());
					ite.remove();
				}
			}
		}
	}
	
	/**
	 * 
	 * @param roleInfo
	 * @return
	 */
	public List<Map<String, Object>> roleMenuTreeData(RoleInfo roleInfo) {
		String roleId = roleInfo.getId();
		List<Map<String, Object>> trees = new ArrayList<Map<String, Object>>(10);
		List<MenuInfo> menuList = selectMenuAll();
		if (StringUtils.isNotBlank(roleId)) {
			List<String> roleMenuList = extMenuInfoMapper.selectMenuTree(roleId);
			trees = getTrees(menuList, true, roleMenuList, true);
		} else {
			trees = getTrees(menuList, false, null, true);
		}
		return trees;
	}

	/**
	 * 对象转树结构
	 * 
	 * @param menuList
	 * @param isCheck
	 * @param roleMenuList
	 * @param permsFlag
	 * @return
	 */
	public List<Map<String, Object>> getTrees(List<MenuInfo> menuList, boolean isCheck, List<String> roleMenuList,
			boolean permsFlag) {
		List<Map<String, Object>> trees = new ArrayList<Map<String, Object>>(10);
		for (MenuInfo menu : menuList) {
			Map<String, Object> deptMap = new HashMap<String, Object>();
			deptMap.put("id", menu.getId());
			deptMap.put("pId", menu.getParentId());
			deptMap.put("name", transMenuName(menu, permsFlag));
			deptMap.put("title", menu.getMenuName());
			deptMap.put("type", menu.getMenuType());
			deptMap.put("value", menu.getId());
			if (isCheck) {
				deptMap.put("checked", roleMenuList.contains(menu.getId()));
			} else {
				deptMap.put("checked", false);
			}
			trees.add(deptMap);
		}
		return trees;
	}

	private Object transMenuName(MenuInfo menu, boolean permsFlag) {
		StringBuffer sb = new StringBuffer();
		sb.append(menu.getMenuName());
		if (permsFlag) {
			if (StringUtils.isNotBlank(menu.getPerms())) {
				sb.append("<font color=\"#888\">&nbsp;&nbsp;&nbsp;" + menu.getPerms() + "</font>");
			}
		}
		return sb.toString();
	}

	/**
	 * 查询菜单集合
	 * 
	 * @return 所有菜单信息
	 */
	public List<MenuInfo> selectMenuAll() {
		MenuInfoExample example = new MenuInfoExample();
		example.setOrderByClause(" ORDER_NUM ASC, CREATE_TIME ASC");
		return menuInfoMapper.selectByExample(example);
	}
	
	public List<Map<String, Object>> menuTreeData(boolean includeRoot)
    {
        List<Map<String, Object>> trees = new ArrayList<Map<String, Object>>();
        List<MenuInfo> menuList = findAllMenu();
        if(includeRoot) {
        	MenuInfo item = new MenuInfo();
        	item.setId("0");
        	item.setParentId("-1");
        	item.setMenuName(Constants.ROOT_CONTENT_NAME);
        	menuList.add(item);
        }
        trees = getTrees(menuList, false, null, false);
        return trees;
    }
	
	public List<Map<String, Object>> menuTreeData(boolean includeRoot,String menuName)
    {
        List<Map<String, Object>> trees = new ArrayList<Map<String, Object>>();
        List<MenuInfo> menuList;
        if(StringUtils.isEmpty(menuName)){
        	menuList = findAllMenu();
        }else{
        	menuList = findMenu(menuName);
        }
        if(includeRoot) {
        	MenuInfo item = new MenuInfo();
        	item.setId("0");
        	item.setParentId("-1");
        	item.setMenuName(Constants.ROOT_CONTENT_NAME);
        	menuList.add(item);
        }
        trees = getTrees(menuList, false, null, false);
        return trees;
    }
	
	public List<MenuInfo> findButtonByParent(String parentId){
		MenuInfoExample example = new MenuInfoExample();
		MenuInfoExample.Criteria criteria = example.createCriteria();
		criteria.andParentIdEqualTo(parentId);
		example.setOrderByClause("ID , ORDER_NUM");
		
		return menuInfoMapper.selectByExample(example);
	}
}

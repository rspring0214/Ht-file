package com.huateng.user.core.service;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.api.utils.UserUtils;
import com.huateng.user.core.model.operLog.OperLogQuery;
import com.huateng.user.core.util.HTDateUtils;
import com.huateng.user.dal.dao.OperLogInfoMapper;
import com.huateng.user.dal.dao.ext.ExtOperLogInfoMapper;
import com.huateng.user.dal.model.OperLogInfo;
import com.huateng.user.dal.model.OperLogInfoExample;

@Repository("OperLogInfoService")
public class OperLogInfoService {

	@Autowired
	private OperLogInfoMapper operLogInfoMapper;

	@Autowired
	private ExtOperLogInfoMapper extOperLogInfoMapper;

	public void addOperLog(OperLogInfo operLog) {
		operLog.setOperTime(new Date());
		operLogInfoMapper.insertSelective(operLog);
	}

	public List<OperLogInfo> search(OperLogQuery query, PageInfo<OperLogInfo> page) {
		if (query != null) {
			OperLogInfoExample example = new OperLogInfoExample();
			OperLogInfoExample.Criteria criteria = example.createCriteria();
			SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
			if (!UserUtils.isAdmin(user)) {
				criteria.andDeptIdEqualTo(user.getLoginDept().getId());
			}
			if (StringUtils.isNotBlank(query.getTitle())) {
				criteria.andTitleLike("%" + query.getTitle() + "%");
			}
			if (StringUtils.isNotBlank(query.getOperMethod())) {
				criteria.andOperMethodLike("%" + query.getOperMethod() + "%");
			}
			if (StringUtils.isNotBlank(query.getOperName())) {
				criteria.andOperNameLike("%" + query.getOperName() + "%");
			}
			if (StringUtils.isNotBlank(query.getOperRemark())) {
				criteria.andOperRemarkLike("%" + query.getOperRemark() + "%");
			}
			if (StringUtils.isNotBlank(query.getBeginTime())) {
				criteria.andOperTimeGreaterThan(HTDateUtils.parseDate(query.getBeginTime()));
			}

			if (StringUtils.isNotBlank(query.getEndTime())) {
				criteria.andOperTimeLessThan(HTDateUtils.parseDate(query.getEndTime()));
			}

			example.setOrderByClause(" OPER_TIME DESC");
			return operLogInfoMapper.selectByExample(example, page);
		}
		return null;
	}

	/**
	 * 根据ID查询操作日志
	 * 
	 * @param id
	 * @return
	 */
	public OperLogInfo selectOperLogById(String id) {
		return operLogInfoMapper.selectByPrimaryKey(id);
	}

	/**
	 * 删除操作日志
	 * 
	 * @param ids
	 * @return
	 */
	public int deleteOperLogByIds(List<String> ids) {
		Assert.notEmpty(ids, "ID 不能为空");
		if (ids.size() == 1) {
			return operLogInfoMapper.deleteByPrimaryKey(ids.get(0));
		} else {
			OperLogInfoExample example = new OperLogInfoExample();
			example.createCriteria().andIdIn(ids);
			return operLogInfoMapper.deleteByExample(example);
		}
	}

	/**
	 * 清空表记录
	 */
	public void cleanOperLog() {
		extOperLogInfoMapper.cleanOperLog();
	}
}

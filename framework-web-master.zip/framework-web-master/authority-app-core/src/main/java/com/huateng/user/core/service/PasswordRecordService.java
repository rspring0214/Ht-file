/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.service;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.huateng.user.dal.dao.PasswordRecordMapper;
import com.huateng.user.dal.model.PasswordRecord;
import com.huateng.user.dal.model.PasswordRecordExample;

/**
 * Description:密码服务
 *
 * @author Heaven.tang
 * @version $Id: PasswordRecordService.java, v 0.1 2019年4月18日 下午1:01:53 Heaven.tang Exp $
 */
@Repository
public class PasswordRecordService {

	@Autowired
	private PasswordRecordMapper mapper;
	
	/**
	 * 根据用户ID查询最近一次密码记录
	 * 
	 * @param userId
	 * @return
	 */
	public PasswordRecord selectLatestRecordByUserId(String userId) {
		PasswordRecordExample example = new PasswordRecordExample();
		example.createCriteria().andUserIdEqualTo(userId);
		example.setOrderByClause(" CREATE_TIME DESC");
		List<PasswordRecord> list = mapper.selectByExample(example);
		if (CollectionUtils.isNotEmpty(list)) {
			return list.get(0);
		}
		return null;
	}

	
}

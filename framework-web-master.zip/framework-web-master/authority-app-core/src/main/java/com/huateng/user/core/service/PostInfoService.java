/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.service;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.core.exception.DMLExecuteException;
import com.huateng.user.core.model.postInfo.PostInfoModel;
import com.huateng.user.core.util.BeanUtils;
import com.huateng.user.dal.dao.PostInfoMapper;
import com.huateng.user.dal.dao.UserPostInfoMapper;
import com.huateng.user.dal.dao.ext.ExtPostInfoMapper;
import com.huateng.user.dal.model.PostInfo;
import com.huateng.user.dal.model.PostInfoExample;
import com.huateng.user.dal.model.UserPostInfoExample;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: PostInfoService.java, v 0.1 2019年4月3日 下午4:41:47 Heaven.tang Exp $
 */
@Repository
public class PostInfoService {

	@Autowired
	private PostInfoMapper postInfoMapper;

	@Autowired
	private UserPostInfoMapper userPostInfoMapper;

	@Autowired
	private ExtPostInfoMapper extPostInfoMapper;

	/**
	 * 分页查询岗位信息
	 * 
	 * @param post
	 * @param page
	 */
	public List<PostInfo> selectPostListByPage(PostInfo post, PageInfo<PostInfo> page) {
		return postInfoMapper.selectByExample(createQuery(post), page);
	}

	/**
	 * 查询岗位信息
	 * 
	 * @param post
	 * @param page
	 */
	public List<PostInfo> selectPostList(PostInfo post) {
		return postInfoMapper.selectByExample(createQuery(post));
	}

	private PostInfoExample createQuery(PostInfo post) {
		PostInfoExample example = new PostInfoExample();
		PostInfoExample.Criteria criteria = example.createCriteria();
		if (post != null) {
			if (StringUtils.isNotBlank(post.getPostCode())) {
				criteria.andPostCodeLike("%" + post.getPostCode() + "%");
			}
			if (null != post.getStatus()) {
				criteria.andStatusEqualTo(post.getStatus());
			}
			if (StringUtils.isNotBlank(post.getPostName())) {
				criteria.andPostNameLike("%" + post.getPostName() + "%");
			}
		}
		example.setOrderByClause(" POST_SORT ASC, CREATE_TIME ASC");
		return example;
	}

	/**
	 * 新增岗位
	 * 
	 * @param post
	 * @return
	 */
	public int insertPost(PostInfo post) {
		post.setCreateTime(new Date());
		return postInfoMapper.insertSelective(post);
	}

	/**
	 * 根据ID查询岗位信息
	 * 
	 * @param id
	 * @return
	 */
	public PostInfo selectPostById(String id) {
		return postInfoMapper.selectByPrimaryKey(id);
	}

	/**
	 * 根据主键更新岗位信息
	 * 
	 * @param dept
	 * @return
	 */
	public int updatePost(PostInfo post) {
		post.setUpdateTime(new Date());
		return postInfoMapper.updateByPrimaryKeySelective(post);
	}

	/**
	 * 根据ID批量删除岗位
	 * 
	 * @param ids
	 * @return
	 */
	public int deletePostByIds(String ids) {
		// TODO 暂时不作并发回滚控制
		Assert.isTrue(ids.length() >= 1, "id must not empty");
		List<String> postIds = Arrays.asList(ids.split(","));
		for (String id : postIds) {
			PostInfo post = postInfoMapper.selectByPrimaryKey(id);
			if (countUsersByPostId(id) > 0) {
				throw new DMLExecuteException(String.format("%1$s已分配,不能删除", post.getPostName()));
			}
		}
		PostInfoExample example = new PostInfoExample();
		PostInfoExample.Criteria criteria = example.createCriteria();
		if (postIds.size() == 1) {
			return postInfoMapper.deleteByPrimaryKey(postIds.get(0));
		} else {
			criteria.andIdIn(postIds);
			return postInfoMapper.deleteByExample(example);
		}
	}

	/**
	 * 根据岗位ID查询岗位下人数
	 * 
	 * @param postId
	 * @return
	 */
	private int countUsersByPostId(String postId) {
		UserPostInfoExample example = new UserPostInfoExample();
		example.createCriteria().andPostIdEqualTo(postId);
		return userPostInfoMapper.countByExample(example);
	}

	/**
	 * 检查岗位名称是否存在
	 * 
	 * @param post
	 * @return
	 */
	public Boolean checkPostNameUnique(PostInfo post) {
		PostInfoExample example = new PostInfoExample();
		PostInfoExample.Criteria criteria = example.createCriteria();
		criteria.andPostNameEqualTo(post.getPostName());
		if (StringUtils.isNotBlank(post.getId())) {
			criteria.andIdNotEqualTo(post.getId());
		}
		return postInfoMapper.countByExample(example) == 0;
	}

	/**
	 * 检查岗位编号是否存在
	 * 
	 * @param post
	 * @return
	 */
	public Boolean checkPostCodeUnique(PostInfo post) {
		PostInfoExample example = new PostInfoExample();
		PostInfoExample.Criteria criteria = example.createCriteria();
		criteria.andPostCodeEqualTo(post.getPostCode());
		if (StringUtils.isNotBlank(post.getId())) {
			criteria.andIdNotEqualTo(post.getId());
		}
		return postInfoMapper.countByExample(example) == 0;
	}

	/**
	 * 根据用户ID查询岗位信息
	 * 
	 * @param userId
	 * @return
	 */
	public List<PostInfoModel> selectPostsByUserId(String userId) {
		List<PostInfo> userPosts = extPostInfoMapper.selectPostsByUserId(userId);
		List<PostInfo> postInfos = selectPostList(null);
		List<PostInfoModel> postList = BeanUtils.propertiesCopy(postInfos, new PostInfoModel());
		for (PostInfoModel model : postList) {
			for (PostInfo post : userPosts) {
				if (model.getId().equals(post.getId())) {
					model.setFlag(true);
					break;
				}
			}
		}
		return postList;
	}

	/**
	 * 统计岗位使用用户数
	 * 
	 * @param ids
	 * @return
	 */
	public int countUsersByPostIds(String ids) {
		UserPostInfoExample example = new UserPostInfoExample();
		example.createCriteria().andPostIdIn(Arrays.asList(ids));
		return userPostInfoMapper.countByExample(example);
	}

}

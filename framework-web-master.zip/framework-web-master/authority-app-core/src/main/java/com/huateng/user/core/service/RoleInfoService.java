/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.service;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.alibaba.fastjson.JSONObject;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.constants.ExceptionConstants;
import com.huateng.user.api.enums.YesOrNoEnum;
import com.huateng.user.core.exception.DMLExecuteException;
import com.huateng.user.core.model.roleInfo.RoleInfoModel;
import com.huateng.user.core.model.roleInfo.RoleInfoQueryModel;
import com.huateng.user.core.util.BeanUtils;
import com.huateng.user.core.util.HTDateUtils;
import com.huateng.user.dal.dao.RoleDeptInfoMapper;
import com.huateng.user.dal.dao.RoleInfoMapper;
import com.huateng.user.dal.dao.RoleMenuInfoMapper;
import com.huateng.user.dal.dao.UserRoleInfoMapper;
import com.huateng.user.dal.dao.ext.ExtRoleInfoMapper;
import com.huateng.user.dal.model.RoleDeptInfo;
import com.huateng.user.dal.model.RoleDeptInfoExample;
import com.huateng.user.dal.model.RoleInfo;
import com.huateng.user.dal.model.RoleInfoExample;
import com.huateng.user.dal.model.RoleMenuInfo;
import com.huateng.user.dal.model.RoleMenuInfoExample;
import com.huateng.user.dal.model.UserRoleInfoExample;

/**
 * Description:角色管理实现
 *
 * @author Heaven.tang
 * @version $Id: RoleInfoService.java, v 0.1 2019年4月3日 下午6:53:50 Heaven.tang Exp $
 */
@Repository
public class RoleInfoService {

	private static final Logger logger = LoggerFactory.getLogger(RoleInfoService.class);
	
	@Autowired
	private RoleInfoMapper roleInfoMapper;
	
	@Autowired
	private RoleMenuInfoMapper roleMenuInfoMapper;
	
	@Autowired
	private SqlSessionFactory sessionFactory;
	
	@Autowired
	private RoleDeptInfoMapper roleDeptInfoMapper;
	
	@Autowired
	private UserRoleInfoMapper userRoleInfoMapper;
	
	@Autowired
	private ExtRoleInfoMapper extRoleInfoMapper;
	
	/**
	 * 分页查询角色信息
	 * 
	 * @param role
	 * @param page
	 * @return
	 */
	public List<RoleInfo> selectRoleListByPage(RoleInfoQueryModel role, PageInfo<RoleInfo> page) {
		return roleInfoMapper.selectByExample(createQuery(role), page);
	}

	/**
	 * 查询角色信息
	 * 
	 * @param role
	 * @param page
	 */
	public List<RoleInfo> selectRoleList(RoleInfoQueryModel role) {
		return roleInfoMapper.selectByExample(createQuery(role));
	}
	
	private RoleInfoExample createQuery(RoleInfoQueryModel role) {
		RoleInfoExample example = new RoleInfoExample();
		RoleInfoExample.Criteria criteria = example.createCriteria();
		criteria.andDelFlagEqualTo(Integer.valueOf(YesOrNoEnum.YES.getCode()));
		if (null != role) {
			if (StringUtils.isNotBlank(role.getRoleKey())) {
				criteria.andRoleKeyLike("%" + role.getRoleKey() + "%");
			}
			if (null != role.getStatus()) {
				criteria.andStatusEqualTo(role.getStatus());
			}
			if (StringUtils.isNotBlank(role.getRoleName())) {
				criteria.andRoleNameLike("%" + role.getRoleName() + "%");
			}
			if (null != role.getDataScope()) {
				criteria.andDataScopeEqualTo(role.getDataScope());
			}
			if (StringUtils.isNotBlank(role.getBeginTime())) {
				criteria.andCreateTimeGreaterThanOrEqualTo(HTDateUtils.parseDate(role.getBeginTime()));
			}
			if (StringUtils.isNotBlank(role.getEndTime())) {
				criteria.andCreateTimeLessThan(HTDateUtils.parseDate(role.getEndTime()));
			}
		}
		example.setOrderByClause(" ROLE_SORT ASC, CREATE_TIME ASC");
		return example;
	}

	/**
	 * 新增角色和关联信息
	 * 
	 * @param role
	 * @return
	 */
	@Transactional
	public void insertRole(RoleInfoModel role) {
		insertRoleInfo(role);
		insertRoleMenus(role.getId(), Arrays.asList(role.getMenuIds()));
	}

	private void insertRoleInfo(RoleInfoModel role) {
		role.setCreateTime(new Date());
		role.setDelFlag(Integer.valueOf(YesOrNoEnum.YES.getCode()));
		int num = roleInfoMapper.insertSelective(role);
		if (num != 1) {
			logger.error("Data role insert failed, expect 1, but {}, role {}", num, JSONObject.toJSONString(role));
			throw new DMLExecuteException("数据保存记录异常");
		}
	}
	
	private void insertRoleMenus(String roleId, List<String> menuIds) {
		int num = 0;
		try {
			num = batchInsertRoleMenus(roleId, menuIds);
		} catch (Exception e) {
			logger.error("Data role menu insert exception ", e);
			throw new DMLExecuteException(ExceptionConstants.DATA_INSERT_EXCEPTION_MESSAGE);
		}
		if (num != menuIds.size()) {
			logger.error("Data role menu insert failed, expect 1, but {}", num);
			throw new DMLExecuteException(ExceptionConstants.DATA_INSERT_EXCEPTION_MESSAGE);
		}
	}

	/**
	 * 批量插入
	 * 
	 * @param roleId
	 * @return
	 * @throws Exception 
	 */
	public int batchInsertRoleMenus(String roleId, List<String> menuIds) throws Exception {
		if (CollectionUtils.isEmpty(menuIds)) {
			return 0;
		}
		int rows = 0;
		// 新增用户与角色管理
		SqlSession session = sessionFactory.openSession(ExecutorType.BATCH);
		RoleMenuInfoMapper mapper = session.getMapper(RoleMenuInfoMapper.class);
		for (String menuId : menuIds) {
			RoleMenuInfo rm = new RoleMenuInfo();
			rm.setRoleId(roleId);
			rm.setMenuId(menuId);
			mapper.insertSelective(rm);
			rows++;
		}
		session.flushStatements();
		return rows;
	}

	/**
	 * 根据ID查询角色信息
	 * 
	 * @param id
	 * @return
	 */
	public RoleInfo selectRoleById(String id) {
		RoleInfoExample example = new RoleInfoExample();
		RoleInfoExample.Criteria criteria = example.createCriteria();
		criteria.andIdEqualTo(id);
		criteria.andDelFlagEqualTo(Integer.valueOf(YesOrNoEnum.YES.getCode()));
		List<RoleInfo> list = roleInfoMapper.selectByExample(example);
		if (CollectionUtils.isEmpty(list)) {
			return null;
		}
		return list.get(0);
	}

	/**
	 * 
	 * @param dept
	 * @return
	 */
	@Transactional
	public void updateRole(RoleInfoModel role) {
		int num = updateRoleInfo(role);
		if (num != 1) {
			logger.error("Data role update failed, expect 1, but {}, id {}", num, role.getId());
			throw new DMLExecuteException(ExceptionConstants.DATA_UPDATE_EXCEPTION_MESSAGE);
		}
		deleteRoleMenus(role.getId());
		insertRoleMenus(role.getId(), Arrays.asList(role.getMenuIds()));
	}

	private void deleteRoleMenus(String roleId) {
		RoleMenuInfoExample example = new RoleMenuInfoExample();
		example.createCriteria().andRoleIdEqualTo(roleId);
		// 如果严格控制，需要先查询一次数量
		roleMenuInfoMapper.deleteByExample(example);
	}

	/**
	 * 修改数据权限信息
	 * 
	 * @param role
	 * @param menuIds
	 * @param deptIds
	 */
	@Transactional
	public void updateRule(RoleInfoModel role) {
		// 修改角色信息
		int num = updateRoleInfo(role);
		if (num != 1) {
			logger.error("Data role update failed, expect 1, but {}, id {}", num, role.getId());
			throw new DMLExecuteException(ExceptionConstants.DATA_UPDATE_EXCEPTION_MESSAGE);
		}
		// 删除角色与组织机构关联
		deleteRoleDepts(role.getId());
		// 新增角色和组织机构信息（数据权限）
		insertRoleDepts(role.getId(), Arrays.asList(role.getDeptIds()));
	}

	private void deleteRoleDepts(String roleId) {
		RoleDeptInfoExample example = new RoleDeptInfoExample();
		example.createCriteria().andRoleIdEqualTo(roleId);
		try {
			roleDeptInfoMapper.deleteByExample(example);
		} catch (Exception e) {
			logger.error("Data roleDept delete exception ", e);
			throw new DMLExecuteException(ExceptionConstants.DATA_DELETE_EXCEPTION_MESSAGE);
		}
	}
	
	private void insertRoleDepts(String roleId, List<String> deptIds) {
		int num = 0;
		try {
			num = batchInsertRoleDepts(roleId, deptIds);
		} catch (Exception e) {
			logger.error("Data role menu insert exception ", e);
			throw new DMLExecuteException(ExceptionConstants.DATA_INSERT_EXCEPTION_MESSAGE);
		}
		if (num != deptIds.size()) {
			logger.error("Data role menu insert failed, expect 1, but {}", num);
			throw new DMLExecuteException(ExceptionConstants.DATA_INSERT_EXCEPTION_MESSAGE);
		}
	}

	/**
	 * 更新角色信息
	 * 
	 * @param role
	 * @return
	 */
	public int updateRoleInfo(RoleInfo role) {
		role.setUpdateTime(new Date());
		return roleInfoMapper.updateByPrimaryKeySelective(role);
	}

	/**
	 * 新增角色组织机构信息
	 * 
	 * @param role
	 * @throws Exception 
	 */
	private int batchInsertRoleDepts(String roleId, List<String> deptIds) throws Exception {
		if (CollectionUtils.isEmpty(deptIds)) {
			return 0;
		}
		int rows = 0;
		// 新增角色与组织机构（数据权限）管理
		SqlSession session = sessionFactory.openSession(ExecutorType.BATCH);
		RoleDeptInfoMapper mapper = session.getMapper(RoleDeptInfoMapper.class);
		for (String deptId : deptIds) {
			RoleDeptInfo rd = new RoleDeptInfo();
			rd.setRoleId(roleId);
			rd.setDeptId(deptId);
			mapper.insertSelective(rd);
			rows++;
		}
		session.flushStatements();
		return rows;
	}

	/**
	 * 根据ID批量删除角色
	 * 
	 * @param ids
	 */
	public void deleteRoleByIds(String ids) {
		// TODO 暂时不作并发回滚控制
		Assert.isTrue(ids.length() >= 1, "id must not empty");
		List<String> roleIds = Arrays.asList(ids.split(","));
		for (String id : roleIds) {
			RoleInfo role = roleInfoMapper.selectByPrimaryKey(id);
			if (countRoleUsersByRoleId(id) > 0) {
				throw new DMLExecuteException(String.format("%1$s已分配,不能删除", role.getRoleName()));
			}
		}
		RoleInfoExample example = new RoleInfoExample();
		RoleInfoExample.Criteria criteria = example.createCriteria();
		criteria.andIdIn(roleIds);
		roleInfoMapper.deleteByExample(example);
	}

	/**
	 * 通过角色ID查询角色使用数量
	 * 
	 * @param roleId
	 * @return
	 */
	public int countRoleUsersByRoleId(String roleId) {
		UserRoleInfoExample example = new UserRoleInfoExample();
		example.createCriteria().andRoleIdEqualTo(roleId);
		return userRoleInfoMapper.countByExample(example);
	}

	/**
	 * 校验角色名称是否已存在
	 * 
	 * @param role
	 * @return
	 */
	public Boolean checkRoleNameUnique(RoleInfo role) {
		RoleInfoExample example = new RoleInfoExample();
		RoleInfoExample.Criteria criteria = example.createCriteria();
		criteria.andRoleNameEqualTo(role.getRoleName());
		if (StringUtils.isNotBlank(role.getId())) {
			criteria.andIdNotEqualTo(role.getId());
		}
		return roleInfoMapper.countByExample(example) == 0;
	}

	/**
	 * 校验角色KEY是否存在
	 * 
	 * @param role
	 * @return
	 */
	public Boolean checkRoleKeyUnique(RoleInfo role) {
		RoleInfoExample example = new RoleInfoExample();
		RoleInfoExample.Criteria criteria = example.createCriteria();
		criteria.andRoleKeyEqualTo(role.getRoleKey());
		if (StringUtils.isNotBlank(role.getId())) {
			criteria.andIdNotEqualTo(role.getId());
		}
		return roleInfoMapper.countByExample(example) == 0;
	}

	/**
	 * 根据用户ID查询角色信息
	 * 会返回用户所在租户下所有有效角色
	 * 
	 * @param userId
	 * @return
	 */
	public List<RoleInfoModel> selectRolesByUserId(String userId, String deptId) {
		List<RoleInfo> userRoles = selectUserRolesByUserId(userId, deptId);
		RoleInfoQueryModel query = new RoleInfoQueryModel();
		query.setStatus(Constants.COMMON_VALID);
		List<RoleInfo> roleInfos = selectRoleList(query);
		List<RoleInfoModel> roleInfolist = BeanUtils.propertiesCopy(roleInfos, new RoleInfoModel());
		for (RoleInfoModel model : roleInfolist) {
			for (RoleInfo role : userRoles) {
				if (model.getId().equals(role.getId())) {
					model.setFlag(true);
					break;
				}
			}
		}
		return roleInfolist;
	}

	/**
	 * 根据用户ID查询用户角色信息
	 * 
	 * @param userId
	 * @return
	 */
	private List<RoleInfo> selectUserRolesByUserId(String userId, String deptId) {
		Map<String, Object> params = new HashMap<String, Object>();
		if (StringUtils.isNotBlank(userId)) {
			params.put("userId", userId);
		}
		if (StringUtils.isNotBlank(deptId)) {
			params.put("deptId", deptId);
		}
		params.put(Constants.DEL_FLAG, Integer.valueOf(YesOrNoEnum.YES.getCode()));
		params.put("status", Integer.valueOf(YesOrNoEnum.YES.getCode()));
		List<RoleInfo> userRoles = extRoleInfoMapper.selectRolesByUserId(params);
		return userRoles;
	}

	/**
	 * 根据ID集查询角色集，默认支持1000及以内
	 * 
	 * @param ids
	 * @return
	 */
	public List<RoleInfo> selectRolesByIds(List<String> ids) {
		RoleInfoExample example = new RoleInfoExample();
		example.createCriteria().andIdIn(ids);
		return roleInfoMapper.selectByExample(example);
	}

}

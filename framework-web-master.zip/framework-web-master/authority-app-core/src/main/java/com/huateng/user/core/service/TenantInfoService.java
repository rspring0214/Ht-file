package com.huateng.user.core.service;

import java.util.Date;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.alibaba.fastjson.TypeReference;
import com.huateng.base.cache.CacheService;
import com.huateng.base.cache.DeleteCache;
import com.huateng.base.cache.LoadCacheCallback;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.enums.YesOrNoEnum;
import com.huateng.user.core.exception.DuplicateDataException;
import com.huateng.user.dal.dao.TenantInfoMapper;
import com.huateng.user.dal.model.TenantInfo;
import com.huateng.user.dal.model.TenantInfoExample;

/**租户服务
 * @author senvon
 *
 */
@Repository
public class TenantInfoService {

	@Autowired
	private TenantInfoMapper tenantInfoMapper;
	
	@Autowired
	private CacheService cacheService;
	
	public List<TenantInfo> findTanantList(TenantInfo tenantInfo, PageInfo<TenantInfo> page) {
		TenantInfoExample example = new TenantInfoExample();
		TenantInfoExample.Criteria criteria = example.createCriteria();
		if (tenantInfo != null) {
			if (StringUtils.isNotBlank(tenantInfo.getTenantName())) {
				criteria.andTenantNameLike("%" + tenantInfo.getTenantName() + "%");
			}
			if (StringUtils.isNotBlank(tenantInfo.getTenantCode())) {
				criteria.andTenantCodeLike("%" + tenantInfo.getTenantCode() + "%");
			}
		}
		example.setOrderByClause(" CREATE_TIME ASC");
		return tenantInfoMapper.selectByExample(example, page);
	}

	@DeleteCache(key=Constants.TENANT_CACHE_KEY)
	public void saveTenantInfo(TenantInfo tenantInfo) {
		if(tenantInfo != null){
			tenantInfo.setCreateTime(new Date());
			if (tenantInfo.getStatus() == null) {
				tenantInfo.setStatus(Constants.COMMON_VALID);
			}
			if (tenantInfo.getDelFlag() == null) {
				tenantInfo.setDelFlag(Integer.valueOf(YesOrNoEnum.YES.getCode()));
			}
			if(StringUtils.isNotBlank(tenantInfo.getId())){
				//update
				tenantInfo.setUpdateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
				tenantInfoMapper.updateByPrimaryKeySelective(tenantInfo);
			}else {
				tenantInfo.setCreateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
				tenantInfoMapper.insertSelective(tenantInfo);
			}
		}
	}

	public List<TenantInfo> selectCacheTenants(Integer status) {
		return cacheService.getObject(
				Constants.TENANT_CACHE_KEY, 
				new TypeReference<List<TenantInfo>>(){}, 
				60 * 5L, 
				new LoadCacheCallback<List<TenantInfo>>(){

			@Override
			public List<TenantInfo> load() {
				return selectTenants(Integer.valueOf(YesOrNoEnum.YES.getCode()));
			}}
		);
	}
	
	/**
	 * 查询所有有效租户
	 * 
	 * @param status
	 * @return
	 */
	public List<TenantInfo> selectTenants(Integer status) {
		TenantInfoExample example = new TenantInfoExample();
		TenantInfoExample.Criteria criteria = example.createCriteria();
		if (null != status) {
			criteria.andStatusEqualTo(status);
		}
		criteria.andDelFlagEqualTo(Integer.valueOf(YesOrNoEnum.YES.getCode()));
		example.setOrderByClause(" CREATE_TIME ASC");
		return tenantInfoMapper.selectByExample(example);
	}

	/**
	 * 根据主键查询租户
	 * 
	 * @param id
	 * @return
	 */
	public TenantInfo selectByPrimaryKey(String id) {
		return tenantInfoMapper.selectByPrimaryKey(id);
	}

	/**
	 * 根据租户编号查询有效的租户
	 * 
	 * @param tenantCode
	 * @return
	 */
	public TenantInfo selectTenantByCode(String tenantCode) {
		TenantInfoExample example = new TenantInfoExample();
		TenantInfoExample.Criteria criteria = example.createCriteria();
		criteria.andTenantCodeEqualTo(tenantCode);
		criteria.andStatusEqualTo(Constants.COMMON_VALID);
		criteria.andDelFlagEqualTo(Integer.valueOf(YesOrNoEnum.YES.getCode()));
		example.setOrderByClause(" CREATE_TIME ASC");
		List<TenantInfo> list = tenantInfoMapper.selectByExample(example);
		if (CollectionUtils.isEmpty(list)) {
			return null;
		}
		if (list.size() > 1) {
			throw new DuplicateDataException("Found " + list.size() + " tenant info, expected 1");
		}
		
		return list.get(0);
	}
	
	/**
	 * 用户免登陆拦截查询租户
	 * 
	 * @return
	 */
	public List<TenantInfo> selectTenants() {
		return cacheService.getObject(
				Constants.TENANT_CACHE_KEY, 
				new TypeReference<List<TenantInfo>>(){}, 
				60 * 5L, 
				new LoadCacheCallback<List<TenantInfo>>(){

			@Override
			public List<TenantInfo> load() {
				return selectTenants(Constants.COMMON_VALID);
			}}
		);
	}

	/**
	 * 根据ID集合查询租户
	 * 
	 * @param ids
	 * @return
	 */
	public List<TenantInfo> selectTenantsByIds(List<String> ids) {
		TenantInfoExample example = new TenantInfoExample();
		TenantInfoExample.Criteria criteria = example.createCriteria();
		criteria.andIdIn(ids);
		example.setOrderByClause(" CREATE_TIME ASC");
		return tenantInfoMapper.selectByExample(example);
	}

	/**
	 * 检查租户号唯一
	 * 
	 * @param tenant
	 * @return
	 */
	public Boolean checkTenantCodeUnique(TenantInfo tenant) {
		TenantInfoExample example = new TenantInfoExample();
		TenantInfoExample.Criteria criteria = example.createCriteria();
		criteria.andTenantCodeEqualTo(tenant.getTenantCode());
		if (StringUtils.isNotBlank(tenant.getId())) {
			criteria.andIdNotEqualTo(tenant.getId());
		}
		return tenantInfoMapper.countByExample(example) == 0;
	}
	
}

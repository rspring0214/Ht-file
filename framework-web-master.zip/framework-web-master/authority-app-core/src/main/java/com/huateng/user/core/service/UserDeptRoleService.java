/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.api.constants.ExceptionConstants;
import com.huateng.user.api.model.UserRole;
import com.huateng.user.core.exception.DMLExecuteException;
import com.huateng.user.core.model.userDept.UserDeptQueryModel;
import com.huateng.user.core.model.userDept.UserDeptRole;
import com.huateng.user.core.model.userDept.UserDeptRoleBinding;
import com.huateng.user.core.util.BeanUtils;
import com.huateng.user.core.util.ExampleCriteriaUtils;
import com.huateng.user.dal.dao.RoleInfoMapper;
import com.huateng.user.dal.dao.UserRoleInfoMapper;
import com.huateng.user.dal.dao.ext.ExtUserDeptInfoMapper;
import com.huateng.user.dal.model.RoleInfo;
import com.huateng.user.dal.model.RoleInfoExample;
import com.huateng.user.dal.model.UserRoleInfo;
import com.huateng.user.dal.model.UserRoleInfoExample;
import com.huateng.user.dal.model.ext.ExtUserDeptInfo;

/**
 * Description:用户机构/部门角色关系服务
 *
 * @author Heaven.tang
 * @version $Id: UserDeptRoleService.java, v 0.1 2019年8月6日 上午10:35:56 Heaven.tang Exp $
 */
@Repository
public class UserDeptRoleService {

	private static final Logger logger = LoggerFactory.getLogger(UserDeptRoleService.class);
	
	@Autowired
	private UserRoleInfoMapper userRoleInfoMapper;
	
	@Autowired
	private ExtUserDeptInfoMapper extUserDeptInfoMapper;
	
	@Autowired
	private RoleInfoMapper roleInfoMapper;
	
	@Autowired
	private SqlSessionFactory sessionFactory;
	
	/**
	 * 查看一个用户挂职了几个部门
	 * 
	 * @param userId
	 * @return
	 */
	public int countUserDepts(String userId) {
		return extUserDeptInfoMapper.countByUserIdDistinct(userId);
	}
	
	/**
	 * 根据用户机构数据判断是否在机构挂职
	 */
	public boolean userInDept(String userId, String deptId) {
		UserRoleInfoExample example = new UserRoleInfoExample();
		example.createCriteria().andUserIdEqualTo(userId).andDeptIdEqualTo(deptId);
		return userRoleInfoMapper.countByExample(example) > 0;
	}

	/**
	 * 分页查询用户挂职的关联信息
	 * 
	 * @param user
	 * @param page
	 * @param containsSub 是否查询包含子机构中的用户挂职信息，true-是，false-否
	 * @return
	 */
	public List<UserDeptRole> selectUserDeptRolesByPage(UserDeptQueryModel user, PageInfo<UserDeptRole> page, boolean containsSub) {
		List<UserDeptRole> list = new ArrayList<UserDeptRole>();
		PageInfo<ExtUserDeptInfo> pageInfo = new PageInfo<ExtUserDeptInfo>();
		pageInfo.setCurrent(page.getCurrent());
		pageInfo.setLimit(page.getLimit());
		pageInfo.setNeedCount(page.isNeedCount());
		List<ExtUserDeptInfo> userDepts = null;
		if (containsSub) {
			userDepts= extUserDeptInfoMapper.queryWithSubByPage(BeanUtils.propertiesCopyToMap(user, ""), pageInfo);
		} else {
			userDepts = extUserDeptInfoMapper.queryByPage(BeanUtils.propertiesCopyToMap(user, ""), pageInfo);
		}
		if (CollectionUtils.isNotEmpty(userDepts)) {
			list = new ArrayList<UserDeptRole>(userDepts.size());
			for (ExtUserDeptInfo extUserDeptInfo : userDepts) {
				UserDeptRole udr = new UserDeptRole();
				udr.setUserDept(extUserDeptInfo);
				List<String> roleIds = extUserDeptInfoMapper.queryRoleIds(BeanUtils.propertiesCopyToMap(extUserDeptInfo, "userName", "deptName"));
				// 认为不可能超过1000
				RoleInfoExample example = new RoleInfoExample();
				example.createCriteria().andIdIn(roleIds);
				example.setOrderByClause(" ID ASC");
				List<RoleInfo> roleList = roleInfoMapper.selectByExample(example);
				List<UserRole> roles = BeanUtils.propertiesCopy(roleList, new UserRole());
				udr.setRoles(roles);
				list.add(udr);
			}
		}
		page.setData(list);
		page.setTotalPage(pageInfo.getTotalPage());
		page.setTotalRecord(pageInfo.getTotalRecord());
		return list;
	}

	/**
	 * 保存绑定数据
	 * 
	 * @param data
	 */
	@Transactional
	public void saveBinding(UserDeptRoleBinding data) {
		// 1.删除用户某机构下的角色绑定
		UserRoleInfoExample example = new UserRoleInfoExample();
		UserRoleInfoExample.Criteria criteria = example.createCriteria();
		ExampleCriteriaUtils.criteriaEqualsSet(criteria, data, "roleIds");
		userRoleInfoMapper.deleteByExample(example);
		// 2.新增绑定
		bindingData(data);
	}

	private void bindingData(UserDeptRoleBinding data) {
		if (null == data.getRoleIds() || data.getRoleIds().length == 0) {
			return;
		}
		int num = 0;
		try {
			num = insertData(data);
		} catch (Exception e) {
			logger.error("User binding dept and role insert exception ", e);
			throw new DMLExecuteException(ExceptionConstants.DATA_INSERT_EXCEPTION_MESSAGE);
		}
		if (num != data.getRoleIds().length) {
			logger.error("User binding dept and role insert failed, expect {}, but {}", data.getRoleIds().length, num);
			throw new DMLExecuteException(ExceptionConstants.DATA_INSERT_EXCEPTION_MESSAGE);
		}
	}

	private int insertData(UserDeptRoleBinding data) throws Exception {
		int rows = 0;
		SqlSession session = sessionFactory.openSession(ExecutorType.BATCH);
		UserRoleInfoMapper mapper = session.getMapper(UserRoleInfoMapper.class);
		for (String roleId : data.getRoleIds()) {
			UserRoleInfo up = new UserRoleInfo();
			up.setUserId(data.getUserId());
			up.setDeptId(data.getDeptId());
			up.setRoleId(roleId);
			mapper.insertSelective(up);
			rows++;
		}
		session.flushStatements();
		return rows;
	}

	public void delete(String userId, String deptId) {
		UserRoleInfoExample example = new UserRoleInfoExample();
		example.createCriteria().andUserIdEqualTo(userId).andDeptIdEqualTo(deptId);
		userRoleInfoMapper.deleteByExample(example);
	}

	/**
	 * 查询用户任职的机构
	 * 
	 * @param userId
	 * @return
	 */
	public List<String> selectDistinctUserDept(String userId) {
		return extUserDeptInfoMapper.selectDistinctUserDept(userId);
	}

}

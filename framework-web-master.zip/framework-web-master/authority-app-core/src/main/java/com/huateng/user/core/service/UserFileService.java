package com.huateng.user.core.service;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.alibaba.fastjson.JSONObject;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.api.enums.YesOrNoEnum;
import com.huateng.user.core.exception.DMLExecuteException;
import com.huateng.user.dal.dao.UserFileInfoMapper;
import com.huateng.user.dal.model.UserFileInfo;
import com.huateng.user.dal.model.UserFileInfoExample;
import com.huateng.user.dal.model.UserFileInfoExample.Criteria;

@Repository
public class UserFileService {

	private static final Logger logger = LoggerFactory.getLogger(UserFileService.class);
	
	@Autowired
	private UserFileInfoMapper mapper;	
	
	public void saveFileInfo(UserFileInfo userFileInfo){
		userFileInfo.setCreateTime(new Date());
		userFileInfo.setDelFlag(Integer.valueOf(YesOrNoEnum.YES.getCode()));
		int num = mapper.insertSelective(userFileInfo);
		if (num != 1) {
			logger.error("userFile info insert failed, expect 1, but {}, user {}", num, JSONObject.toJSONString(userFileInfo));
			throw new DMLExecuteException("数据保存记录异常");
		}
	}
	
	public UserFileInfo queryFileInfo(String id){
		return mapper.selectByPrimaryKey(id);
	}
	
	/**
	 * 分页查询
	 * 
	 * @param post
	 * @param page
	 */
	public List<UserFileInfo> selectFileListByPage(UserFileInfo info, PageInfo<UserFileInfo> page) {
		UserFileInfoExample example = new UserFileInfoExample();
		Criteria c = example.createCriteria();
		if (StringUtils.isNotBlank(info.getId())) {
			c.andIdEqualTo(info.getId());
		}
		if (StringUtils.isNotBlank(info.getName())) {
			c.andNameLike("%" + info.getName() + "%");
		}
		if (StringUtils.isNotBlank(info.getType())) {
			c.andTypeLike("%" + info.getType() + "%");
		}
		return mapper.selectByExample(example, page);
	}
	
	public int deletFileById(String id) {
		return mapper.deleteByPrimaryKey(id);
	}
}

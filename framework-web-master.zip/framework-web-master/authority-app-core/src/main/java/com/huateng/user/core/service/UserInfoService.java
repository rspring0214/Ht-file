package com.huateng.user.core.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSONObject;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.constants.ExceptionConstants;
import com.huateng.user.api.enums.YesOrNoEnum;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.api.utils.UserUtils;
import com.huateng.user.core.exception.DMLExecuteException;
import com.huateng.user.core.exception.DataNotFoundException;
import com.huateng.user.core.exception.DuplicateDataException;
import com.huateng.user.core.exception.IllegalParamException;
import com.huateng.user.core.model.userInfo.UserInfoQueryModel;
import com.huateng.user.core.util.Assembler;
import com.huateng.user.core.util.BeanUtils;
import com.huateng.user.core.util.HTDateUtils;
import com.huateng.user.core.util.MD5Utils;
import com.huateng.user.dal.dao.PasswordRecordMapper;
import com.huateng.user.dal.dao.TenantInfoMapper;
import com.huateng.user.dal.dao.UserInfoMapper;
import com.huateng.user.dal.dao.UserPostInfoMapper;
import com.huateng.user.dal.dao.UserRoleInfoMapper;
import com.huateng.user.dal.dao.ext.ExtUserInfoMapper;
import com.huateng.user.dal.model.PasswordRecord;
import com.huateng.user.dal.model.PasswordRecordExample;
import com.huateng.user.dal.model.TenantInfo;
import com.huateng.user.dal.model.TenantInfoExample;
import com.huateng.user.dal.model.UserInfo;
import com.huateng.user.dal.model.UserInfoExample;
import com.huateng.user.dal.model.UserPostInfo;
import com.huateng.user.dal.model.UserPostInfoExample;
import com.huateng.user.dal.model.UserRoleInfo;
import com.huateng.user.dal.model.UserRoleInfoExample;
import com.huateng.user.dal.model.ext.ExtUserDeptInfo;
import com.huateng.user.dal.model.ext.ExtUserInfo;

@Repository
public class UserInfoService {

	private static final Logger logger = LoggerFactory.getLogger(UserInfoService.class);
	
	@Autowired
	private UserInfoMapper userInfoMapper;
	
	@Autowired
	private UserRoleInfoMapper userRoleInfoMapper;
	
	@Autowired
	private UserPostInfoMapper userPostInfoMapper;
	
	@Autowired
	private ExtUserInfoMapper extUserInfoMapper;
	
	@Autowired
	private TenantInfoMapper tenantInfoMapper;
	
	@Autowired
	private SqlSessionFactory sessionFactory;
	
	@Autowired
	private PasswordRecordMapper passwordRecordMapper;
	
	@Autowired
	private DeptInfoService deptInfoService;
	
	@Value("${password.inspire.times:24}")
	private Integer passwordInspireTimes;

	/**
	 * 根据参数分页查询用户信息
	 * 
	 * @param user
	 * @param page
	 * @return
	 */
	public List<ExtUserInfo> selectUserListByPage4Admin(UserInfoQueryModel user, PageInfo<ExtUserInfo> page) {
		Map<String, Object> params = BeanUtils.propertiesCopyToMap(user);
		params.put("superUser", Constants.SUPER_USER_NAME);
		if (StringUtils.isNotBlank(user.getBeginTime())) {
			params.put(Constants.TIME_SCOPE_BEGIN, HTDateUtils.parseDate(user.getBeginTime()));
		}
		if (StringUtils.isNotBlank((String) user.getEndTime())) {
			params.put(Constants.TIME_SCOPE_END, HTDateUtils.parseDate(user.getEndTime()));
		}
		if (StringUtils.isNotBlank(user.getDeptId())) {
//			params.put("deptId", user.getDeptId());
		}
		params.remove("deptId");
		
//		SSOUser u = SSOClientUtils.getInstance().findCurrentUser();
//		List<String> ids = new ArrayList<String>();
//		deptInfoService.getChildrenId(Arrays.asList(new String[]{u.getLoginDept().getId()}), ids);
//		ids.add(u.getLoginDept().getId());
		
//		String[] pa = user.getDeptIds().split(",");
//		ids.removeAll(Arrays.asList(pa));
		
//		StringBuilder sb = new StringBuilder();
//		for(String id : ids){
//			sb.append(id + ",")
//		}
		
		if (StringUtils.isNotBlank(user.getDeptIds())) {
			params.put("deptIds", user.getDeptIds().split(","));
		}
		params.put(Constants.DEL_FLAG, Integer.valueOf(YesOrNoEnum.YES.getCode()));
		return extUserInfoMapper.selectUserListByPage(params, page);
	}
	/**
	 * 根据参数分页查询用户信息
	 * 
	 * @param user
	 * @param page
	 * @return
	 */
	public List<ExtUserInfo> selectUserListByPage(UserInfoQueryModel user, PageInfo<ExtUserInfo> page) {
		Map<String, Object> params = BeanUtils.propertiesCopyToMap(user);
		params.put("superUser", Constants.SUPER_USER_NAME);
		if (StringUtils.isNotBlank(user.getBeginTime())) {
			params.put(Constants.TIME_SCOPE_BEGIN, HTDateUtils.parseDate(user.getBeginTime()));
		}
		if (StringUtils.isNotBlank((String) user.getEndTime())) {
			params.put(Constants.TIME_SCOPE_END, HTDateUtils.parseDate(user.getEndTime()));
		}
		if (StringUtils.isNotBlank(user.getDeptId())) {
//			params.put("deptId", user.getDeptId());
		}
		params.remove("deptId");

		SSOUser u = SSOClientUtils.getInstance().findCurrentUser();
		List<String> ids = new ArrayList<String>();
		deptInfoService.getChildrenId(Arrays.asList(new String[]{u.getLoginDept().getId()}), ids);
		ids.add(u.getLoginDept().getId());
		params.put("deptIds", ids.toArray());
	
//		String[] pa = user.getDeptIds().split(",");
//		ids.removeAll(Arrays.asList(pa));
		
//		StringBuilder sb = new StringBuilder();
//		for(String id : ids){
//			sb.append(id + ",")
//		}
		
		if (StringUtils.isNotBlank(user.getDeptIds())) {
			
			params.put("deptIds", user.getDeptIds().split(","));
			
			
		}
		
		// 1,2,3,4   1
		
		params.put(Constants.DEL_FLAG, Integer.valueOf(YesOrNoEnum.YES.getCode()));
		return extUserInfoMapper.selectUserListByPage(params, page);
	}

	/**
	 * 新增用户
	 * 
	 * @param user
	 */
	@Transactional
	public void insertUser(ExtUserInfo user) {
		// 新增用户信息
		insertUserInfo(user);
		// 新增用户岗位关联
		insertUserPosts(user.getId(), Arrays.asList(user.getPostIds()));
		// 新增用户与角色管理
		insertUserRoles(user.getId(), Arrays.asList(user.getRoleIds()), user.getDeptId());
	}

	private void insertUserInfo(UserInfo user) {
		// 没有值的时候设置默认值
		user.setCreateTime(new Date());
		user.setDelFlag(Integer.valueOf(YesOrNoEnum.YES.getCode()));
		int num = userInfoMapper.insertSelective(user);
		if (num != 1) {
			logger.error("Data user insert failed, expect 1, but {}, user {}", num, JSONObject.toJSONString(user));
			throw new DMLExecuteException("数据保存记录异常");
		}
	}
	
	private void insertUserPosts(String userId, List<String> postIds) {
		int num = 0;
		try {
			num = insertUserPost(userId, postIds);
		} catch (Exception e) {
			logger.error("Data user post insert exception ", e);
			throw new DMLExecuteException(ExceptionConstants.DATA_INSERT_EXCEPTION_MESSAGE);
		}
		if (num != postIds.size()) {
			logger.error("Data user post insert failed, expect 1, but {}", num);
			throw new DMLExecuteException(ExceptionConstants.DATA_INSERT_EXCEPTION_MESSAGE);
		}
	}
	
	private void insertUserRoles(String userId, List<String> roleIds, String deptId) {
		int num = 0;
		try {
			num = insertUserRole(userId, roleIds, deptId);
		} catch (Exception e) {
			logger.error("Data user role insert exception ", e);
			throw new DMLExecuteException(ExceptionConstants.DATA_INSERT_EXCEPTION_MESSAGE);
		}
		if (num != roleIds.size()) {
			logger.error("Data user role insert failed, expect 1, but {}", num);
			throw new DMLExecuteException(ExceptionConstants.DATA_INSERT_EXCEPTION_MESSAGE);
		}
	}

	/**
	 * 新增用户岗位关联
	 * 
	 * @param userId
	 * @param postIds
	 * @return
	 * @throws Exception 
	 */
	private int insertUserPost(String userId, List<String> postIds) throws Exception {
		if (CollectionUtils.isEmpty(postIds)) {
			return 0;
		}
		int rows = 0;
		SqlSession session = sessionFactory.openSession(ExecutorType.BATCH);
		UserPostInfoMapper mapper = session.getMapper(UserPostInfoMapper.class);
		for (String postId : postIds) {
			UserPostInfo up = new UserPostInfo();
			up.setUserId(userId);
			up.setPostId(postId);
			mapper.insertSelective(up);
			rows++;
		}
		session.flushStatements();
		return rows;
	}
	
	/**
	 * 新增机构用户与角色管理
	 * 
	 * @param userId
	 * @param roleIds
	 * @param deptId
	 * @return
	 * @throws Exception 
	 */
	private int insertUserRole(String userId, List<String> roleIds, String deptId) throws Exception {
		if (CollectionUtils.isEmpty(roleIds)) {
			return 0;
		}
		int rows = 0;
		SqlSession session = sessionFactory.openSession(ExecutorType.BATCH);
		UserRoleInfoMapper mapper = session.getMapper(UserRoleInfoMapper.class);
		for (String roleId : roleIds) {
			UserRoleInfo up = new UserRoleInfo();
			up.setUserId(userId);
			up.setRoleId(roleId);
			up.setDeptId(deptId);
			mapper.insertSelective(up);
			rows++;
		}
		session.flushStatements();
		return rows;
	}

	/**
	 * 根据ID查询用户详细信息
	 * 
	 * @param id
	 * @return
	 */
	public ExtUserInfo selectUserDetailsById(String id) {
		return extUserInfoMapper.selectUserDetailsById(id);
	}

	/**
	 * 更新用户信息
	 * 
	 * @param user
	 */
	@Transactional
	public void updateUser(ExtUserInfo user) {
		String userId = user.getId();
		// 删除用户与角色关联
		UserRoleInfoExample urExample = new UserRoleInfoExample();
		UserRoleInfoExample.Criteria criteria = urExample.createCriteria();
		criteria.andUserIdEqualTo(userId);
		criteria.andDeptIdEqualTo(user.getDeptId());
		userRoleInfoMapper.deleteByExample(urExample);
		// 新增用户与角色管理
		insertUserRoles(user.getId(), Arrays.asList(user.getRoleIds()), user.getDeptId());
		// 删除用户与岗位关联
		UserPostInfoExample upExample = new UserPostInfoExample();
		upExample.createCriteria().andUserIdEqualTo(userId);
		userPostInfoMapper.deleteByExample(upExample);
		// 新增用户与岗位管理
		insertUserPosts(user.getId(), Arrays.asList(user.getPostIds()));
		UserInfo record = BeanUtils.propertiesCopy(user, new UserInfo());
		int num = userInfoMapper.updateByPrimaryKeySelective(record);
		if (num != 1) {
			logger.error("Data user update failed, expect 1, but {}, id {}", num, record.getId());
			throw new DMLExecuteException(ExceptionConstants.DATA_INSERT_EXCEPTION_MESSAGE);
		}
	}

	/**
	 * 根据主键查询用户信息
	 * 
	 * @param id
	 * @return
	 */
	public UserInfo selectUserById(String id) {
		return userInfoMapper.selectByPrimaryKey(id);
	}

	/**
	 * 批量删除用户
	 * 
	 * @param ids
	 */
	@Transactional
	public void deleteUserByIds(List<String> ids) {
		if (CollectionUtils.isEmpty(ids)) {
			return;
		}
		UserInfoExample example = new UserInfoExample();
		example.createCriteria().andIdIn(ids);
		userInfoMapper.deleteByExample(example);
		// 逻辑密码记录
		PasswordRecordExample prExample = new PasswordRecordExample();
		prExample.createCriteria().andUserIdIn(ids);
		passwordRecordMapper.deleteByExample(prExample);
		// 删除用户与角色关联
		UserRoleInfoExample urExample = new UserRoleInfoExample();
		urExample.createCriteria().andUserIdIn(ids);
		userRoleInfoMapper.deleteByExample(urExample);
		// 删除用户与岗位关联
		UserPostInfoExample upExample = new UserPostInfoExample();
		upExample.createCriteria().andUserIdIn(ids);
		userPostInfoMapper.deleteByExample(upExample);
	}

	/**
	 * 检查登录用户名是否唯一
	 * 
	 * @param user
	 * @return
	 */
	public Boolean checkLoginNameUnique(UserInfo user) {
		UserInfoExample example = new UserInfoExample();
		UserInfoExample.Criteria criteria = example.createCriteria();
		criteria.andLoginNameEqualTo(user.getLoginName());
		if (StringUtils.isNotBlank(user.getId())) {
			criteria.andIdNotEqualTo(user.getId());
		}
		return userInfoMapper.countByExample(example) == 0;
	}

	/**
	 * 检查电话号是否唯一
	 * 
	 * @param user
	 * @return
	 */
	public Boolean checkPhoneUnique(UserInfo user) {
		UserInfoExample example = new UserInfoExample();
		UserInfoExample.Criteria criteria = example.createCriteria();
		criteria.andPhoneNumberEqualTo(user.getPhoneNumber());
		if (StringUtils.isNotBlank(user.getId())) {
			criteria.andIdNotEqualTo(user.getId());
		}
		return userInfoMapper.countByExample(example) == 0;
	}
	
	/**
	 * 检查邮箱是否唯一
	 * 
	 * @param user
	 * @return
	 */
	public Boolean checkEmailUnique(UserInfo user) {
		UserInfoExample example = new UserInfoExample();
		UserInfoExample.Criteria criteria = example.createCriteria();
		criteria.andEmailEqualTo(user.getEmail());
		if (StringUtils.isNotBlank(user.getId())) {
			criteria.andIdNotEqualTo(user.getId());
		}
		return userInfoMapper.countByExample(example) == 0;
	}

	/**
	 * 修改用户信息
	 * 
	 * @param user
	 */
	public int updateUser(UserInfo user) {
		user.setUpdateTime(new Date());
		return userInfoMapper.updateByPrimaryKeySelective(user);
	}

	/**
	 * 根据租户号和用户名查询用户信息，理论上只有一个
	 * 
	 * @param tenantCode 租户号
	 * @param userName 登录名
	 * @return
	 */
	public List<UserInfo> selectUserByKeyCode(String tenantCode, String userName) {
		UserInfoExample example = new UserInfoExample();
		UserInfoExample.Criteria criteria = example.createCriteria();
		if (StringUtils.isNotBlank(tenantCode) && !StringUtils.equals(Constants.SUPER_USER_NAME, userName)) {
			// 查询tenantId
			TenantInfoExample tiExample = new TenantInfoExample();
			tiExample.createCriteria().andTenantCodeEqualTo(tenantCode);
			List<TenantInfo> tiList = tenantInfoMapper.selectByExample(tiExample);
			if (!CollectionUtils.isEmpty(tiList) && tiList.size() == 1) {
				criteria.andTenantIdEqualTo(tiList.get(0).getId());
			} else {
				logger.error("Duplicate tenantInfo, tenantCode : {}", tenantCode);
				throw new DuplicateDataException("租户号异常");
			}
		}
		if (StringUtils.isNotBlank(userName)) {
			criteria.andLoginNameEqualTo(userName);
		}
		return userInfoMapper.selectByExample(example);
	}
	
	/**
	 * 根据租户ID和用户名查询用户信息，理论上只有一个
	 * 
	 * @param tenantId 租户ID
	 * @param userName 登录名
	 * @return
	 */
	public List<UserInfo> selectUserByKeyId(String tenantId, String userName) {
		UserInfoExample example = new UserInfoExample();
		UserInfoExample.Criteria criteria = example.createCriteria();
		if (StringUtils.isNotBlank(tenantId)) {
			criteria.andTenantIdEqualTo(tenantId);
		}
		if (StringUtils.isNotBlank(userName)) {
			criteria.andLoginNameEqualTo(userName);
		}
		return userInfoMapper.selectByExample(example);
	}
	
	/**
	 * 校验密码，已知用户ID，方便内部使用，通过之后返回用户信息
	 * 
	 * @param userId
	 * @param password
	 * @return
	 */
	public UserInfo checkPassword(String userId, String password) {
		UserInfo user = userInfoMapper.selectByPrimaryKey(userId);
		if (null == user) {
			logger.error("User not found, id : {}", userId);
			throw new DataNotFoundException(ExceptionConstants.USER_NOT_EXISTS_EXCEPTION_MESSAGE);
		}
		String key = user.getLoginName() + password;
        if (StringUtils.isNotBlank(user.getSalt())) {
        	key = key + user.getSalt();
        }
        return MD5Utils.verifySaltMD5(key, user.getPassword()) ? user : null;
	}

	/**
	 * 修改密码，修改密码并且添加密码记录
	 * 
	 * @param user
	 * @param confirmNewPassword
	 */
	@Transactional
	public void changePassword(UserInfo user, String confirmNewPassword) {
		if (null == user || StringUtils.isBlank(user.getId())) {
			throw new IllegalParamException("userId must not be blank");
		}
		UserInfo record = new UserInfo();
		record.setLoginName(user.getLoginName());
		record.setSalt(MD5Utils.genSalt());
		record.setPassword(confirmNewPassword);
		record.setPassword(MD5Utils.genSaltMD5(UserUtils.createPasswdKey(record.getLoginName(), record.getPassword(), record.getSalt())));
		record.setUpdateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
		record.setLoginName(null);
		int rst = updateUserPassword(user, record);
		if (rst != 1) {
			logger.error("Update password failed, excepte one but {}", rst);
			throw new DMLExecuteException(ExceptionConstants.DATA_UPDATE_EXCEPTION_MESSAGE);
		}
		record.setId(user.getId());
		rst = savePasswordRecord(Assembler.buildPasswordRecord(record));
		if (rst != 1) {
			logger.error("Update password failed, excepte one but {}", rst);
			throw new DMLExecuteException(ExceptionConstants.DATA_UPDATE_EXCEPTION_MESSAGE);
		}
	}

	/**
	 * 根据ID和原密码修改密码
	 * 
	 * @param user
	 * @param record
	 * @return
	 */
	private int updateUserPassword(UserInfo user, UserInfo record) {
		UserInfoExample example = new UserInfoExample();
		UserInfoExample.Criteria criteria = example.createCriteria();
		criteria.andIdEqualTo(user.getId());
		criteria.andPasswordEqualTo(user.getPassword());
		return userInfoMapper.updateByExampleSelective(record, example);
	}

	/**
	 * 保存密码记录
	 * 
	 * @param record
	 */
	public int savePasswordRecord(PasswordRecord record) {
		record.setCreateTime(new Date());
		record.setUpdateTime(new Date());
		record.setExpireTime(HTDateUtils.addHours(new Date(), passwordInspireTimes));
		if (StringUtils.isBlank(record.getId())) {
			return passwordRecordMapper.insertSelective(record);
		} else {
			return passwordRecordMapper.updateByPrimaryKeySelective(record);
		}
	}

	/**
	 * 根据状态查询用户
	 * 
	 * @param status
	 * @return
	 */
	public List<UserInfo> selectUserListByStatus(Integer status) {
		UserInfoExample example = new UserInfoExample();
		example.createCriteria().andStatusEqualTo(status);
		return userInfoMapper.selectByExample(example);
	}

	/**
	 * 查询可解锁的锁定用户
	 * 
	 * @param lockTime
	 * @return
	 */
	public List<UserInfo> selectLockedUsers(Integer lockTime) {
		UserInfoExample example = new UserInfoExample();
		UserInfoExample.Criteria criteria = example.createCriteria();
		criteria.andStatusEqualTo(Constants.COMMON_INVALID);
		criteria.andUpdateTimeLessThan(HTDateUtils.addMinutes(new Date(), -lockTime));
		example.setOrderByClause(" CREATE_TIME ASC");
		return userInfoMapper.selectByExample(example);
	}

	/**
	 * 查询机构及子机构下的用户
	 * 
	 * @param deptId
	 * @param status
	 * @return
	 */
	public List<UserInfo> selectUsersWithSubDept(String deptId, Integer status) {
		Map<String, Object> params = new HashMap<String, Object>(4);
		if (StringUtils.isNotBlank(deptId)) {
			params.put("deptId", deptId);
		}
		if (null != status) {
			params.put("status", status);
		}
		params.put("superUser", Constants.SUPER_USER_NAME);
		params.put(Constants.DEL_FLAG, Integer.valueOf(YesOrNoEnum.YES.getCode()));
		return extUserInfoMapper.selectUserList(params);
	}

	/**
	 * 根据参数分页查询用户信息，只查询用户ID和名称，所属机构ID和名称
	 * 
	 * @param user
	 * @param page
	 */
	public List<ExtUserDeptInfo> selectUserDeptListByPage(UserInfoQueryModel user, PageInfo<ExtUserDeptInfo> page) {
		Map<String, Object> params = BeanUtils.propertiesCopyToMap(user);
		params.put("superUser", Constants.SUPER_USER_NAME);
		if (StringUtils.isNotBlank(user.getBeginTime())) {
			params.put(Constants.TIME_SCOPE_BEGIN, HTDateUtils.parseDate(user.getBeginTime()));
		}
		if (StringUtils.isNotBlank((String) user.getEndTime())) {
			params.put(Constants.TIME_SCOPE_END, HTDateUtils.parseDate(user.getEndTime()));
		}
		if (StringUtils.isNotBlank(user.getDeptId())) {
			params.put("deptId", user.getDeptId());
		}
		params.put(Constants.DEL_FLAG, Integer.valueOf(YesOrNoEnum.YES.getCode()));
		return extUserInfoMapper.selectUserDeptListByPage(params, page);
	}

}

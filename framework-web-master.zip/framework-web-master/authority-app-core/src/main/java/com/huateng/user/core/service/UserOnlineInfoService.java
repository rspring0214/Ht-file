package com.huateng.user.core.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.api.utils.UserUtils;
import com.huateng.user.core.util.HTDateUtils;
import com.huateng.user.dal.dao.UserOnlineInfoMapper;
import com.huateng.user.dal.model.DeptInfo;
import com.huateng.user.dal.model.UserOnlineInfo;
import com.huateng.user.dal.model.UserOnlineInfoExample;

@Repository("UserOnlineInfoService")
public class UserOnlineInfoService {

	@Autowired
	private UserOnlineInfoMapper mapper;
	
	@Autowired
	private DeptInfoService deptService;
	
	@Value("${sso.token.expire.time:1800}")
	private Integer sessionExpireSecond;
	
	public void saveUserOnlineInfo(UserOnlineInfo userOnline){
		UserOnlineInfoExample example = new UserOnlineInfoExample();
		UserOnlineInfoExample.Criteria criteria = example.createCriteria();
		
		criteria.andSessionIdEqualTo(userOnline.getSessionId());
		
		List<UserOnlineInfo> onlineInfoList = mapper.selectByExample(example);
		
		if(onlineInfoList != null && onlineInfoList.size()>0){
			userOnline.setId(onlineInfoList.get(0).getId());
			userOnline.setLastAccessTime(new Date());
			Date exExpireTime = HTDateUtils.addTime(new Date(), Calendar.SECOND, sessionExpireSecond);
			userOnline.setExExpireTime(exExpireTime);
			mapper.updateByPrimaryKeySelective(userOnline);
		}else{
			mapper.insertSelective(userOnline);
		}
	}
	
	public void updateAccessTimeBySessionId(String sessionId){
		UserOnlineInfoExample example = new UserOnlineInfoExample();
		UserOnlineInfoExample.Criteria criteria = example.createCriteria();
		
		criteria.andSessionIdEqualTo(sessionId);
		
		UserOnlineInfo record = new UserOnlineInfo();
		record.setLastAccessTime(new Date());
		Date exExpireTime = HTDateUtils.addTime(new Date(), Calendar.SECOND, sessionExpireSecond);
		record.setExExpireTime(exExpireTime);
		
		mapper.updateByExampleSelective(record, example);
	}
	
	public int clearExpireSession(){
		UserOnlineInfoExample example = new UserOnlineInfoExample();
		UserOnlineInfoExample.Criteria criteria = example.createCriteria();
		criteria.andExExpireTimeLessThanOrEqualTo(new Date());
		return mapper.deleteByExample(example);
	}
	
	public List<UserOnlineInfo> search(String loginName, String deptName, String ipaddr, PageInfo<UserOnlineInfo> pageInfo){
		UserOnlineInfoExample example = new UserOnlineInfoExample();
		UserOnlineInfoExample.Criteria criteria = example.createCriteria();

		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		if (!UserUtils.isAdmin(user)) {
			List<DeptInfo> depts = deptService.selectDeptList();
			List<String> ids = new ArrayList<String>(10);
			for (DeptInfo dept : depts) {
				ids.add(dept.getId());
			}
			criteria.andDeptIdIn(ids);
		}
		if (StringUtils.isNotBlank(deptName)) {
			criteria.andDeptNameLike("%" + deptName + "%");
		}
		if (StringUtils.isNotBlank(ipaddr)) {
			criteria.andIpaddrLike("%" + ipaddr + "%");
		}
		if (StringUtils.isNotBlank(loginName)) {
			criteria.andLoginNameLike("%" + loginName + "%");
		}
		criteria.andSessionIdNotEqualTo(user.getToken());
		example.setOrderByClause(" LAST_ACCESS_TIME DESC");
		return mapper.selectByExample(example, pageInfo);
	}
	
	/**在经过check以后的sessionId,如果在缓存里面不存在,则进行删除
	 * 
	 * @param sessionId
	 */
	public void remveUserOnlineInfo(String... sessionId){
		if(sessionId != null){
			UserOnlineInfoExample example = new UserOnlineInfoExample();
			UserOnlineInfoExample.Criteria criteria = example.createCriteria();
			
			criteria.andSessionIdIn(Arrays.asList(sessionId));
			mapper.deleteByExample(example);
		}
	}

	/**
	 * 根据时间范围和状态查询
	 * 
	 * @param less
	 * @param greater
	 * @param status
	 * @return
	 */
	public List<UserOnlineInfo> selectUserOnline(Integer less, Integer greater, List<Integer> status) {
		UserOnlineInfoExample example = new UserOnlineInfoExample();
		UserOnlineInfoExample.Criteria criteria = example.createCriteria();
		Date greaterThan = null;
		Date lessThan = null;
		if (null != less) {
			greaterThan = HTDateUtils.addTime(new Date(), Calendar.MINUTE, less);
			criteria.andLastAccessTimeGreaterThanOrEqualTo(greaterThan);
		}
		if (null != greater) {
			lessThan = HTDateUtils.addTime(new Date(), Calendar.MINUTE, greater);
			criteria.andLastAccessTimeLessThan(lessThan);
		}
		if (CollectionUtils.isNotEmpty(status)) {
			if (status.size() == 1) {
				criteria.andStatusEqualTo(status.get(0));
			} else {
				criteria.andStatusIn(status);
			}
		}
		return mapper.selectByExample(example);
	}
}

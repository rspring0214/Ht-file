/**
 * Copyright (c) 2018 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.task;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.huateng.base.task.service.AtomicTaskService;
import com.huateng.base.task.vo.TaskExecContext;
import com.huateng.base.task.vo.TaskExecResult;
import com.huateng.base.task.vo.TaskResult;
import com.huateng.user.core.enums.InvokeTypeEnum;

/**
 * Description:抽象类，用户注入使用的Bean
 *
 * @author Heaven.tang
 * @version $Id: AbstractAtomicTask.java, v 0.1 2018年5月10日 下午4:53:04 Heaven.tang Exp $
 */
public abstract class AbstractAtomicTask {
	
	private static final Logger logger = LoggerFactory.getLogger(AbstractAtomicTask.class);

	@Autowired
	protected AtomicTaskService atomicTaskService;
	
	@Value("${user.complement:true}")
	private Boolean complement;
	
	public void add() {
		if (complement) {
			addTask();
		}
	}
	
	/**
	 * 添加atomic-task
	 */
	public abstract void addTask();
	
	/**
	 * 添加并发起执行任务的实现
	 * 
	 * @param taskNo 任务编号
	 * @param taskEnum 任务类型
	 * @param invokeTypeEnum 同步/异步
	 */
	protected void addExecute(String taskNo, AtomicTaskEnum taskEnum, InvokeTypeEnum invokeTypeEnum) {
		// 先查询任务是否已存在
		TaskResult taskResult = atomicTaskService.getAtomicTask(taskEnum.getTaskType(), taskNo);
		if (null == taskResult) {
			try {
				atomicTaskService.addAtomicTask(
						taskEnum.getTaskType(), 
						taskNo, 
						taskEnum.getTaskCallback(), 
						null, 
						taskEnum.getFirstDelay(), 
						taskEnum.getExpire(), 
						taskEnum.getExecTime());
				if (invokeTypeEnum == InvokeTypeEnum.SYNC) {
					atomicTaskService.syncExecuteTask(taskEnum.getTaskType(), taskNo);
				} else {
					atomicTaskService.asynExecuteTask(taskEnum.getTaskType(), taskNo);
				}
			} catch (Exception e) {
				logger.info("任务：" + taskNo + " 异常... cause:{}", e.getMessage());
				e.printStackTrace();
			}
		} else if (taskResult.isComplete()) {
			logger.info("任务：" + taskNo + " 已完成...");
		} else {
			logger.info("任务：" + taskNo + " 处理中...");
		}
	}
	
	/**
	 * atomic-task执行业务
	 */
	public abstract TaskExecResult execute(TaskExecContext context);
}

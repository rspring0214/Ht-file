/**
 * Copyright (c) 2017 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.task;

/**
 * Description:task使用枚举
 *
 * @author Heaven.tang
 * @version $Id: AtomicTaskEnum.java, v 0.1 2018年5月10日17:05:07 Heaven.tang Exp $
 */
public enum AtomicTaskEnum {

	/** 流程中断补单 */
	ONLINE_EXPIRE_COMPLEMENT("ONLINE_EXPIRE_COMPLEMENT", "spring:OnlineExpireComplementTask.execute", 1, 30, 1),
	/** 用户自动解锁 */
	AUTO_UNLOCK_USER("AUTO_UNLOCK_USER", "spring:AutoUnlockUserTask.execute", 1, 30, 1),
	
	;
	// 任务类型
	private String taskType;
	// 回调方法
	private String taskCallback;
	// 第一次执行延迟
	private Integer firstDelay;
	// 执行超时时间
	private Integer expire;
	// 重试次数
	private Integer execTime;

	private AtomicTaskEnum(String taskType, String taskCallback, Integer firstDelay, Integer expire, Integer execTime) {
		this.taskType = taskType;
		this.taskCallback = taskCallback;
		this.firstDelay = firstDelay;
		this.expire = expire;
		this.execTime = execTime;
	}

	public String getTaskType() {
		return taskType;
	}

	public String getTaskCallback() {
		return taskCallback;
	}

	public Integer getFirstDelay() {
		return firstDelay;
	}

	public Integer getExpire() {
		return expire;
	}

	public Integer getExecTime() {
		return execTime;
	}

}

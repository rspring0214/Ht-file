/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.task;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.huateng.base.task.vo.TaskExecContext;
import com.huateng.base.task.vo.TaskExecResult;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.core.enums.InvokeTypeEnum;
import com.huateng.user.core.service.UserInfoService;
import com.huateng.user.core.util.HTDateUtils;
import com.huateng.user.dal.model.UserInfo;

/**
 * Description:用户自动解锁任务
 *
 * @author Heaven.tang
 * @version $Id: AutoUnlockUserTask.java, v 0.1 2019年5月9日 下午2:26:44 Heaven.tang Exp $
 */
public class AutoUnlockUserTask extends AbstractAtomicTask {

	private final static Logger logger = LoggerFactory.getLogger(AutoUnlockUserTask.class);
	
	@Value("${auto.unlock.time:-1}")
	private Integer autoUnlockTime;
	
	@Autowired
	private UserInfoService userInfoService;
	
	/**
	 * @see com.huateng.user.core.task.AbstractAtomicTask#addTask()
	 */
	@Override
	public void addTask() {
		if (autoUnlockTime > 0) {
			logger.debug("AutoUnlockUserTask add, create task start...");
			
			String taskNo = AtomicTaskEnum.AUTO_UNLOCK_USER.getTaskType() + "_" + HTDateUtils.getDateStr(HTDateUtils.DATE_SHORT_MINUTE_FMT, new Date());
			
			addExecute(taskNo, AtomicTaskEnum.AUTO_UNLOCK_USER, InvokeTypeEnum.SYNC);
			
			logger.debug("AutoUnlockUserTask add, create task end...");
		}
	}

	/**
	 * @see com.huateng.user.core.task.AbstractAtomicTask#execute(com.huateng.base.task.vo.TaskExecContext)
	 */
	@Override
	public TaskExecResult execute(TaskExecContext context) {
		List<UserInfo> list = userInfoService.selectLockedUsers(autoUnlockTime);
		for (final UserInfo user : list) {
			UserInfo u = new UserInfo();
			u.setId(user.getId());
			u.setStatus(Constants.COMMON_VALID);
			u.setUpdateBy("system");
			userInfoService.updateUser(u);
		}
		return new TaskExecResult(true, "Execute complete");
	}

}

/**
 * Copyright (c) 2018 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.task;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.huateng.base.task.vo.TaskExecContext;
import com.huateng.base.task.vo.TaskExecResult;
import com.huateng.user.core.enums.InvokeTypeEnum;
import com.huateng.user.core.service.UserOnlineInfoService;
import com.huateng.user.core.util.HTDateUtils;

/**
 * Description:超时下线补单
 *
 * @author Heaven.tang
 * @version $Id: OnlineExpireComplementTask.java, v 0.1 2019年4月16日18:52:04 Heaven.tang Exp $
 */
@Component("OnlineExpireComplementTask")
public class OnlineExpireComplementTask extends AbstractAtomicTask {

	private static final Logger logger = LoggerFactory.getLogger(OnlineExpireComplementTask.class);
	
	@Autowired
	private UserOnlineInfoService onlineService;
	
	/*@Autowired
	private StorageService storageService;
	
	@Autowired
	private AsycRecordService asycRecord;*/
	
	/**
	 * @see com.huateng.user.core.task.AbstractAtomicTask#addTask()
	 */
	@Override
	public void addTask() {
		logger.debug("OnlineExpireComplementTask add, create task start...");
		
		String taskNo = AtomicTaskEnum.ONLINE_EXPIRE_COMPLEMENT.getTaskType() + "_" + HTDateUtils.getDateStr(HTDateUtils.DATE_SHORT_MINUTE_FMT, new Date());
		
		addExecute(taskNo, AtomicTaskEnum.ONLINE_EXPIRE_COMPLEMENT, InvokeTypeEnum.SYNC);
		
		logger.debug("OnlineExpireComplementTask add, create task end...");
	}

	/**
	 * @see com.huateng.user.core.task.AbstractAtomicTask#execute(com.huateng.base.task.vo.TaskExecContext)
	 */
	@Override
	public TaskExecResult execute(TaskExecContext context) {
		/*List<UserOnlineInfo> list = onlineService.selectUserOnline(null, -2, null);
		for (UserOnlineInfo online : list) {
			SSOUser tokenUserModel = storageService.getObject(online.getSessionId(), SSOClientUtils.KEY_TOKEN + online.getSessionId(), SSOUser.class);
			if (null == tokenUserModel) {
				asycRecord.userOnlineRemove(online.getSessionId());
			}
		}*/
		int result = onlineService.clearExpireSession();
		return new TaskExecResult(true, "Execute complete,clear "+result+" session");
	}

}

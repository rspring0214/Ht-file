/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.util;

import org.apache.commons.lang3.StringUtils;

import com.huateng.user.api.enums.YesOrNoEnum;
import com.huateng.user.api.model.UserDept;
import com.huateng.user.dal.model.DeptInfo;
import com.huateng.user.dal.model.PasswordRecord;
import com.huateng.user.dal.model.TenantInfo;
import com.huateng.user.dal.model.UserInfo;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: Assembler.java, v 0.1 2019年4月15日 上午11:22:46 Heaven.tang Exp $
 */
public abstract class Assembler {

	/**
	 * 租户信息映射为顶级组织机构
	 * 
	 * @param data
	 * @return
	 */
	public static DeptInfo buildDeptInfo(TenantInfo data) {
        DeptInfo result = new DeptInfo();
		result.setId(data.getId());
		result.setTenantId(data.getId());
		result.setParentId("0");
		result.setAncestors("0");
		result.setDeptName(data.getTenantName());
		result.setOrderNum(0);
		result.setStatus(data.getStatus());
		result.setDelFlag(data.getDelFlag());
		result.setCreateBy(data.getCreateBy());
		result.setCreateTime(data.getCreateTime());
		if (StringUtils.isNotBlank(data.getUpdateBy())) {
			result.setUpdateBy(data.getUpdateBy());
		}
		if (null != data.getUpdateTime()) {
			result.setUpdateTime(data.getUpdateTime());
		}
		return result;
	}

	/**
	 * 组织机构信息转换
	 * 
	 * @param dept
	 * @param curDept
	 * @return
	 */
	public static UserDept convertDeptInfo(DeptInfo dept, UserDept curDept) {
		return BeanUtils.propertiesCopy(dept, curDept);
	}

	/**
	 * 用户密码记录组装
	 * 
	 * @param user
	 * @return
	 */
	public static PasswordRecord buildPasswordRecord(UserInfo user) {
		PasswordRecord record = new PasswordRecord();
		record.setUserId(user.getId());
		record.setUserPassword(user.getPassword());
		record.setStatus(Integer.valueOf(YesOrNoEnum.YES.getCode()));
		return record;
	}

}

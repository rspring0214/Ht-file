package com.huateng.user.core.util;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.FieldUtils;

/**
 * Description:Bean 工具类
 *
 * @author Heaven.tang
 * @version $Id: BeanUtils.java, v 0.1 2019年4月3日 下午5:21:22 Heaven.tang Exp $
 */
public class BeanUtils {

	/**
	 * 对象属性复制，支持单对象、List/Set集合，数组 create by heaven.tang
	 * 
	 * @param source 要复制属性值的来源（单个对象、List/Set集合、数组）
	 * @param target 赋值的目标对象 new Target()
	 * @return
	 */
	@SuppressWarnings("unchecked")
	 public static <S, T, R> R propertiesCopy(S source, T target) {
    	try {
    		Class<? extends Object> cla = target.getClass();
        	if (source instanceof List) {
        		List<?> sList = (List<?>) source;
        		List<T> tList = new ArrayList<T>(10);
        		for (Object src : sList) {
					T tar = beanPropertiesCopy(src, cla);
					tList.add(tar);
    			}
        		return (R) tList;
        	}
        	if (source instanceof Set) {
        		Set<?> sSet = (Set<?>) source;
        		Set<T> tSet = new HashSet<T>();
        		for (Object src : sSet) {
					T tar = beanPropertiesCopy(src, cla);
					tSet.add(tar);
    			}
        		return (R) tSet;
        	}
        	if (source instanceof Array) {
        		Array sArr = (Array) source;
        		Array[] tArr = new Array[Array.getLength(sArr)];
        		for (int i = 0; i < Array.getLength(sArr); i++) {
					T tar = beanPropertiesCopy(Array.get(sArr, i), cla);
					Array.set(tArr, i, tar);
    			}
        		return (R) tArr;
        	}
        	return beanPropertiesCopy((Object) source, cla);
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return (R) target;
    }

	@SuppressWarnings("unchecked")
	private static <T> T beanPropertiesCopy(Object source, Class<?> cla) throws Exception {
		T target = (T) cla.newInstance();
		org.springframework.beans.BeanUtils.copyProperties(source, target);
		return target;
	}

	/**
	 * 对象单层属性复制到Map中
	 * 
	 * @param user
	 * @return
	 */
	public static Map<String, Object> propertiesCopyToMap(Object source, String... ignores) {
		List<Field> fields = FieldUtils.getAllFieldsList(source.getClass());
		Map<String, Object> map = new HashMap<String, Object>(8);
		for (Field field : fields) {
			field.setAccessible(true);
			if (StringUtils.equals(field.getName(), "serialVersionUID")) {
				continue;
			}
			if (null != ignores && ignores.length > 0) {
				List<String> ignoreFields = Arrays.asList(ignores);
				if (ignoreFields.contains(field.getName())) {
					continue;
				}
			}
			try {
				Object obj = FieldUtils.readField(field, source);
				if (!isEmpty(obj)) {
//				if ( null != obj) {
					map.put(field.getName(), obj);
				}
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		}
		return map;
	}
	
	public static boolean isEmpty(Object obj) {
        if (obj == null) {
            return true;
        }

        if (obj.getClass().isArray()) {
            return Array.getLength(obj) == 0;
        }
        if (obj instanceof CharSequence) {
            return ((CharSequence) obj).length() == 0;
        }
        if (obj instanceof Collection) {
            return ((Collection) obj).isEmpty();
        }
        if (obj instanceof Map) {
            return ((Map) obj).isEmpty();
        }

        // else
        return false;
    }
}

package com.huateng.user.core.util;

import org.apache.commons.lang3.StringUtils;

import com.huateng.user.core.service.ConfigInfoService;
import com.huateng.user.dal.model.ConfigInfo;

/**
 * 规范使用动态配置参数
 * 
 * @author senvon
 *
 */
public class Configs {
	
	private Configs() {
	}

	private static Configs instance = new Configs();

	public static Configs getInstance() {
		if (instance == null) {
			synchronized (Configs.class) {
				if (instance == null) {
					instance = new Configs();
				}
			}
		}
		return instance;
	}

	private ConfigInfoService configInfoService;

	public void setConfigInfoService(ConfigInfoService configInfoService) {
		this.configInfoService = configInfoService;
	}

	public String findByKey(String key) {
		if (StringUtils.isNotBlank(key)) {
			ConfigInfo configInfo = configInfoService.findByKey(key);
			if (configInfo != null) {
				return configInfo.getConfigValue();
			}
		}
		return null;
	}
}

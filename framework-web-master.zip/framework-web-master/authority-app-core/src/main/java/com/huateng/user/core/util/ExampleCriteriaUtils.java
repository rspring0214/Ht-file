/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.util;

import java.lang.reflect.Field;
import java.util.Arrays;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.commons.lang3.reflect.MethodUtils;

import com.huateng.user.api.model.BaseException;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: ExampleCriteriaUtils.java, v 0.1 2019年3月6日 下午6:39:55 Heaven.tang Exp $
 */
public class ExampleCriteriaUtils {

	/**
	 * 设置属性值
	 * 
	 * @param obj
	 * @param criteria
	 * @throws Exception
	 */
	public static void criteriaEqualsSet(Object criteria, Object obj, String... ignoreFields) {
		for (Field field : FieldUtils.getAllFieldsList(obj.getClass())) {
			field.setAccessible(true);
			String fieldName = field.getName();
			if (StringUtils.equals(fieldName, "serialVersionUID")) {
				continue;
			}
			if (null != ignoreFields && ignoreFields.length > 0 && (Arrays.asList(ignoreFields)).contains(fieldName)) {
				continue;
			}
			String upperCase = fieldName.substring(0, 1).toUpperCase();
			String upperField = fieldName.replaceFirst(upperCase.toLowerCase(), upperCase);
			try {
				Object fieldValue = FieldUtils.readDeclaredField(obj, fieldName, true);
				if (!BeanUtils.isEmpty(fieldValue)) {
//				if (null != fieldValue) {
					String compareMtd = "and".concat(upperField).concat("EqualTo");
					MethodUtils.invokeMethod(criteria, compareMtd, fieldValue);
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new BaseException("Set field value exception, " + e.getMessage());
			}
		}
	}

}

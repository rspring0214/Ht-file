/**
 * Copyright (c) 2017 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.core.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Description:日期格式转换工具类
 *
 * @author Heaven.tang
 * @version $Id: DateUtils.java, v 0.1 2017年10月20日14:31:34 Heaven.tang Exp $
 */
public class HTDateUtils extends org.apache.commons.lang3.time.DateUtils {

	/** 年月日带分隔符 */
	public static final String DATE_FMT = "yyyy-MM-dd";
	/** 年月日时分秒带分隔符 */
	public static final String DATE_TIME_FMT = "yyyy-MM-dd HH:mm:ss";
	/** 年月日不带分隔符 */
	public static final String DATE_SHORT_FMT = "yyyyMMdd";
	/** 年月日时不带分隔符 */
	public static final String DATE_SHORT_HOUR_FMT = "yyyyMMddHH";
	/** 年月日时分不带分隔符 */
	public static final String DATE_SHORT_MINUTE_FMT = "yyyyMMddHHmm";
	/** 年月日时分秒不带分隔符 */
	public static final String DATE_LONG_FMT = "yyyyMMddHHmmss";

	private static final String[] parsePatterns = {
            "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM", 
            "yyyy/MM/dd", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm", "yyyy/MM",
            "yyyy.MM.dd", "yyyy.MM.dd HH:mm:ss", "yyyy.MM.dd HH:mm", "yyyy.MM"};

	/**
	 * 获取当前时间指定格式字符串
	 * 
	 * @param dateFormat
	 * @return
	 */
	public static String getCurrentDateStr(String dateFormat) {
		return getDateFormat(dateFormat).format(new Date());
	}

	/**
	 * formatString转换DateFormat
	 * 
	 * @param format
	 * @return
	 */
	public static final DateFormat getDateFormat(String format) {
		return new SimpleDateFormat(format);
	}

	/**
	 * 获取指定时间指定格式字符串
	 * 
	 * @param dateFormat
	 * @param date
	 * @return
	 */
	public static String getDateStr(String dateFormat, Date date) {
		return getDateFormat(dateFormat).format(date);
	}

	/**
	 * 时间字符串转换成Date
	 * 
	 * @param dateFormat
	 * @param dateStr
	 * @return
	 */
	public static Date parseStrToDate(String dateFormat, String dateStr) {
		try {
			return getDateFormat(dateFormat).parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static final String parseDateToStr(final String format, final Date date)
    {
        return new SimpleDateFormat(format).format(date);
    }
	
	/**
     * 日期型字符串转化为日期格式，自动匹配格式
     * 
     * @param str
     */
	public static Date parseDate(String str) {
		if (str == null) {
			return null;
		}
		try {
			return parseDate(str, parsePatterns);
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 根据类型和增减值获取新的时间，由调用方指定时间单位
	 * 
	 * @param calendar
	 * @param num
	 * @return
	 */
	public static Date addTime(Date date, int calendar, int num) {
		Calendar time = Calendar.getInstance();
		time.setTime(date);
		time.add(calendar, num);
		return time.getTime();
	}

}

package com.huateng.user.core.test;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.core.model.GlobalUserModel;
import com.huateng.user.core.security.impl.CacheManagerStorageServiceImpl;
import com.huateng.user.core.security.impl.InnerTokenServiceImpl;

@RunWith(org.springframework.test.context.junit4.SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:newUser/application-test.xml"})
public class InnerTokenTest {

	@Autowired
	private InnerTokenServiceImpl tokenService;
	@Autowired
	private CacheManagerStorageServiceImpl storageService;
	
	@Test
	public void test1() throws Exception{
		SSOUser user =new SSOUser();
		user.setTenantCode("senvonTenant");
		user.setUserName("senvonName");
		user.setDeviceType("1234567890");
		String token = tokenService.generateToken(user);
		
		GlobalUserModel userModel = tokenService.findUserModel(user.getUserName() , user.getTenantCode());
		userModel.addToken("1234556", user.getDeviceType());
		tokenService.invalidGlobalToken(user.getUserName() , user.getTenantCode());
		
		Assert.assertTrue(userModel != null);
		
		System.out.println(ToStringBuilder.reflectionToString(userModel));
		
		Assert.assertTrue(userModel.tokenExist(token, user.getDeviceType()));
		Assert.assertTrue(userModel.findLoginTime(user.getDeviceType()) == 1);
	}
	
	@Test
	public void test2() throws Exception{
		SSOUser user =new SSOUser();
		user.setTenantCode("senvonTenant");
		user.setUserName("senvonName");
		user.setDeviceType("senvonDeviceType");
		
		String token = tokenService.generateToken(user);
		
		SSOClientUtils.getInstance().setCurrent(token);
		Map<String ,Object> param = new HashMap<String , Object>();
		param.put("s1", "123");
		param.put("s2", "senvon");
		SSOClientUtils.getInstance().putObject("senvon1234", param);
		
		tokenService.invalidToken(token);
		
		GlobalUserModel userModel = tokenService.findUserModel(user.getUserName() , user.getTenantCode());
		System.out.println("====="+ToStringBuilder.reflectionToString(userModel));
		Assert.assertTrue(userModel != null);
		Assert.assertTrue(!userModel.tokenExist(token, user.getDeviceType()));
		Assert.assertTrue(userModel.findLoginTime(user.getDeviceType()) == 0);
		
		Object obj = SSOClientUtils.getInstance().getObject("senvon1234", Object.class);
		System.out.println("====="+obj);
		Assert.assertTrue(obj == null);
	}
	
	@Test
	public void test3() throws Exception{
		Map<String ,Object> param = new HashMap<String , Object>();
		param.put("s1", "123");
		param.put("s2", "senvon");
		
		String key = "senvonKey";
		String token = "senvonToken";
		
		storageService.putObject(token, key, param);
		Object obj = storageService.getObject(token, key, Object.class);
		Assert.assertTrue(obj != null);
		
		Map<String , Set<String>> keyMap = storageService.getKeyMap();
		Assert.assertTrue(keyMap.containsKey(token));
		Set<String> keySet = keyMap.get(token);
		Assert.assertTrue(keySet != null && !keySet.isEmpty() && keySet.contains(key));
		
		storageService.removeObject(token, key);
		Object obj1 = storageService.getObject(token, key, Object.class);
		Assert.assertTrue(obj1 == null);
		
		Map<String , Set<String>> keyMap2 = storageService.getKeyMap();
		Assert.assertTrue(!keyMap2.containsKey(token));
		
		storageService.putObject(token, key, param);
		Object obj2 = storageService.getObject(token, key, Object.class);
		Assert.assertTrue(obj2 != null);
		
		storageService.removeAll(token);
		Map<String , Set<String>> keyMap4 = storageService.getKeyMap();
		Assert.assertTrue(!keyMap4.containsKey(token));
		Object obj3 = storageService.getObject(token, key, Object.class);
		Assert.assertTrue(obj3 == null);
	}
}

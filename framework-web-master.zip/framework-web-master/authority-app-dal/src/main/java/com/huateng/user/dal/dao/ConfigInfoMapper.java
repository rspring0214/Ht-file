package com.huateng.user.dal.dao;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.dal.model.ConfigInfo;
import com.huateng.user.dal.model.ConfigInfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ConfigInfoMapper {
    int countByExample(ConfigInfoExample example);

    int deleteByExample(ConfigInfoExample example);

    int deleteByPrimaryKey(String id);

    int insert(ConfigInfo record);

    int insertSelective(ConfigInfo record);

    List<ConfigInfo> selectByExample(ConfigInfoExample example);

    ConfigInfo selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") ConfigInfo record, @Param("example") ConfigInfoExample example);

    int updateByExample(@Param("record") ConfigInfo record, @Param("example") ConfigInfoExample example);

    int updateByPrimaryKeySelective(ConfigInfo record);

    int updateByPrimaryKey(ConfigInfo record);

    List<ConfigInfo> selectByExample(ConfigInfoExample example, PageInfo pageRowBounds);
}
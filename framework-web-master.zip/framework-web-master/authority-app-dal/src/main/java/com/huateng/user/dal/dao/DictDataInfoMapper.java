package com.huateng.user.dal.dao;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.dal.model.DictDataInfo;
import com.huateng.user.dal.model.DictDataInfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DictDataInfoMapper {
    int countByExample(DictDataInfoExample example);

    int deleteByExample(DictDataInfoExample example);

    int deleteByPrimaryKey(String id);

    int insert(DictDataInfo record);

    int insertSelective(DictDataInfo record);

    List<DictDataInfo> selectByExample(DictDataInfoExample example);

    DictDataInfo selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") DictDataInfo record, @Param("example") DictDataInfoExample example);

    int updateByExample(@Param("record") DictDataInfo record, @Param("example") DictDataInfoExample example);

    int updateByPrimaryKeySelective(DictDataInfo record);

    int updateByPrimaryKey(DictDataInfo record);

    List<DictDataInfo> selectByExample(DictDataInfoExample example, PageInfo pageRowBounds);
}
package com.huateng.user.dal.dao;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.dal.model.DictTypeInfo;
import com.huateng.user.dal.model.DictTypeInfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DictTypeInfoMapper {
    int countByExample(DictTypeInfoExample example);

    int deleteByExample(DictTypeInfoExample example);

    int deleteByPrimaryKey(String id);

    int insert(DictTypeInfo record);

    int insertSelective(DictTypeInfo record);

    List<DictTypeInfo> selectByExample(DictTypeInfoExample example);

    DictTypeInfo selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") DictTypeInfo record, @Param("example") DictTypeInfoExample example);

    int updateByExample(@Param("record") DictTypeInfo record, @Param("example") DictTypeInfoExample example);

    int updateByPrimaryKeySelective(DictTypeInfo record);

    int updateByPrimaryKey(DictTypeInfo record);

    List<DictTypeInfo> selectByExample(DictTypeInfoExample example, PageInfo pageRowBounds);
}
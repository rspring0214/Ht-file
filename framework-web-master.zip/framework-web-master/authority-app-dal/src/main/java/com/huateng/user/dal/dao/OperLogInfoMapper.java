package com.huateng.user.dal.dao;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.dal.model.OperLogInfo;
import com.huateng.user.dal.model.OperLogInfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface OperLogInfoMapper {
    int countByExample(OperLogInfoExample example);

    int deleteByExample(OperLogInfoExample example);

    int deleteByPrimaryKey(String id);

    int insert(OperLogInfo record);

    int insertSelective(OperLogInfo record);

    List<OperLogInfo> selectByExample(OperLogInfoExample example);

    OperLogInfo selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") OperLogInfo record, @Param("example") OperLogInfoExample example);

    int updateByExample(@Param("record") OperLogInfo record, @Param("example") OperLogInfoExample example);

    int updateByPrimaryKeySelective(OperLogInfo record);

    int updateByPrimaryKey(OperLogInfo record);

    List<OperLogInfo> selectByExample(OperLogInfoExample example, PageInfo pageRowBounds);
}
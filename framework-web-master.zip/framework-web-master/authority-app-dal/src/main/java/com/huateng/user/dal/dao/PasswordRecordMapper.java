package com.huateng.user.dal.dao;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.dal.model.PasswordRecord;
import com.huateng.user.dal.model.PasswordRecordExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PasswordRecordMapper {
    int countByExample(PasswordRecordExample example);

    int deleteByExample(PasswordRecordExample example);

    int deleteByPrimaryKey(String id);

    int insert(PasswordRecord record);

    int insertSelective(PasswordRecord record);

    List<PasswordRecord> selectByExample(PasswordRecordExample example);

    PasswordRecord selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") PasswordRecord record, @Param("example") PasswordRecordExample example);

    int updateByExample(@Param("record") PasswordRecord record, @Param("example") PasswordRecordExample example);

    int updateByPrimaryKeySelective(PasswordRecord record);

    int updateByPrimaryKey(PasswordRecord record);

    List<PasswordRecord> selectByExample(PasswordRecordExample example, PageInfo pageRowBounds);
}
package com.huateng.user.dal.dao;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.dal.model.PostInfo;
import com.huateng.user.dal.model.PostInfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PostInfoMapper {
    int countByExample(PostInfoExample example);

    int deleteByExample(PostInfoExample example);

    int deleteByPrimaryKey(String id);

    int insert(PostInfo record);

    int insertSelective(PostInfo record);

    List<PostInfo> selectByExample(PostInfoExample example);

    PostInfo selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") PostInfo record, @Param("example") PostInfoExample example);

    int updateByExample(@Param("record") PostInfo record, @Param("example") PostInfoExample example);

    int updateByPrimaryKeySelective(PostInfo record);

    int updateByPrimaryKey(PostInfo record);

    List<PostInfo> selectByExample(PostInfoExample example, PageInfo pageRowBounds);
}
package com.huateng.user.dal.dao;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.dal.model.RoleDeptInfo;
import com.huateng.user.dal.model.RoleDeptInfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface RoleDeptInfoMapper {
    int countByExample(RoleDeptInfoExample example);

    int deleteByExample(RoleDeptInfoExample example);

    int deleteByPrimaryKey(String id);

    int insert(RoleDeptInfo record);

    int insertSelective(RoleDeptInfo record);

    List<RoleDeptInfo> selectByExample(RoleDeptInfoExample example);

    RoleDeptInfo selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") RoleDeptInfo record, @Param("example") RoleDeptInfoExample example);

    int updateByExample(@Param("record") RoleDeptInfo record, @Param("example") RoleDeptInfoExample example);

    int updateByPrimaryKeySelective(RoleDeptInfo record);

    int updateByPrimaryKey(RoleDeptInfo record);

    List<RoleDeptInfo> selectByExample(RoleDeptInfoExample example, PageInfo pageRowBounds);
}
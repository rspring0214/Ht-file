package com.huateng.user.dal.dao;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.dal.model.RoleMenuInfo;
import com.huateng.user.dal.model.RoleMenuInfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface RoleMenuInfoMapper {
    int countByExample(RoleMenuInfoExample example);

    int deleteByExample(RoleMenuInfoExample example);

    int deleteByPrimaryKey(String id);

    int insert(RoleMenuInfo record);

    int insertSelective(RoleMenuInfo record);

    List<RoleMenuInfo> selectByExample(RoleMenuInfoExample example);

    RoleMenuInfo selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") RoleMenuInfo record, @Param("example") RoleMenuInfoExample example);

    int updateByExample(@Param("record") RoleMenuInfo record, @Param("example") RoleMenuInfoExample example);

    int updateByPrimaryKeySelective(RoleMenuInfo record);

    int updateByPrimaryKey(RoleMenuInfo record);

    List<RoleMenuInfo> selectByExample(RoleMenuInfoExample example, PageInfo pageRowBounds);
}
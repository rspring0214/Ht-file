package com.huateng.user.dal.dao;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.dal.model.TenantInfo;
import com.huateng.user.dal.model.TenantInfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TenantInfoMapper {
    int countByExample(TenantInfoExample example);

    int deleteByExample(TenantInfoExample example);

    int deleteByPrimaryKey(String id);

    int insert(TenantInfo record);

    int insertSelective(TenantInfo record);

    List<TenantInfo> selectByExample(TenantInfoExample example);

    TenantInfo selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") TenantInfo record, @Param("example") TenantInfoExample example);

    int updateByExample(@Param("record") TenantInfo record, @Param("example") TenantInfoExample example);

    int updateByPrimaryKeySelective(TenantInfo record);

    int updateByPrimaryKey(TenantInfo record);

    List<TenantInfo> selectByExample(TenantInfoExample example, PageInfo pageRowBounds);
}
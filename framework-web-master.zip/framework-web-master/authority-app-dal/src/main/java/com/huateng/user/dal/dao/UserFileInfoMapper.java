package com.huateng.user.dal.dao;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.dal.model.UserFileInfo;
import com.huateng.user.dal.model.UserFileInfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UserFileInfoMapper {
    int countByExample(UserFileInfoExample example);

    int deleteByExample(UserFileInfoExample example);

    int deleteByPrimaryKey(String id);

    int insert(UserFileInfo record);

    int insertSelective(UserFileInfo record);

    List<UserFileInfo> selectByExample(UserFileInfoExample example);

    UserFileInfo selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") UserFileInfo record, @Param("example") UserFileInfoExample example);

    int updateByExample(@Param("record") UserFileInfo record, @Param("example") UserFileInfoExample example);

    int updateByPrimaryKeySelective(UserFileInfo record);

    int updateByPrimaryKey(UserFileInfo record);

    List<UserFileInfo> selectByExample(UserFileInfoExample example, PageInfo pageRowBounds);
}
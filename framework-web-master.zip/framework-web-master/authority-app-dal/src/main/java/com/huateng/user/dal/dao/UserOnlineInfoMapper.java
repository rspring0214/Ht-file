package com.huateng.user.dal.dao;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.dal.model.UserOnlineInfo;
import com.huateng.user.dal.model.UserOnlineInfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UserOnlineInfoMapper {
    int countByExample(UserOnlineInfoExample example);

    int deleteByExample(UserOnlineInfoExample example);

    int deleteByPrimaryKey(String id);

    int insert(UserOnlineInfo record);

    int insertSelective(UserOnlineInfo record);

    List<UserOnlineInfo> selectByExample(UserOnlineInfoExample example);

    UserOnlineInfo selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") UserOnlineInfo record, @Param("example") UserOnlineInfoExample example);

    int updateByExample(@Param("record") UserOnlineInfo record, @Param("example") UserOnlineInfoExample example);

    int updateByPrimaryKeySelective(UserOnlineInfo record);

    int updateByPrimaryKey(UserOnlineInfo record);

    List<UserOnlineInfo> selectByExample(UserOnlineInfoExample example, PageInfo pageRowBounds);
}
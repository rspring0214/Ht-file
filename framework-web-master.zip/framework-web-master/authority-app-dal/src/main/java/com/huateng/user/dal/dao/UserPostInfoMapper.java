package com.huateng.user.dal.dao;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.dal.model.UserPostInfo;
import com.huateng.user.dal.model.UserPostInfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UserPostInfoMapper {
    int countByExample(UserPostInfoExample example);

    int deleteByExample(UserPostInfoExample example);

    int deleteByPrimaryKey(String id);

    int insert(UserPostInfo record);

    int insertSelective(UserPostInfo record);

    List<UserPostInfo> selectByExample(UserPostInfoExample example);

    UserPostInfo selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") UserPostInfo record, @Param("example") UserPostInfoExample example);

    int updateByExample(@Param("record") UserPostInfo record, @Param("example") UserPostInfoExample example);

    int updateByPrimaryKeySelective(UserPostInfo record);

    int updateByPrimaryKey(UserPostInfo record);

    List<UserPostInfo> selectByExample(UserPostInfoExample example, PageInfo pageRowBounds);
}
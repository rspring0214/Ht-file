package com.huateng.user.dal.dao;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.dal.model.UserRoleInfo;
import com.huateng.user.dal.model.UserRoleInfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UserRoleInfoMapper {
    int countByExample(UserRoleInfoExample example);

    int deleteByExample(UserRoleInfoExample example);

    int deleteByPrimaryKey(String id);

    int insert(UserRoleInfo record);

    int insertSelective(UserRoleInfo record);

    List<UserRoleInfo> selectByExample(UserRoleInfoExample example);

    UserRoleInfo selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") UserRoleInfo record, @Param("example") UserRoleInfoExample example);

    int updateByExample(@Param("record") UserRoleInfo record, @Param("example") UserRoleInfoExample example);

    int updateByPrimaryKeySelective(UserRoleInfo record);

    int updateByPrimaryKey(UserRoleInfo record);

    List<UserRoleInfo> selectByExample(UserRoleInfoExample example, PageInfo pageRowBounds);
}
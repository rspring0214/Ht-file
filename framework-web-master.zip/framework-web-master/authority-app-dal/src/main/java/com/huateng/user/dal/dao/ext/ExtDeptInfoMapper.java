/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.dal.dao.ext;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.huateng.user.dal.model.DeptInfo;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: ExtDeptInfoMapper.java, v 0.1 2019年4月3日 下午12:22:00 Heaven.tang Exp $
 */
public interface ExtDeptInfoMapper {

	/**
	 * 更新子组织机构信息
	 * 
	 * @param childrens
	 * @return
	 */
	int updateDeptChildren(@Param("depts") List<DeptInfo> depts);

	/**
	 * 
	 * @param roleId
	 * @return
	 */
	List<String> selectRoleDeptTree(String roleId);

	/**
	 * 查询组织机构树
	 * 
	 * @param deptInfo
	 * @return
	 */
	List<DeptInfo> selectDeptTree(DeptInfo deptInfo);

	/**
	 * 查询组织机构树
	 * 
	 * @param params
	 * @return
	 */
	List<DeptInfo> selectDeptTree(Map<String, Object> params);

	/**
	 * 根据祖先ID查询组织机构ID
	 * 
	 * @param accessorId
	 * @return
	 */
	List<String> selectDeptIdsByAccessorId(String accessorId);

}

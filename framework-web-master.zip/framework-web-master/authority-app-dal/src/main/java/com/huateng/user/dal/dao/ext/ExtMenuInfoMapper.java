package com.huateng.user.dal.dao.ext;

import java.util.List;
import java.util.Map;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.dal.model.MenuInfo;

public interface ExtMenuInfoMapper {

	/**
	 * 得到某一个user的所有权限配置信息
	 * 使用map是因为需要传递一些其他相关的配置化的固定参数
	 * 
	 * @param userId
	 * @return
	 */
	public List<MenuInfo> findMenuByUserId(Map<String, Object> params);
	
	/**
	 * 查询所有资源菜单信息
	 * 
	 * @return
	 */
	public List<MenuInfo> findAllMenu();
	
	/**
	 * 得到某一个用户的权限标识列表 同findMenuByUserId，只是限定了返回结果
	 * 使用map是因为需要传递一些其他相关的配置化的固定参数
	 * 
	 * @param userId
	 * @return
	 */
	public List<String> selectPermsByUserId(Map<String, Object> params);
	
	/**
	 * 查询所有菜单权限配置
	 * 
	 * @return
	 */
	public List<String> selectAllPerms();

	/**
	 * 关联分页查询资源菜单
	 * 
	 * @param menuInfo
	 * @param page
	 * @return
	 */
	public List<MenuInfo> selectMenuList(MenuInfo menuInfo, PageInfo<MenuInfo> page);

	/**
	 * 根据角色ID查询资源菜单树
	 * 
	 * @param roleId
	 * @return
	 */
	public List<String> selectMenuTree(String roleId);
}

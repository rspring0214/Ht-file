/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.dal.dao.ext;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: ExtOperLogInfoMapper.java, v 0.1 2019年4月9日 下午1:15:46 Heaven.tang Exp $
 */
public interface ExtOperLogInfoMapper {

	/**
	 * 清空表记录
	 */
	void cleanOperLog();

}

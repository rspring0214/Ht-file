/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.dal.dao.ext;

import java.util.List;

import com.huateng.user.dal.model.PostInfo;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: ExtPostInfoMapper.java, v 0.1 2019年4月4日 下午8:22:49 Heaven.tang Exp $
 */
public interface ExtPostInfoMapper {

	/**
	 * 根据用户ID查询用户岗位信息
	 * 
	 * @param userId
	 * @return
	 */
	List<PostInfo> selectPostsByUserId(String userId);

}

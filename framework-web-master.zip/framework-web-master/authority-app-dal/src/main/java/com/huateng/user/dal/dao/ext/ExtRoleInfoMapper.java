/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.dal.dao.ext;

import java.util.List;
import java.util.Map;

import com.huateng.user.dal.model.RoleInfo;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: ExtRoleInfoMapper.java, v 0.1 2019年4月4日 下午7:54:07 Heaven.tang Exp $
 */
public interface ExtRoleInfoMapper {

	/**
	 * 根据用户ID查询用户角色
	 * 
	 * @param userId
	 * @return
	 */
	List<RoleInfo> selectRolesByUserId(Map<String, Object> params);

}

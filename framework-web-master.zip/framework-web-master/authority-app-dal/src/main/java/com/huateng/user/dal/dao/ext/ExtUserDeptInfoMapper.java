package com.huateng.user.dal.dao.ext;

import java.util.List;
import java.util.Map;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.dal.model.ext.ExtUserDeptInfo;

public interface ExtUserDeptInfoMapper {

	/**
	 * 分页查询用户挂职机构/部门关联信息
	 * 
	 * @param paramMap
	 * @return
	 */
	List<ExtUserDeptInfo> queryByPage(Map<String, Object> paramMap, PageInfo<ExtUserDeptInfo> page);
	
	/**
	 * 分页查询用户挂职机构/部门关联信息，包括下级机构中的信息
	 * 
	 * @param paramMap
	 * @return
	 */
	List<ExtUserDeptInfo> queryWithSubByPage(Map<String, Object> paramMap, PageInfo<ExtUserDeptInfo> page);

	/**
	 * 查询挂职机构/部门的角色ID
	 * 
	 * @param paramMap
	 * @return
	 */
	List<String> queryRoleIds(Map<String, Object> paramMap);

	/**
	 * 统计用户任职机构/部门数量
	 * 
	 * @param userId
	 * @return
	 */
	int countByUserIdDistinct(String userId);

	/**
	 * 查询用户任职的机构
	 * 
	 * @param userId
	 * @return
	 */
	List<String> selectDistinctUserDept(String userId);

}
/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.dal.dao.ext;

import java.util.List;
import java.util.Map;

import com.huateng.base.common.api.model.PageInfo;
import com.huateng.user.dal.model.UserInfo;
import com.huateng.user.dal.model.ext.ExtUserDeptInfo;
import com.huateng.user.dal.model.ext.ExtUserInfo;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: ExtUserInfoMapper.java, v 0.1 2019年4月4日 下午3:34:49 Heaven.tang Exp $
 */
public interface ExtUserInfoMapper {

	/**
	 * 查询用户信息
	 * 
	 * @param params
	 * @param page
	 * @return
	 */
	List<UserInfo> selectUserList(Map<String, Object> params);
	
	/**
	 * 分页查询用户信息
	 * 
	 * @param params
	 * @param page
	 * @return
	 */
	List<ExtUserInfo> selectUserListByPage(Map<String, Object> params, PageInfo<ExtUserInfo> page);

	/**
	 * 根据ID关联查询用户详细信息
	 * 
	 * @param id
	 * @return
	 */
	ExtUserInfo selectUserDetailsById(String id);

	/**
	 * 分页查询用户和所属部门姓名信息
	 * 
	 * @param params
	 * @param page
	 * @return
	 */
	List<ExtUserDeptInfo> selectUserDeptListByPage(Map<String, Object> params, PageInfo<ExtUserDeptInfo> page);

}

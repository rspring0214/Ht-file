package com.huateng.user.dal.model;

import java.io.Serializable;
import java.util.Date;

public class DeptInfo implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * VARCHAR(32) 必填<br>
     * 
     */
    private String id;

    /**
     * VARCHAR(32) 必填<br>
     * 租户ID
     */
    private String tenantId;

    /**
     * VARCHAR(50)<br>
     * 
     */
    private String tenantCode;

    /**
     * VARCHAR(32) 默认值[0] 必填<br>
     * 父组织机构ID
     */
    private String parentId;

    /**
     * VARCHAR(50)<br>
     * 
     */
    private String deptCode;

    /**
     * VARCHAR(64)<br>
     * 组织机构名称
     */
    private String deptName;

    /**
     * VARCHAR(512)<br>
     * 祖先组织机构ID集合
     */
    private String ancestors;

    /**
     * VARCHAR(512)<br>
     * 
     */
    private String ancestorsCodes;

    /**
     * DECIMAL(5) 默认值[0]<br>
     * 显示顺序
     */
    private Integer orderNum;

    /**
     * VARCHAR(64)<br>
     * 负责人
     */
    private String leader;

    /**
     * VARCHAR(20)<br>
     * 联系电话
     */
    private String phone;

    /**
     * VARCHAR(100)<br>
     * 邮箱
     */
    private String email;

    /**
     * DECIMAL(5) 默认值[1]<br>
     * 组织机构状态：1-正常、2-停用/禁用，默认为1
     */
    private Integer status;

    /**
     * DECIMAL(5) 默认值[1]<br>
     * 删除标识：1-正常、2-逻辑删除，默认为1
     */
    private Integer delFlag;

    /**
     * VARCHAR(64)<br>
     * 创建者
     */
    private String createBy;

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 创建时间
     */
    private Date createTime;

    /**
     * VARCHAR(64)<br>
     * 更新者
     */
    private String updateBy;

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 更新时间
     */
    private Date updateTime;

    /**
     * VARCHAR(32) 必填<br>
     * 获得 
     */
    public String getId() {
        return id;
    }

    /**
     * VARCHAR(32) 必填<br>
     * 设置 
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * VARCHAR(32) 必填<br>
     * 获得 租户ID
     */
    public String getTenantId() {
        return tenantId;
    }

    /**
     * VARCHAR(32) 必填<br>
     * 设置 租户ID
     */
    public void setTenantId(String tenantId) {
        this.tenantId = tenantId == null ? null : tenantId.trim();
    }

    /**
     * VARCHAR(50)<br>
     * 获得 
     */
    public String getTenantCode() {
        return tenantCode;
    }

    /**
     * VARCHAR(50)<br>
     * 设置 
     */
    public void setTenantCode(String tenantCode) {
        this.tenantCode = tenantCode == null ? null : tenantCode.trim();
    }

    /**
     * VARCHAR(32) 默认值[0] 必填<br>
     * 获得 父组织机构ID
     */
    public String getParentId() {
        return parentId;
    }

    /**
     * VARCHAR(32) 默认值[0] 必填<br>
     * 设置 父组织机构ID
     */
    public void setParentId(String parentId) {
        this.parentId = parentId == null ? null : parentId.trim();
    }

    /**
     * VARCHAR(50)<br>
     * 获得 
     */
    public String getDeptCode() {
        return deptCode;
    }

    /**
     * VARCHAR(50)<br>
     * 设置 
     */
    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode == null ? null : deptCode.trim();
    }

    /**
     * VARCHAR(64)<br>
     * 获得 组织机构名称
     */
    public String getDeptName() {
        return deptName;
    }

    /**
     * VARCHAR(64)<br>
     * 设置 组织机构名称
     */
    public void setDeptName(String deptName) {
        this.deptName = deptName == null ? null : deptName.trim();
    }

    /**
     * VARCHAR(512)<br>
     * 获得 祖先组织机构ID集合
     */
    public String getAncestors() {
        return ancestors;
    }

    /**
     * VARCHAR(512)<br>
     * 设置 祖先组织机构ID集合
     */
    public void setAncestors(String ancestors) {
        this.ancestors = ancestors == null ? null : ancestors.trim();
    }

    /**
     * VARCHAR(512)<br>
     * 获得 
     */
    public String getAncestorsCodes() {
        return ancestorsCodes;
    }

    /**
     * VARCHAR(512)<br>
     * 设置 
     */
    public void setAncestorsCodes(String ancestorsCodes) {
        this.ancestorsCodes = ancestorsCodes == null ? null : ancestorsCodes.trim();
    }

    /**
     * DECIMAL(5) 默认值[0]<br>
     * 获得 显示顺序
     */
    public Integer getOrderNum() {
        return orderNum;
    }

    /**
     * DECIMAL(5) 默认值[0]<br>
     * 设置 显示顺序
     */
    public void setOrderNum(Integer orderNum) {
        this.orderNum = orderNum;
    }

    /**
     * VARCHAR(64)<br>
     * 获得 负责人
     */
    public String getLeader() {
        return leader;
    }

    /**
     * VARCHAR(64)<br>
     * 设置 负责人
     */
    public void setLeader(String leader) {
        this.leader = leader == null ? null : leader.trim();
    }

    /**
     * VARCHAR(20)<br>
     * 获得 联系电话
     */
    public String getPhone() {
        return phone;
    }

    /**
     * VARCHAR(20)<br>
     * 设置 联系电话
     */
    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    /**
     * VARCHAR(100)<br>
     * 获得 邮箱
     */
    public String getEmail() {
        return email;
    }

    /**
     * VARCHAR(100)<br>
     * 设置 邮箱
     */
    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    /**
     * DECIMAL(5) 默认值[1]<br>
     * 获得 组织机构状态：1-正常、2-停用/禁用，默认为1
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * DECIMAL(5) 默认值[1]<br>
     * 设置 组织机构状态：1-正常、2-停用/禁用，默认为1
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * DECIMAL(5) 默认值[1]<br>
     * 获得 删除标识：1-正常、2-逻辑删除，默认为1
     */
    public Integer getDelFlag() {
        return delFlag;
    }

    /**
     * DECIMAL(5) 默认值[1]<br>
     * 设置 删除标识：1-正常、2-逻辑删除，默认为1
     */
    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    /**
     * VARCHAR(64)<br>
     * 获得 创建者
     */
    public String getCreateBy() {
        return createBy;
    }

    /**
     * VARCHAR(64)<br>
     * 设置 创建者
     */
    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 获得 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 设置 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * VARCHAR(64)<br>
     * 获得 更新者
     */
    public String getUpdateBy() {
        return updateBy;
    }

    /**
     * VARCHAR(64)<br>
     * 设置 更新者
     */
    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 获得 更新时间
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 设置 更新时间
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", tenantId=").append(tenantId);
        sb.append(", tenantCode=").append(tenantCode);
        sb.append(", parentId=").append(parentId);
        sb.append(", deptCode=").append(deptCode);
        sb.append(", deptName=").append(deptName);
        sb.append(", ancestors=").append(ancestors);
        sb.append(", ancestorsCodes=").append(ancestorsCodes);
        sb.append(", orderNum=").append(orderNum);
        sb.append(", leader=").append(leader);
        sb.append(", phone=").append(phone);
        sb.append(", email=").append(email);
        sb.append(", status=").append(status);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        DeptInfo other = (DeptInfo) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getTenantId() == null ? other.getTenantId() == null : this.getTenantId().equals(other.getTenantId()))
            && (this.getTenantCode() == null ? other.getTenantCode() == null : this.getTenantCode().equals(other.getTenantCode()))
            && (this.getParentId() == null ? other.getParentId() == null : this.getParentId().equals(other.getParentId()))
            && (this.getDeptCode() == null ? other.getDeptCode() == null : this.getDeptCode().equals(other.getDeptCode()))
            && (this.getDeptName() == null ? other.getDeptName() == null : this.getDeptName().equals(other.getDeptName()))
            && (this.getAncestors() == null ? other.getAncestors() == null : this.getAncestors().equals(other.getAncestors()))
            && (this.getAncestorsCodes() == null ? other.getAncestorsCodes() == null : this.getAncestorsCodes().equals(other.getAncestorsCodes()))
            && (this.getOrderNum() == null ? other.getOrderNum() == null : this.getOrderNum().equals(other.getOrderNum()))
            && (this.getLeader() == null ? other.getLeader() == null : this.getLeader().equals(other.getLeader()))
            && (this.getPhone() == null ? other.getPhone() == null : this.getPhone().equals(other.getPhone()))
            && (this.getEmail() == null ? other.getEmail() == null : this.getEmail().equals(other.getEmail()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()))
            && (this.getCreateBy() == null ? other.getCreateBy() == null : this.getCreateBy().equals(other.getCreateBy()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpdateBy() == null ? other.getUpdateBy() == null : this.getUpdateBy().equals(other.getUpdateBy()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getTenantId() == null) ? 0 : getTenantId().hashCode());
        result = prime * result + ((getTenantCode() == null) ? 0 : getTenantCode().hashCode());
        result = prime * result + ((getParentId() == null) ? 0 : getParentId().hashCode());
        result = prime * result + ((getDeptCode() == null) ? 0 : getDeptCode().hashCode());
        result = prime * result + ((getDeptName() == null) ? 0 : getDeptName().hashCode());
        result = prime * result + ((getAncestors() == null) ? 0 : getAncestors().hashCode());
        result = prime * result + ((getAncestorsCodes() == null) ? 0 : getAncestorsCodes().hashCode());
        result = prime * result + ((getOrderNum() == null) ? 0 : getOrderNum().hashCode());
        result = prime * result + ((getLeader() == null) ? 0 : getLeader().hashCode());
        result = prime * result + ((getPhone() == null) ? 0 : getPhone().hashCode());
        result = prime * result + ((getEmail() == null) ? 0 : getEmail().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
        result = prime * result + ((getCreateBy() == null) ? 0 : getCreateBy().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateBy() == null) ? 0 : getUpdateBy().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        return result;
    }
}
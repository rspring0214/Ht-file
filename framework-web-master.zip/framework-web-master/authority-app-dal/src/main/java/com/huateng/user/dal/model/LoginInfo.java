package com.huateng.user.dal.model;

import java.io.Serializable;
import java.util.Date;

public class LoginInfo implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * VARCHAR(32) 必填<br>
     * 
     */
    private String id;

    /**
     * VARCHAR(32)<br>
     * 租户ID
     */
    private String tenantId;

    /**
     * VARCHAR(64) 必填<br>
     * 登录账号
     */
    private String loginName;

    /**
     * VARCHAR(50)<br>
     * 登录IP地址
     */
    private String ipaddr;

    /**
     * VARCHAR(255)<br>
     * 登录坐标
     */
    private String loginLocation;

    /**
     * VARCHAR(50)<br>
     * 浏览器类型
     */
    private String browser;

    /**
     * VARCHAR(50)<br>
     * 操作系统
     */
    private String os;

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 登录状态：1-成功、2-失败
     */
    private Integer status;

    /**
     * VARCHAR(255)<br>
     * 提示消息
     */
    private String msg;

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 访问时间
     */
    private Date loginTime;

    /**
     * VARCHAR(32) 必填<br>
     * 获得 
     */
    public String getId() {
        return id;
    }

    /**
     * VARCHAR(32) 必填<br>
     * 设置 
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * VARCHAR(32)<br>
     * 获得 租户ID
     */
    public String getTenantId() {
        return tenantId;
    }

    /**
     * VARCHAR(32)<br>
     * 设置 租户ID
     */
    public void setTenantId(String tenantId) {
        this.tenantId = tenantId == null ? null : tenantId.trim();
    }

    /**
     * VARCHAR(64) 必填<br>
     * 获得 登录账号
     */
    public String getLoginName() {
        return loginName;
    }

    /**
     * VARCHAR(64) 必填<br>
     * 设置 登录账号
     */
    public void setLoginName(String loginName) {
        this.loginName = loginName == null ? null : loginName.trim();
    }

    /**
     * VARCHAR(50)<br>
     * 获得 登录IP地址
     */
    public String getIpaddr() {
        return ipaddr;
    }

    /**
     * VARCHAR(50)<br>
     * 设置 登录IP地址
     */
    public void setIpaddr(String ipaddr) {
        this.ipaddr = ipaddr == null ? null : ipaddr.trim();
    }

    /**
     * VARCHAR(255)<br>
     * 获得 登录坐标
     */
    public String getLoginLocation() {
        return loginLocation;
    }

    /**
     * VARCHAR(255)<br>
     * 设置 登录坐标
     */
    public void setLoginLocation(String loginLocation) {
        this.loginLocation = loginLocation == null ? null : loginLocation.trim();
    }

    /**
     * VARCHAR(50)<br>
     * 获得 浏览器类型
     */
    public String getBrowser() {
        return browser;
    }

    /**
     * VARCHAR(50)<br>
     * 设置 浏览器类型
     */
    public void setBrowser(String browser) {
        this.browser = browser == null ? null : browser.trim();
    }

    /**
     * VARCHAR(50)<br>
     * 获得 操作系统
     */
    public String getOs() {
        return os;
    }

    /**
     * VARCHAR(50)<br>
     * 设置 操作系统
     */
    public void setOs(String os) {
        this.os = os == null ? null : os.trim();
    }

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 获得 登录状态：1-成功、2-失败
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 设置 登录状态：1-成功、2-失败
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * VARCHAR(255)<br>
     * 获得 提示消息
     */
    public String getMsg() {
        return msg;
    }

    /**
     * VARCHAR(255)<br>
     * 设置 提示消息
     */
    public void setMsg(String msg) {
        this.msg = msg == null ? null : msg.trim();
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 获得 访问时间
     */
    public Date getLoginTime() {
        return loginTime;
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 设置 访问时间
     */
    public void setLoginTime(Date loginTime) {
        this.loginTime = loginTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", tenantId=").append(tenantId);
        sb.append(", loginName=").append(loginName);
        sb.append(", ipaddr=").append(ipaddr);
        sb.append(", loginLocation=").append(loginLocation);
        sb.append(", browser=").append(browser);
        sb.append(", os=").append(os);
        sb.append(", status=").append(status);
        sb.append(", msg=").append(msg);
        sb.append(", loginTime=").append(loginTime);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        LoginInfo other = (LoginInfo) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getTenantId() == null ? other.getTenantId() == null : this.getTenantId().equals(other.getTenantId()))
            && (this.getLoginName() == null ? other.getLoginName() == null : this.getLoginName().equals(other.getLoginName()))
            && (this.getIpaddr() == null ? other.getIpaddr() == null : this.getIpaddr().equals(other.getIpaddr()))
            && (this.getLoginLocation() == null ? other.getLoginLocation() == null : this.getLoginLocation().equals(other.getLoginLocation()))
            && (this.getBrowser() == null ? other.getBrowser() == null : this.getBrowser().equals(other.getBrowser()))
            && (this.getOs() == null ? other.getOs() == null : this.getOs().equals(other.getOs()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getMsg() == null ? other.getMsg() == null : this.getMsg().equals(other.getMsg()))
            && (this.getLoginTime() == null ? other.getLoginTime() == null : this.getLoginTime().equals(other.getLoginTime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getTenantId() == null) ? 0 : getTenantId().hashCode());
        result = prime * result + ((getLoginName() == null) ? 0 : getLoginName().hashCode());
        result = prime * result + ((getIpaddr() == null) ? 0 : getIpaddr().hashCode());
        result = prime * result + ((getLoginLocation() == null) ? 0 : getLoginLocation().hashCode());
        result = prime * result + ((getBrowser() == null) ? 0 : getBrowser().hashCode());
        result = prime * result + ((getOs() == null) ? 0 : getOs().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getMsg() == null) ? 0 : getMsg().hashCode());
        result = prime * result + ((getLoginTime() == null) ? 0 : getLoginTime().hashCode());
        return result;
    }
}
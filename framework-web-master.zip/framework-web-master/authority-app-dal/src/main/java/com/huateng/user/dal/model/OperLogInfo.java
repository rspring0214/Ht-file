package com.huateng.user.dal.model;

import java.io.Serializable;
import java.util.Date;

public class OperLogInfo implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * VARCHAR(32) 必填<br>
     * 
     */
    private String id;

    /**
     * VARCHAR(64) 必填<br>
     * 模块标题
     */
    private String title;

    /**
     * DECIMAL(5) 默认值[0]<br>
     * 功能请求
     */
    private Integer businessType;

    /**
     * VARCHAR(100)<br>
     * 操作方法名称
     */
    private String operMethod;

    /**
     * VARCHAR(100)<br>
     * 操作方法描述
     */
    private String operRemark;

    /**
     * DECIMAL(5) 默认值[0]<br>
     * 来源渠道
     */
    private Integer operatorType;

    /**
     * VARCHAR(64) 必填<br>
     * 操作用户
     */
    private String operName;

    /**
     * VARCHAR(32)<br>
     * 组织机构ID
     */
    private String deptId;

    /**
     * VARCHAR(64)<br>
     * 组织机构名称
     */
    private String deptName;

    /**
     * VARCHAR(256)<br>
     * 请求URL
     */
    private String operUrl;

    /**
     * VARCHAR(30)<br>
     * 主机地址
     */
    private String operIp;

    /**
     * VARCHAR(2000)<br>
     * 请求参数
     */
    private String operParam;

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 操作状态：1-正常、2-异常
     */
    private Integer status;

    /**
     * VARCHAR(1000)<br>
     * 错误消息
     */
    private String errorMsg;

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 操作时间
     */
    private Date operTime;

    /**
     * VARCHAR(32) 必填<br>
     * 获得 
     */
    public String getId() {
        return id;
    }

    /**
     * VARCHAR(32) 必填<br>
     * 设置 
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * VARCHAR(64) 必填<br>
     * 获得 模块标题
     */
    public String getTitle() {
        return title;
    }

    /**
     * VARCHAR(64) 必填<br>
     * 设置 模块标题
     */
    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }

    /**
     * DECIMAL(5) 默认值[0]<br>
     * 获得 功能请求
     */
    public Integer getBusinessType() {
        return businessType;
    }

    /**
     * DECIMAL(5) 默认值[0]<br>
     * 设置 功能请求
     */
    public void setBusinessType(Integer businessType) {
        this.businessType = businessType;
    }

    /**
     * VARCHAR(100)<br>
     * 获得 操作方法名称
     */
    public String getOperMethod() {
        return operMethod;
    }

    /**
     * VARCHAR(100)<br>
     * 设置 操作方法名称
     */
    public void setOperMethod(String operMethod) {
        this.operMethod = operMethod == null ? null : operMethod.trim();
    }

    /**
     * VARCHAR(100)<br>
     * 获得 操作方法描述
     */
    public String getOperRemark() {
        return operRemark;
    }

    /**
     * VARCHAR(100)<br>
     * 设置 操作方法描述
     */
    public void setOperRemark(String operRemark) {
        this.operRemark = operRemark == null ? null : operRemark.trim();
    }

    /**
     * DECIMAL(5) 默认值[0]<br>
     * 获得 来源渠道
     */
    public Integer getOperatorType() {
        return operatorType;
    }

    /**
     * DECIMAL(5) 默认值[0]<br>
     * 设置 来源渠道
     */
    public void setOperatorType(Integer operatorType) {
        this.operatorType = operatorType;
    }

    /**
     * VARCHAR(64) 必填<br>
     * 获得 操作用户
     */
    public String getOperName() {
        return operName;
    }

    /**
     * VARCHAR(64) 必填<br>
     * 设置 操作用户
     */
    public void setOperName(String operName) {
        this.operName = operName == null ? null : operName.trim();
    }

    /**
     * VARCHAR(32)<br>
     * 获得 组织机构ID
     */
    public String getDeptId() {
        return deptId;
    }

    /**
     * VARCHAR(32)<br>
     * 设置 组织机构ID
     */
    public void setDeptId(String deptId) {
        this.deptId = deptId == null ? null : deptId.trim();
    }

    /**
     * VARCHAR(64)<br>
     * 获得 组织机构名称
     */
    public String getDeptName() {
        return deptName;
    }

    /**
     * VARCHAR(64)<br>
     * 设置 组织机构名称
     */
    public void setDeptName(String deptName) {
        this.deptName = deptName == null ? null : deptName.trim();
    }

    /**
     * VARCHAR(256)<br>
     * 获得 请求URL
     */
    public String getOperUrl() {
        return operUrl;
    }

    /**
     * VARCHAR(256)<br>
     * 设置 请求URL
     */
    public void setOperUrl(String operUrl) {
        this.operUrl = operUrl == null ? null : operUrl.trim();
    }

    /**
     * VARCHAR(30)<br>
     * 获得 主机地址
     */
    public String getOperIp() {
        return operIp;
    }

    /**
     * VARCHAR(30)<br>
     * 设置 主机地址
     */
    public void setOperIp(String operIp) {
        this.operIp = operIp == null ? null : operIp.trim();
    }

    /**
     * VARCHAR(2000)<br>
     * 获得 请求参数
     */
    public String getOperParam() {
        return operParam;
    }

    /**
     * VARCHAR(2000)<br>
     * 设置 请求参数
     */
    public void setOperParam(String operParam) {
        this.operParam = operParam == null ? null : operParam.trim();
    }

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 获得 操作状态：1-正常、2-异常
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 设置 操作状态：1-正常、2-异常
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * VARCHAR(1000)<br>
     * 获得 错误消息
     */
    public String getErrorMsg() {
        return errorMsg;
    }

    /**
     * VARCHAR(1000)<br>
     * 设置 错误消息
     */
    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg == null ? null : errorMsg.trim();
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 获得 操作时间
     */
    public Date getOperTime() {
        return operTime;
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 设置 操作时间
     */
    public void setOperTime(Date operTime) {
        this.operTime = operTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", title=").append(title);
        sb.append(", businessType=").append(businessType);
        sb.append(", operMethod=").append(operMethod);
        sb.append(", operRemark=").append(operRemark);
        sb.append(", operatorType=").append(operatorType);
        sb.append(", operName=").append(operName);
        sb.append(", deptId=").append(deptId);
        sb.append(", deptName=").append(deptName);
        sb.append(", operUrl=").append(operUrl);
        sb.append(", operIp=").append(operIp);
        sb.append(", operParam=").append(operParam);
        sb.append(", status=").append(status);
        sb.append(", errorMsg=").append(errorMsg);
        sb.append(", operTime=").append(operTime);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        OperLogInfo other = (OperLogInfo) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getTitle() == null ? other.getTitle() == null : this.getTitle().equals(other.getTitle()))
            && (this.getBusinessType() == null ? other.getBusinessType() == null : this.getBusinessType().equals(other.getBusinessType()))
            && (this.getOperMethod() == null ? other.getOperMethod() == null : this.getOperMethod().equals(other.getOperMethod()))
            && (this.getOperRemark() == null ? other.getOperRemark() == null : this.getOperRemark().equals(other.getOperRemark()))
            && (this.getOperatorType() == null ? other.getOperatorType() == null : this.getOperatorType().equals(other.getOperatorType()))
            && (this.getOperName() == null ? other.getOperName() == null : this.getOperName().equals(other.getOperName()))
            && (this.getDeptId() == null ? other.getDeptId() == null : this.getDeptId().equals(other.getDeptId()))
            && (this.getDeptName() == null ? other.getDeptName() == null : this.getDeptName().equals(other.getDeptName()))
            && (this.getOperUrl() == null ? other.getOperUrl() == null : this.getOperUrl().equals(other.getOperUrl()))
            && (this.getOperIp() == null ? other.getOperIp() == null : this.getOperIp().equals(other.getOperIp()))
            && (this.getOperParam() == null ? other.getOperParam() == null : this.getOperParam().equals(other.getOperParam()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getErrorMsg() == null ? other.getErrorMsg() == null : this.getErrorMsg().equals(other.getErrorMsg()))
            && (this.getOperTime() == null ? other.getOperTime() == null : this.getOperTime().equals(other.getOperTime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getTitle() == null) ? 0 : getTitle().hashCode());
        result = prime * result + ((getBusinessType() == null) ? 0 : getBusinessType().hashCode());
        result = prime * result + ((getOperMethod() == null) ? 0 : getOperMethod().hashCode());
        result = prime * result + ((getOperRemark() == null) ? 0 : getOperRemark().hashCode());
        result = prime * result + ((getOperatorType() == null) ? 0 : getOperatorType().hashCode());
        result = prime * result + ((getOperName() == null) ? 0 : getOperName().hashCode());
        result = prime * result + ((getDeptId() == null) ? 0 : getDeptId().hashCode());
        result = prime * result + ((getDeptName() == null) ? 0 : getDeptName().hashCode());
        result = prime * result + ((getOperUrl() == null) ? 0 : getOperUrl().hashCode());
        result = prime * result + ((getOperIp() == null) ? 0 : getOperIp().hashCode());
        result = prime * result + ((getOperParam() == null) ? 0 : getOperParam().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getErrorMsg() == null) ? 0 : getErrorMsg().hashCode());
        result = prime * result + ((getOperTime() == null) ? 0 : getOperTime().hashCode());
        return result;
    }
}
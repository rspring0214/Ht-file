package com.huateng.user.dal.model;

import java.io.Serializable;
import java.util.Date;

public class RoleInfo implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * VARCHAR(32) 必填<br>
     * 
     */
    private String id;

    /**
     * VARCHAR(32) 必填<br>
     * 角色名称
     */
    private String roleName;

    /**
     * VARCHAR(100) 必填<br>
     * 角色权限字符串
     */
    private String roleKey;

    /**
     * DECIMAL(5)<br>
     * 显示顺序
     */
    private Integer roleSort;

    /**
     * DECIMAL(5)<br>
     * 
     */
    private Integer dataScope;

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 状态：1-正常、2-禁用，默认为1
     */
    private Integer status;

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 删除标识：1-正常、2-逻辑删除，默认为1
     */
    private Integer delFlag;

    /**
     * VARCHAR(64)<br>
     * 创建者
     */
    private String createBy;

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 创建时间
     */
    private Date createTime;

    /**
     * VARCHAR(64)<br>
     * 更新者
     */
    private String updateBy;

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 更新时间
     */
    private Date updateTime;

    /**
     * VARCHAR(500)<br>
     * 备注
     */
    private String remark;

    /**
     * VARCHAR(32) 必填<br>
     * 获得 
     */
    public String getId() {
        return id;
    }

    /**
     * VARCHAR(32) 必填<br>
     * 设置 
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * VARCHAR(32) 必填<br>
     * 获得 角色名称
     */
    public String getRoleName() {
        return roleName;
    }

    /**
     * VARCHAR(32) 必填<br>
     * 设置 角色名称
     */
    public void setRoleName(String roleName) {
        this.roleName = roleName == null ? null : roleName.trim();
    }

    /**
     * VARCHAR(100) 必填<br>
     * 获得 角色权限字符串
     */
    public String getRoleKey() {
        return roleKey;
    }

    /**
     * VARCHAR(100) 必填<br>
     * 设置 角色权限字符串
     */
    public void setRoleKey(String roleKey) {
        this.roleKey = roleKey == null ? null : roleKey.trim();
    }

    /**
     * DECIMAL(5)<br>
     * 获得 显示顺序
     */
    public Integer getRoleSort() {
        return roleSort;
    }

    /**
     * DECIMAL(5)<br>
     * 设置 显示顺序
     */
    public void setRoleSort(Integer roleSort) {
        this.roleSort = roleSort;
    }

    /**
     * DECIMAL(5)<br>
     * 获得 
     */
    public Integer getDataScope() {
        return dataScope;
    }

    /**
     * DECIMAL(5)<br>
     * 设置 
     */
    public void setDataScope(Integer dataScope) {
        this.dataScope = dataScope;
    }

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 获得 状态：1-正常、2-禁用，默认为1
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 设置 状态：1-正常、2-禁用，默认为1
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 获得 删除标识：1-正常、2-逻辑删除，默认为1
     */
    public Integer getDelFlag() {
        return delFlag;
    }

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 设置 删除标识：1-正常、2-逻辑删除，默认为1
     */
    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    /**
     * VARCHAR(64)<br>
     * 获得 创建者
     */
    public String getCreateBy() {
        return createBy;
    }

    /**
     * VARCHAR(64)<br>
     * 设置 创建者
     */
    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 获得 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 设置 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * VARCHAR(64)<br>
     * 获得 更新者
     */
    public String getUpdateBy() {
        return updateBy;
    }

    /**
     * VARCHAR(64)<br>
     * 设置 更新者
     */
    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 获得 更新时间
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 设置 更新时间
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    /**
     * VARCHAR(500)<br>
     * 获得 备注
     */
    public String getRemark() {
        return remark;
    }

    /**
     * VARCHAR(500)<br>
     * 设置 备注
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", roleName=").append(roleName);
        sb.append(", roleKey=").append(roleKey);
        sb.append(", roleSort=").append(roleSort);
        sb.append(", dataScope=").append(dataScope);
        sb.append(", status=").append(status);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", remark=").append(remark);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        RoleInfo other = (RoleInfo) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getRoleName() == null ? other.getRoleName() == null : this.getRoleName().equals(other.getRoleName()))
            && (this.getRoleKey() == null ? other.getRoleKey() == null : this.getRoleKey().equals(other.getRoleKey()))
            && (this.getRoleSort() == null ? other.getRoleSort() == null : this.getRoleSort().equals(other.getRoleSort()))
            && (this.getDataScope() == null ? other.getDataScope() == null : this.getDataScope().equals(other.getDataScope()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()))
            && (this.getCreateBy() == null ? other.getCreateBy() == null : this.getCreateBy().equals(other.getCreateBy()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpdateBy() == null ? other.getUpdateBy() == null : this.getUpdateBy().equals(other.getUpdateBy()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getRemark() == null ? other.getRemark() == null : this.getRemark().equals(other.getRemark()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getRoleName() == null) ? 0 : getRoleName().hashCode());
        result = prime * result + ((getRoleKey() == null) ? 0 : getRoleKey().hashCode());
        result = prime * result + ((getRoleSort() == null) ? 0 : getRoleSort().hashCode());
        result = prime * result + ((getDataScope() == null) ? 0 : getDataScope().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
        result = prime * result + ((getCreateBy() == null) ? 0 : getCreateBy().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateBy() == null) ? 0 : getUpdateBy().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getRemark() == null) ? 0 : getRemark().hashCode());
        return result;
    }
}
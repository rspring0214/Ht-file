package com.huateng.user.dal.model;

import java.io.Serializable;
import java.util.Date;

public class UserInfo implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * VARCHAR(32) 必填<br>
     * 
     */
    private String id;

    /**
     * VARCHAR(32) 必填<br>
     * 租户ID
     */
    private String tenantId;

    /**
     * VARCHAR(50)<br>
     * 
     */
    private String tenantCode;

    /**
     * VARCHAR(32) 必填<br>
     * 部门ID
     */
    private String deptId;

    /**
     * VARCHAR(50)<br>
     * 
     */
    private String deptCode;

    /**
     * VARCHAR(64) 必填<br>
     * 登录账号
     */
    private String loginName;

    /**
     * VARCHAR(64)<br>
     * 用户昵称
     */
    private String userName;

    /**
     * DECIMAL(5) 默认值[1]<br>
     * 类型：1默认用户、2-非默认用户，默认为1
     */
    private Integer userType;

    /**
     * VARCHAR(100)<br>
     * 用户邮箱
     */
    private String email;

    /**
     * VARCHAR(20)<br>
     * 手机号码
     */
    private String phoneNumber;

    /**
     * DECIMAL(5) 默认值[3] 必填<br>
     * 性别：1-男、2-女、3-未知
     */
    private Integer sex;

    /**
     * VARCHAR(100)<br>
     * 
     */
    private String avatar;

    /**
     * VARCHAR(100) 必填<br>
     * 密码
     */
    private String password;

    /**
     * VARCHAR(100)<br>
     * 加密盐
     */
    private String salt;

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 帐号状态：1-正常、2-禁用/锁定，默认为1
     */
    private Integer status;

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 删除标记：1-正常、2-逻辑删除，默认为1
     */
    private Integer delFlag;

    /**
     * VARCHAR(64)<br>
     * 创建者
     */
    private String createBy;

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 创建时间
     */
    private Date createTime;

    /**
     * VARCHAR(64)<br>
     * 更新者
     */
    private String updateBy;

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 更新时间
     */
    private Date updateTime;

    /**
     * VARCHAR(500)<br>
     * 
     */
    private String remark;

    /**
     * VARCHAR(32) 必填<br>
     * 获得 
     */
    public String getId() {
        return id;
    }

    /**
     * VARCHAR(32) 必填<br>
     * 设置 
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * VARCHAR(32) 必填<br>
     * 获得 租户ID
     */
    public String getTenantId() {
        return tenantId;
    }

    /**
     * VARCHAR(32) 必填<br>
     * 设置 租户ID
     */
    public void setTenantId(String tenantId) {
        this.tenantId = tenantId == null ? null : tenantId.trim();
    }

    /**
     * VARCHAR(50)<br>
     * 获得 
     */
    public String getTenantCode() {
        return tenantCode;
    }

    /**
     * VARCHAR(50)<br>
     * 设置 
     */
    public void setTenantCode(String tenantCode) {
        this.tenantCode = tenantCode == null ? null : tenantCode.trim();
    }

    /**
     * VARCHAR(32) 必填<br>
     * 获得 部门ID
     */
    public String getDeptId() {
        return deptId;
    }

    /**
     * VARCHAR(32) 必填<br>
     * 设置 部门ID
     */
    public void setDeptId(String deptId) {
        this.deptId = deptId == null ? null : deptId.trim();
    }

    /**
     * VARCHAR(50)<br>
     * 获得 
     */
    public String getDeptCode() {
        return deptCode;
    }

    /**
     * VARCHAR(50)<br>
     * 设置 
     */
    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode == null ? null : deptCode.trim();
    }

    /**
     * VARCHAR(64) 必填<br>
     * 获得 登录账号
     */
    public String getLoginName() {
        return loginName;
    }

    /**
     * VARCHAR(64) 必填<br>
     * 设置 登录账号
     */
    public void setLoginName(String loginName) {
        this.loginName = loginName == null ? null : loginName.trim();
    }

    /**
     * VARCHAR(64)<br>
     * 获得 用户昵称
     */
    public String getUserName() {
        return userName;
    }

    /**
     * VARCHAR(64)<br>
     * 设置 用户昵称
     */
    public void setUserName(String userName) {
        this.userName = userName == null ? null : userName.trim();
    }

    /**
     * DECIMAL(5) 默认值[1]<br>
     * 获得 类型：1默认用户、2-非默认用户，默认为1
     */
    public Integer getUserType() {
        return userType;
    }

    /**
     * DECIMAL(5) 默认值[1]<br>
     * 设置 类型：1默认用户、2-非默认用户，默认为1
     */
    public void setUserType(Integer userType) {
        this.userType = userType;
    }

    /**
     * VARCHAR(100)<br>
     * 获得 用户邮箱
     */
    public String getEmail() {
        return email;
    }

    /**
     * VARCHAR(100)<br>
     * 设置 用户邮箱
     */
    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    /**
     * VARCHAR(20)<br>
     * 获得 手机号码
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * VARCHAR(20)<br>
     * 设置 手机号码
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber == null ? null : phoneNumber.trim();
    }

    /**
     * DECIMAL(5) 默认值[3] 必填<br>
     * 获得 性别：1-男、2-女、3-未知
     */
    public Integer getSex() {
        return sex;
    }

    /**
     * DECIMAL(5) 默认值[3] 必填<br>
     * 设置 性别：1-男、2-女、3-未知
     */
    public void setSex(Integer sex) {
        this.sex = sex;
    }

    /**
     * VARCHAR(100)<br>
     * 获得 
     */
    public String getAvatar() {
        return avatar;
    }

    /**
     * VARCHAR(100)<br>
     * 设置 
     */
    public void setAvatar(String avatar) {
        this.avatar = avatar == null ? null : avatar.trim();
    }

    /**
     * VARCHAR(100) 必填<br>
     * 获得 密码
     */
    public String getPassword() {
        return password;
    }

    /**
     * VARCHAR(100) 必填<br>
     * 设置 密码
     */
    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    /**
     * VARCHAR(100)<br>
     * 获得 加密盐
     */
    public String getSalt() {
        return salt;
    }

    /**
     * VARCHAR(100)<br>
     * 设置 加密盐
     */
    public void setSalt(String salt) {
        this.salt = salt == null ? null : salt.trim();
    }

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 获得 帐号状态：1-正常、2-禁用/锁定，默认为1
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 设置 帐号状态：1-正常、2-禁用/锁定，默认为1
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 获得 删除标记：1-正常、2-逻辑删除，默认为1
     */
    public Integer getDelFlag() {
        return delFlag;
    }

    /**
     * DECIMAL(5) 默认值[1] 必填<br>
     * 设置 删除标记：1-正常、2-逻辑删除，默认为1
     */
    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    /**
     * VARCHAR(64)<br>
     * 获得 创建者
     */
    public String getCreateBy() {
        return createBy;
    }

    /**
     * VARCHAR(64)<br>
     * 设置 创建者
     */
    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 获得 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 设置 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * VARCHAR(64)<br>
     * 获得 更新者
     */
    public String getUpdateBy() {
        return updateBy;
    }

    /**
     * VARCHAR(64)<br>
     * 设置 更新者
     */
    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 获得 更新时间
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 设置 更新时间
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    /**
     * VARCHAR(500)<br>
     * 获得 
     */
    public String getRemark() {
        return remark;
    }

    /**
     * VARCHAR(500)<br>
     * 设置 
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", tenantId=").append(tenantId);
        sb.append(", tenantCode=").append(tenantCode);
        sb.append(", deptId=").append(deptId);
        sb.append(", deptCode=").append(deptCode);
        sb.append(", loginName=").append(loginName);
        sb.append(", userName=").append(userName);
        sb.append(", userType=").append(userType);
        sb.append(", email=").append(email);
        sb.append(", phoneNumber=").append(phoneNumber);
        sb.append(", sex=").append(sex);
        sb.append(", avatar=").append(avatar);
        sb.append(", password=").append(password);
        sb.append(", salt=").append(salt);
        sb.append(", status=").append(status);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", remark=").append(remark);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        UserInfo other = (UserInfo) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getTenantId() == null ? other.getTenantId() == null : this.getTenantId().equals(other.getTenantId()))
            && (this.getTenantCode() == null ? other.getTenantCode() == null : this.getTenantCode().equals(other.getTenantCode()))
            && (this.getDeptId() == null ? other.getDeptId() == null : this.getDeptId().equals(other.getDeptId()))
            && (this.getDeptCode() == null ? other.getDeptCode() == null : this.getDeptCode().equals(other.getDeptCode()))
            && (this.getLoginName() == null ? other.getLoginName() == null : this.getLoginName().equals(other.getLoginName()))
            && (this.getUserName() == null ? other.getUserName() == null : this.getUserName().equals(other.getUserName()))
            && (this.getUserType() == null ? other.getUserType() == null : this.getUserType().equals(other.getUserType()))
            && (this.getEmail() == null ? other.getEmail() == null : this.getEmail().equals(other.getEmail()))
            && (this.getPhoneNumber() == null ? other.getPhoneNumber() == null : this.getPhoneNumber().equals(other.getPhoneNumber()))
            && (this.getSex() == null ? other.getSex() == null : this.getSex().equals(other.getSex()))
            && (this.getAvatar() == null ? other.getAvatar() == null : this.getAvatar().equals(other.getAvatar()))
            && (this.getPassword() == null ? other.getPassword() == null : this.getPassword().equals(other.getPassword()))
            && (this.getSalt() == null ? other.getSalt() == null : this.getSalt().equals(other.getSalt()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()))
            && (this.getCreateBy() == null ? other.getCreateBy() == null : this.getCreateBy().equals(other.getCreateBy()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpdateBy() == null ? other.getUpdateBy() == null : this.getUpdateBy().equals(other.getUpdateBy()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getRemark() == null ? other.getRemark() == null : this.getRemark().equals(other.getRemark()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getTenantId() == null) ? 0 : getTenantId().hashCode());
        result = prime * result + ((getTenantCode() == null) ? 0 : getTenantCode().hashCode());
        result = prime * result + ((getDeptId() == null) ? 0 : getDeptId().hashCode());
        result = prime * result + ((getDeptCode() == null) ? 0 : getDeptCode().hashCode());
        result = prime * result + ((getLoginName() == null) ? 0 : getLoginName().hashCode());
        result = prime * result + ((getUserName() == null) ? 0 : getUserName().hashCode());
        result = prime * result + ((getUserType() == null) ? 0 : getUserType().hashCode());
        result = prime * result + ((getEmail() == null) ? 0 : getEmail().hashCode());
        result = prime * result + ((getPhoneNumber() == null) ? 0 : getPhoneNumber().hashCode());
        result = prime * result + ((getSex() == null) ? 0 : getSex().hashCode());
        result = prime * result + ((getAvatar() == null) ? 0 : getAvatar().hashCode());
        result = prime * result + ((getPassword() == null) ? 0 : getPassword().hashCode());
        result = prime * result + ((getSalt() == null) ? 0 : getSalt().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
        result = prime * result + ((getCreateBy() == null) ? 0 : getCreateBy().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateBy() == null) ? 0 : getUpdateBy().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getRemark() == null) ? 0 : getRemark().hashCode());
        return result;
    }
}
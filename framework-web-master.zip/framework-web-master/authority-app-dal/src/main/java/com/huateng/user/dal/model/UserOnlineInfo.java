package com.huateng.user.dal.model;

import java.io.Serializable;
import java.util.Date;

public class UserOnlineInfo implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * VARCHAR(32) 必填<br>
     * 
     */
    private String id;

    /**
     * VARCHAR(50) 必填<br>
     * 用户会话ID
     */
    private String sessionId;

    /**
     * VARCHAR(64) 必填<br>
     * 登录账号
     */
    private String loginName;

    /**
     * VARCHAR(32)<br>
     * 组织机构ID
     */
    private String deptId;

    /**
     * VARCHAR(64)<br>
     * 组织机构名称
     */
    private String deptName;

    /**
     * VARCHAR(50)<br>
     * 登录IP地址
     */
    private String ipaddr;

    /**
     * VARCHAR(255)<br>
     * 登录坐标
     */
    private String loginLocation;

    /**
     * VARCHAR(50)<br>
     * 浏览器类型
     */
    private String browser;

    /**
     * VARCHAR(50)<br>
     * 操作系统
     */
    private String os;

    /**
     * DECIMAL(5) 必填<br>
     * 在线状态：1-在线、2-离线
     */
    private Integer status;

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * SESSION创建时间
     */
    private Date startTimestamp;

    /**
     * TIMESTAMP(19) 默认值[0000-00-00 00:00:00] 必填<br>
     * SESSION最后访问时间
     */
    private Date lastAccessTime;

    /**
     * INTEGER(10) 默认值[0]<br>
     * 超时时间，单位为分钟
     */
    private Integer expireTime;

    /**
     * TIMESTAMP(19) 默认值[0000-00-00 00:00:00] 必填<br>
     * 超时时间
     */
    private Date exExpireTime;

    /**
     * VARCHAR(32) 必填<br>
     * 获得 
     */
    public String getId() {
        return id;
    }

    /**
     * VARCHAR(32) 必填<br>
     * 设置 
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * VARCHAR(50) 必填<br>
     * 获得 用户会话ID
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * VARCHAR(50) 必填<br>
     * 设置 用户会话ID
     */
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId == null ? null : sessionId.trim();
    }

    /**
     * VARCHAR(64) 必填<br>
     * 获得 登录账号
     */
    public String getLoginName() {
        return loginName;
    }

    /**
     * VARCHAR(64) 必填<br>
     * 设置 登录账号
     */
    public void setLoginName(String loginName) {
        this.loginName = loginName == null ? null : loginName.trim();
    }

    /**
     * VARCHAR(32)<br>
     * 获得 组织机构ID
     */
    public String getDeptId() {
        return deptId;
    }

    /**
     * VARCHAR(32)<br>
     * 设置 组织机构ID
     */
    public void setDeptId(String deptId) {
        this.deptId = deptId == null ? null : deptId.trim();
    }

    /**
     * VARCHAR(64)<br>
     * 获得 组织机构名称
     */
    public String getDeptName() {
        return deptName;
    }

    /**
     * VARCHAR(64)<br>
     * 设置 组织机构名称
     */
    public void setDeptName(String deptName) {
        this.deptName = deptName == null ? null : deptName.trim();
    }

    /**
     * VARCHAR(50)<br>
     * 获得 登录IP地址
     */
    public String getIpaddr() {
        return ipaddr;
    }

    /**
     * VARCHAR(50)<br>
     * 设置 登录IP地址
     */
    public void setIpaddr(String ipaddr) {
        this.ipaddr = ipaddr == null ? null : ipaddr.trim();
    }

    /**
     * VARCHAR(255)<br>
     * 获得 登录坐标
     */
    public String getLoginLocation() {
        return loginLocation;
    }

    /**
     * VARCHAR(255)<br>
     * 设置 登录坐标
     */
    public void setLoginLocation(String loginLocation) {
        this.loginLocation = loginLocation == null ? null : loginLocation.trim();
    }

    /**
     * VARCHAR(50)<br>
     * 获得 浏览器类型
     */
    public String getBrowser() {
        return browser;
    }

    /**
     * VARCHAR(50)<br>
     * 设置 浏览器类型
     */
    public void setBrowser(String browser) {
        this.browser = browser == null ? null : browser.trim();
    }

    /**
     * VARCHAR(50)<br>
     * 获得 操作系统
     */
    public String getOs() {
        return os;
    }

    /**
     * VARCHAR(50)<br>
     * 设置 操作系统
     */
    public void setOs(String os) {
        this.os = os == null ? null : os.trim();
    }

    /**
     * DECIMAL(5) 必填<br>
     * 获得 在线状态：1-在线、2-离线
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * DECIMAL(5) 必填<br>
     * 设置 在线状态：1-在线、2-离线
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 获得 SESSION创建时间
     */
    public Date getStartTimestamp() {
        return startTimestamp;
    }

    /**
     * TIMESTAMP(19) 默认值[CURRENT_TIMESTAMP] 必填<br>
     * 设置 SESSION创建时间
     */
    public void setStartTimestamp(Date startTimestamp) {
        this.startTimestamp = startTimestamp;
    }

    /**
     * TIMESTAMP(19) 默认值[0000-00-00 00:00:00] 必填<br>
     * 获得 SESSION最后访问时间
     */
    public Date getLastAccessTime() {
        return lastAccessTime;
    }

    /**
     * TIMESTAMP(19) 默认值[0000-00-00 00:00:00] 必填<br>
     * 设置 SESSION最后访问时间
     */
    public void setLastAccessTime(Date lastAccessTime) {
        this.lastAccessTime = lastAccessTime;
    }

    /**
     * INTEGER(10) 默认值[0]<br>
     * 获得 超时时间，单位为分钟
     */
    public Integer getExpireTime() {
        return expireTime;
    }

    /**
     * INTEGER(10) 默认值[0]<br>
     * 设置 超时时间，单位为分钟
     */
    public void setExpireTime(Integer expireTime) {
        this.expireTime = expireTime;
    }

    /**
     * TIMESTAMP(19) 默认值[0000-00-00 00:00:00] 必填<br>
     * 获得 超时时间
     */
    public Date getExExpireTime() {
        return exExpireTime;
    }

    /**
     * TIMESTAMP(19) 默认值[0000-00-00 00:00:00] 必填<br>
     * 设置 超时时间
     */
    public void setExExpireTime(Date exExpireTime) {
        this.exExpireTime = exExpireTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", sessionId=").append(sessionId);
        sb.append(", loginName=").append(loginName);
        sb.append(", deptId=").append(deptId);
        sb.append(", deptName=").append(deptName);
        sb.append(", ipaddr=").append(ipaddr);
        sb.append(", loginLocation=").append(loginLocation);
        sb.append(", browser=").append(browser);
        sb.append(", os=").append(os);
        sb.append(", status=").append(status);
        sb.append(", startTimestamp=").append(startTimestamp);
        sb.append(", lastAccessTime=").append(lastAccessTime);
        sb.append(", expireTime=").append(expireTime);
        sb.append(", exExpireTime=").append(exExpireTime);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        UserOnlineInfo other = (UserOnlineInfo) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getSessionId() == null ? other.getSessionId() == null : this.getSessionId().equals(other.getSessionId()))
            && (this.getLoginName() == null ? other.getLoginName() == null : this.getLoginName().equals(other.getLoginName()))
            && (this.getDeptId() == null ? other.getDeptId() == null : this.getDeptId().equals(other.getDeptId()))
            && (this.getDeptName() == null ? other.getDeptName() == null : this.getDeptName().equals(other.getDeptName()))
            && (this.getIpaddr() == null ? other.getIpaddr() == null : this.getIpaddr().equals(other.getIpaddr()))
            && (this.getLoginLocation() == null ? other.getLoginLocation() == null : this.getLoginLocation().equals(other.getLoginLocation()))
            && (this.getBrowser() == null ? other.getBrowser() == null : this.getBrowser().equals(other.getBrowser()))
            && (this.getOs() == null ? other.getOs() == null : this.getOs().equals(other.getOs()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getStartTimestamp() == null ? other.getStartTimestamp() == null : this.getStartTimestamp().equals(other.getStartTimestamp()))
            && (this.getLastAccessTime() == null ? other.getLastAccessTime() == null : this.getLastAccessTime().equals(other.getLastAccessTime()))
            && (this.getExpireTime() == null ? other.getExpireTime() == null : this.getExpireTime().equals(other.getExpireTime()))
            && (this.getExExpireTime() == null ? other.getExExpireTime() == null : this.getExExpireTime().equals(other.getExExpireTime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getSessionId() == null) ? 0 : getSessionId().hashCode());
        result = prime * result + ((getLoginName() == null) ? 0 : getLoginName().hashCode());
        result = prime * result + ((getDeptId() == null) ? 0 : getDeptId().hashCode());
        result = prime * result + ((getDeptName() == null) ? 0 : getDeptName().hashCode());
        result = prime * result + ((getIpaddr() == null) ? 0 : getIpaddr().hashCode());
        result = prime * result + ((getLoginLocation() == null) ? 0 : getLoginLocation().hashCode());
        result = prime * result + ((getBrowser() == null) ? 0 : getBrowser().hashCode());
        result = prime * result + ((getOs() == null) ? 0 : getOs().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getStartTimestamp() == null) ? 0 : getStartTimestamp().hashCode());
        result = prime * result + ((getLastAccessTime() == null) ? 0 : getLastAccessTime().hashCode());
        result = prime * result + ((getExpireTime() == null) ? 0 : getExpireTime().hashCode());
        result = prime * result + ((getExExpireTime() == null) ? 0 : getExExpireTime().hashCode());
        return result;
    }
}
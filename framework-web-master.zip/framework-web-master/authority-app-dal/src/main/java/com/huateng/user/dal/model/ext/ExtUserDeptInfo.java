/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.dal.model.ext;

import java.io.Serializable;

/**
 * Description:用户、机构、角色关联表的用户机构扩展对象
 *
 * @author Heaven.tang
 * @version $Id: ExtUserDeptInfo.java, v 0.1 2019年8月6日 上午11:15:18 Heaven.tang Exp $
 */
public class ExtUserDeptInfo implements Serializable {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = 7155519464202249477L;

	private String userId;
	
	private String userName;
	
	private String deptId;
	
	private String deptName;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
}

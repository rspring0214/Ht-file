/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.dal.model.ext;

import java.util.List;

import com.huateng.user.dal.model.DeptInfo;
import com.huateng.user.dal.model.RoleInfo;
import com.huateng.user.dal.model.UserInfo;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: ExtUserInfo.java, v 0.1 2019年4月4日 下午3:05:41 Heaven.tang Exp $
 */
public class ExtUserInfo extends UserInfo {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = -7839861732340250212L;
	
	/** 
	 * 组织机构对象
	 */
    private DeptInfo dept;

    /**
     * 角色对象集
     */
    private List<RoleInfo> roles;

    /** 
     * 角色组ID
     */
    private String[] roleIds;

    /** 
     * 岗位组ID
     */
    private String[] postIds;

	public DeptInfo getDept() {
		return dept;
	}

	public void setDept(DeptInfo dept) {
		this.dept = dept;
	}

	public List<RoleInfo> getRoles() {
		return roles;
	}

	public void setRoles(List<RoleInfo> roles) {
		this.roles = roles;
	}

	public String[] getRoleIds() {
		return roleIds;
	}

	public void setRoleIds(String[] roleIds) {
		this.roleIds = roleIds;
	}

	public String[] getPostIds() {
		return postIds;
	}

	public void setPostIds(String[] postIds) {
		this.postIds = postIds;
	}
	
}

package com.huateng.user.web.controller.security;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.user.api.annotations.OperLog;
import com.huateng.user.api.annotations.SecurityChecker;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.core.service.ConfigInfoService;
import com.huateng.user.dal.model.ConfigInfo;

@RequestMapping("/s/configInfo")
@Controller
public class ConfigInfoController {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private ConfigInfoService configInfoService;

	@RequestMapping("showList")
	public String showList(ModelMap model) {
		return "configInfo/list";
	}

	@RequestMapping("search")
	@SecurityChecker("user:configInfo:search")
	public @ResponseBody ApiBaseResponse<PageInfo<ConfigInfo>> search(ConfigInfo configInfo, PageInfo<ConfigInfo> page) {
		if (page == null) {
			page = new PageInfo<ConfigInfo>();
		}
		configInfoService.findConfigInfo(configInfo, page);
		return new ApiBaseResponse<PageInfo<ConfigInfo>>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, page);
	}

	@RequestMapping("addPre")
	@SecurityChecker("user:configInfo:add")
	public String addPre(ModelMap model, String id) {
		if (StringUtils.isNotBlank(id)) {
			ConfigInfo configInfo = configInfoService.findById(id);
			model.put("edit", configInfo);
		}
		return "configInfo/save";
	}

	@RequestMapping("editPre")
	@SecurityChecker("user:configInfo:edit")
	public String editPre(ModelMap model, String id) {
		return addPre(model, id);
	}

	@RequestMapping("checkConfigKeyUnique")
	public @ResponseBody ApiBaseResponse<Boolean> checkConfigKeyUnique(String id, String configKey) {
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, configInfoService.checkConfigKeyUnique(id, configKey));
	}

	@RequestMapping("save")
	@OperLog(functionName="保存",menuName="配置管理")
	public @ResponseBody ApiBaseResponse<Boolean> save(ConfigInfo configInfo) {
		try {
			configInfoService.saveConfigInfo(configInfo);
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
					Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
		} catch (Exception e) {
			logger.error("save Exception ", e);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL,
				Constants.API_RESPONSE_FAIL_MESSAGE, false);
	}
	
	/**
	 * 删除参数配置
	 */
	@SecurityChecker("user:configInfo:remove")
	@RequestMapping( "/remove")
	@ResponseBody
	@OperLog(functionName="删除",menuName="配置管理")
	public ApiBaseResponse<Boolean> remove(String ids) {
		int num = 0;
		try {
			List<String> idList = Arrays.asList(ids.split(","));
			num = configInfoService.deleteConfigByIds(Arrays.asList(ids.split(",")));
			if (null != idList && num == idList.size()) {
				return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
						Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
			}
		} catch (Exception e) {
			logger.error("Delete config info by id exception ", e);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL,
				Constants.API_RESPONSE_FAIL_MESSAGE, false);
	}
}

/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.web.controller.security;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.user.api.annotations.OperLog;
import com.huateng.user.api.annotations.SecurityChecker;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.api.utils.Echo;
import com.huateng.user.api.utils.UserUtils;
import com.huateng.user.core.service.DeptInfoService;
import com.huateng.user.core.service.TenantInfoService;
import com.huateng.user.core.service.UserDeptRoleService;
import com.huateng.user.dal.model.DeptInfo;
import com.huateng.user.dal.model.RoleInfo;
import com.huateng.user.web.model.DeptInfoVo;

/**
 * Description:组织机构
 *
 * @author Heaven.tang
 * @version $Id: DeptInfoController.java, v 0.1 2019年3月28日 下午3:33:30 Heaven.tang Exp $
 */
@RequestMapping("/s/deptInfo")
@Controller
public class DeptInfoController {

	private static final Logger logger = LoggerFactory.getLogger(DeptInfoController.class);
	
	@Autowired
	private DeptInfoService deptService;
	
	@Autowired
	private TenantInfoService tenantService;
	
	@Autowired
	private UserDeptRoleService userDeptRoleService;
	
	@Value("${multiple.corporate:false}")
	private boolean multipleCorporate;
	
	@SecurityChecker("user:deptInfo:view")
	@RequestMapping("/showList")
	public String dept(ModelMap model) {
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		
		// 如果超级管理员时需要给出可选租户
		if (UserUtils.isAdmin(user)) {
			model.put("tenants", tenantService.selectTenants(Constants.COMMON_VALID));
			model.put("isAdmin", true);
		} else {
			model.put("isAdmin", false);
		}
		
		return "deptInfo/list";
	}

	@SecurityChecker("user:deptInfo:search")
	@RequestMapping("/search")
	@ResponseBody
	public ApiBaseResponse<List<DeptInfoVo>> search(DeptInfo deptInfo) throws Exception {
		
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();

		List<DeptInfoVo> listVo = new ArrayList<DeptInfoVo>();
		// 根据当前用户，查询出结果
		List<DeptInfo> list = null;
		list = deptService.search(deptInfo);
		for(DeptInfo d : list){
			DeptInfoVo deptInfoVo = new DeptInfoVo();
			BeanUtilsBean.getInstance().copyProperties(deptInfoVo, d);
			listVo.add(deptInfoVo);
		}
		
		// 操作选项是否显示处理
		if(!UserUtils.isAdmin(user)){
			
			List<String> set = new ArrayList<String>();
			deptService.getAncestorId(user.getLoginDept().getId(), set);
			set.remove(user.getBelongDept().getId());
			
			for(DeptInfoVo d : listVo){
				if(set.contains(d.getId())){
					d.setShowOper(false);
				} else {
					d.setShowOper(true);
				}
			}
		} else {
			for(DeptInfoVo d : listVo){
				d.setShowOper(true);
			}
		}
		
		return new ApiBaseResponse<List<DeptInfoVo>>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, listVo);
	}

	/**
	 * 新增
	 */
	@RequestMapping("/addPre")
	public String add(ModelMap model, String id) {
		model.put("parentId", id);
		return "deptInfo/add";
	}

	/**
	 * 新增保存组织机构
	 */
	@SecurityChecker("user:deptInfo:add")
	@RequestMapping("/add")
	@ResponseBody
	@OperLog(functionName="新增",menuName="组织机构管理")
	public ApiBaseResponse<Boolean> addSave(DeptInfo deptInfo) {
		int rows = 0;
		try {
			rows = deptService.insertDept(deptInfo);
			System.out.println(rows);
		} catch (Exception e) {
			logger.error("insert dept info error, cause ", e);
			return Echo.toFail(e);
		}
		if (rows != 1) {
			logger.error("insert dept info error, expected 1 but {}", rows);
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, Constants.API_RESPONSE_FAIL_MESSAGE, false);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}
	
	/**
	 * 修改组织机构
	 */
	@RequestMapping("/editPre")
	public String edit(ModelMap model, String id) {
		DeptInfo dept = deptService.selectDeptById(id);
		DeptInfoVo deptVo = new DeptInfoVo();
		
		BeanUtils.copyProperties(dept, deptVo);
		
		String parentName = "";
		if(dept.getParentId().equals("0")){
			parentName = tenantService.selectByPrimaryKey(dept.getTenantId()).getTenantName();
		} else {
			parentName = deptService.selectDeptById(dept.getParentId()).getDeptName();
		}
		deptVo.setParentName(parentName);
		
		model.put("dept", deptVo);
		
		return "deptInfo/edit";
	}

	/**
	 * 修改保存组织机构
	 */
	@SecurityChecker("user:deptInfo:edit")
	@RequestMapping("/edit")
	@ResponseBody
	@OperLog(functionName="修改",menuName="组织机构管理")
	public ApiBaseResponse<Boolean> editSave(DeptInfo dept) {
		
		dept.setUpdateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
		
		if (dept.getStatus().intValue() == Constants.COMMON_INVALID.intValue()) {
			String rst = deptCloseCheck(dept.getId());
			if (StringUtils.isNotBlank(rst)) {
				return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, rst, false);
			}
		}
		int u = deptService.updateDept(dept);
		if (u != 1) {
			logger.error("update dept info error, expected 1 but {}", u);
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, Constants.API_RESPONSE_FAIL_MESSAGE, false);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}

	private String deptCloseCheck(String id) {
		if (deptService.countDeptByParentId(id) > 0) {
			return "存在下级组织机构,不允许删除";
		}
		if (deptService.countUsersByDeptId(id) > 0) {
			return "组织机构存在用户,不允许删除";
		}
		return null;
	}
	
	/**
	 * 删除组织机构
	 */
	@SecurityChecker("user:deptInfo:remove")
	@RequestMapping("/remove")
	@ResponseBody
	@OperLog(functionName="删除",menuName="组织机构管理")
	public ApiBaseResponse<Boolean> remove(String id) {
		String rst = deptCloseCheck(id);
		if (StringUtils.isNotBlank(rst)) {
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, rst, false);
		}
		// 实际更新了标识为失效
		boolean del = deptService.deleteDeptById(id) > 0 ? true : false;
		if (!del) {
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, Constants.API_RESPONSE_FAIL_MESSAGE, false);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}

	/**
	 * 校验组织机构名称
	 */
	@RequestMapping("/checkDeptNameUnique")
	@ResponseBody
	public ApiBaseResponse<Boolean> checkDeptNameUnique(DeptInfo deptInfo) {
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, deptService.checkDeptNameUnique(deptInfo));
	}
	/**
	 * 校验组织机构编码
	 */
	@RequestMapping("/checkDeptCodeUnique")
	@ResponseBody
	public ApiBaseResponse<Boolean> checkDeptCodeUnique(DeptInfo deptInfo) {
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, deptService.checkDeptCodeUnique(deptInfo));
	}

	/**
	 * 选择组织机构树
	 */
	@RequestMapping("/selectDeptTree")
	public String selectDeptTree(ModelMap model, String id, String tenantId) {
		if (StringUtils.isNotBlank(id)) {
			DeptInfo dept = deptService.selectDeptById(id);
			if (null != dept) {
				model.put("dept", dept);
				tenantId = dept.getTenantId();
			}
		}
		if (StringUtils.isNotBlank(tenantId)) {
			model.put("tenantId", tenantId);
		}
		return "deptInfo/tree";
	}
	
	/**
	 * 加载组织机构列表树
	 */
	@RequestMapping("/deptTreeData")
	@ResponseBody
	public List<Map<String, Object>> deptTreeData(String id, String tenantId, boolean tenantSupport) {
		// XXX 因为将租户和组织机构的结构分离（这种设计不合理，租户本身也是组织机构，使得数据结构的展示以及数据之间的关系处理起来更为复杂），
		// 而租户下不允许建用户（这种设计下租户成为标识性的信息，创建在机构下的数据都不能在租户下创建，否则需要在所有的地方合并租户信息和机构信息）
		if (StringUtils.isBlank(id) || StringUtils.isEmpty(tenantId)) {
			SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
			if (!UserUtils.isAdmin(user)) {
				tenantId = StringUtils.isBlank(tenantId) ? user.getTenantId() : tenantId;
				id = StringUtils.isBlank(id) ? user.getLoginDept().getId() : id;
			}
		}
		return deptService.deptTreeData(id, tenantId, tenantSupport);
	}
	
	/**
	 * 加载角色组织机构列表树
	 */
	@RequestMapping("/roleDeptTreeData")
	@ResponseBody
	public List<Map<String, Object>> roleDeptTreeData(RoleInfo roleInfo) {
		List<Map<String, Object>> tree = deptService.roleDeptTreeData(roleInfo);
		return tree;
	}

	@RequestMapping("/checkNoSon")
	@ResponseBody
	public ApiBaseResponse<Boolean> checkNoSon(String tenantId) {
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, deptService.checkNoSon(tenantId));
	}
	
	@RequestMapping("/checkSonStatus")
	@ResponseBody
	public ApiBaseResponse<Boolean> checkSonStatus(String id, Integer status, Integer oldStatus) {
		boolean result = true;
		// 由无效改为有效时需要检查子集机构是否都有效
		if (Constants.COMMON_VALID.intValue() == status.intValue() && oldStatus.intValue() != status.intValue()) {
			int subCount = deptService.countDeptByAncestorId(id, Constants.COMMON_INVALID);
			if (subCount > 0) {
				logger.warn("Invalid son dept exists, cur deptId : {}", id);
				result = false;
			}
		}
		// 有效改为无效是否需要检查自行决定...
		
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, result);
	}
	
	/**
	 * 加载组织机构列表树，使用户所属同机构的机构不可选
	 */
	@RequestMapping("/deptTreeDataWithDisabled")
	@ResponseBody
	public List<Map<String, Object>> deptTreeDataWithDisabled(String id, String tenantId, boolean tenantSupport, String userId) {
		List<Map<String, Object>> data = deptTreeData(id, tenantId, tenantSupport);
		// 查询该用户所有的任职机构
		List<String> list = userDeptRoleService.selectDistinctUserDept(userId);
		for (String deptId : list) {
			for (Map<String, Object> map : data) {
				if (StringUtils.equals((String) map.get("id"), deptId)) {
					map.put("disabled", 1);
				}
			}
		}
		
		return data;
	}
	
	/**
	 * 加载组织机构列表树，使用户所属同机构的机构不可选
	 */
	@RequestMapping("/deptTree4DeptNew")
	@ResponseBody
	public List<Map<String, Object>> deptTree4DeptNew(String parentId) {
		String tenantId = null;
		String id = null;
		
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		if (!UserUtils.isAdmin(user)) {
			tenantId = user.getTenantId();
			id = user.getLoginDept().getId();
		}
		
		List<Map<String, Object>> trees = deptService.deptTreeData4DeptNew(id, tenantId, multipleCorporate);
		if(StringUtils.isNotBlank(parentId)){
			for (Map<String, Object> map : trees) {
				if (parentId.equals(map.get("id"))) {
					map.put("checked", true);	
				}
			}
		}
		
		return trees;
	}
	/**
	 * 加载组织机构列表树，使用户所属同机构的机构不可选
	 */
	@RequestMapping("/deptTree4UserQuery")
	@ResponseBody
	public List<Map<String, Object>> deptTree4UserQuery(String id, String tenantId, boolean tenantSupport, String userId) {
		
		id = null;
		tenantId = null;
		tenantSupport = true;
		
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		if (StringUtils.isBlank(id) || StringUtils.isEmpty(tenantId)) {
			if (!UserUtils.isAdmin(user)) {
				tenantId = StringUtils.isBlank(tenantId) ? user.getTenantId() : tenantId;
				id = StringUtils.isBlank(id) ? user.getLoginDept().getId() : id;
			}
		}
		
		List<Map<String, Object>> trees = deptService.deptTree4UserQuery(id, tenantId, tenantSupport);
		if(UserUtils.isAdmin(user)){
			for (Map<String, Object> map : trees) {
				if (map.get("pId").equals(Constants.ROOT_ID)) {
					map.put("disabled", "1");
				}
			}
		}
		return trees;
	}
	/**
	 * 加载组织机构列表树，使用户所属同机构的机构不可选
	 */
	@RequestMapping("/deptTree4UserNew")
	@ResponseBody
	public List<Map<String, Object>> deptTree4UserNew(String id, String tenantId, boolean tenantSupport, String userId) {
		
		
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		id = null;
		tenantId = null;
		tenantSupport = true;
		
		if (StringUtils.isBlank(id) || StringUtils.isEmpty(tenantId)) {
			if (!UserUtils.isAdmin(user)) {
				tenantId = StringUtils.isBlank(tenantId) ? user.getTenantId() : tenantId;
				id = StringUtils.isBlank(id) ? user.getLoginDept().getId() : id;
			}
		}
		
		List<Map<String, Object>> trees = deptService.deptTreeData4UserNew(id, tenantId, tenantSupport);
		
		
		if (UserUtils.isAdmin(user)) {
			for (Map<String, Object> map : trees) {
				if (map.get("pId").equals(Constants.ROOT_ID)) {
					map.put("disabled", "1");
				}
			}
		} else {
			List<String> ids = new ArrayList<String>();
			deptService.getAncestorId(user.getLoginDept().getId(), ids);
			ids.remove(user.getLoginDept().getId());
			for (Map<String, Object> map : trees) {
				if (ids.contains(map.get("id"))) {
					map.put("disabled", "1");
				}
			}
		}
		
		return trees;
	}
	
}

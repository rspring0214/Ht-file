package com.huateng.user.web.controller.security;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.user.api.annotations.OperLog;
import com.huateng.user.api.annotations.SecurityChecker;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.core.model.dictInfo.DictTypeData;
import com.huateng.user.core.model.dictInfo.DictTypeQuery;
import com.huateng.user.core.service.DictInfoService;
import com.huateng.user.dal.model.DictDataInfo;
import com.huateng.user.dal.model.DictTypeInfo;

@Controller
@RequestMapping("/s/dictInfo")
public class DictInfoController {
	
	private static final Logger logger = LoggerFactory.getLogger(DictInfoController.class);
	
	@Autowired
	private DictInfoService dictInfoService;
	
	@RequestMapping("showList")
	@SecurityChecker("user:dictInfo:search")
	public String showList(ModelMap model){
		return "dictInfo/list";
	}
	
	@RequestMapping("search")
	@SecurityChecker("user:dictInfo:search")
	public @ResponseBody ApiBaseResponse<PageInfo<DictTypeInfo>> search(ModelMap model ,DictTypeQuery typeQuery, PageInfo<DictTypeInfo> page){
		if (page == null) {
			page = new PageInfo<DictTypeInfo>();
		}
		dictInfoService.findTypeList(typeQuery, page);
		return new ApiBaseResponse<PageInfo<DictTypeInfo>>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, page);
	}
	
	private static String EDIT_CACHE_ID = "EDIT_CACHE_ID";
	
	@RequestMapping("addPre")
	@SecurityChecker("user:dictInfo:add")
	public String addPre(ModelMap model) {
		DictTypeData cacheObject = new DictTypeData();
		SSOClientUtils.getInstance().putObject(EDIT_CACHE_ID, cacheObject);
		model.put("edit", cacheObject);
		return "dictInfo/save";
	}

	@RequestMapping("editPre")
	@SecurityChecker("user:dictInfo:edit")
	public String editPre(ModelMap model, String id) {
		if (StringUtils.isNotBlank(id)) {
			DictTypeData typeData = dictInfoService.findByTypeId(id);
			SSOClientUtils.getInstance().putObject(EDIT_CACHE_ID, typeData);
			model.put("edit", typeData);
		}
		return "dictInfo/save";
	}

	@RequestMapping("checkDictTypeUnique")
	public @ResponseBody ApiBaseResponse<Boolean> checkDictTypeUnique(String id, String dictType) {
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, dictInfoService.checkDictTypeUnique(id, dictType));
	}

	@RequestMapping("save")
	@OperLog(functionName="保存",menuName="字典管理")
	public @ResponseBody ApiBaseResponse<Boolean> save(DictTypeInfo typeInfo) {
		try {
			DictTypeData cacheObject = SSOClientUtils.getInstance().getObject(EDIT_CACHE_ID, DictTypeData.class);
			BeanUtils.copyProperties(typeInfo, cacheObject);
			dictInfoService.saveDictTypeData(cacheObject);
			SSOClientUtils.getInstance().remove(EDIT_CACHE_ID);
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
					Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
		} catch (Exception e) {
			logger.error("save Exception ", e);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL,
				Constants.API_RESPONSE_FAIL_MESSAGE, false);
	}
	
	@RequestMapping("remove")
	@SecurityChecker("user:dictInfo:remove")
	@OperLog(functionName="删除",menuName="字典管理")
	public @ResponseBody ApiBaseResponse<Boolean> remove(ModelMap model , String[] ids){
		dictInfoService.removeType(ids);
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}
	
	@RequestMapping("searchDictData")
	public @ResponseBody ApiBaseResponse<PageInfo<DictDataInfo>> searchDictData(ModelMap model){
		DictTypeData cacheObject = SSOClientUtils.getInstance().getObject(EDIT_CACHE_ID, DictTypeData.class);
		if(cacheObject != null){
			PageInfo<DictDataInfo> pageInfo = new PageInfo<DictDataInfo>();
			pageInfo.setData(cacheObject.getDataList());
			return new ApiBaseResponse<PageInfo<DictDataInfo>>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
					Constants.API_RESPONSE_SUCCESS_MESSAGE, pageInfo);
		}
		return new ApiBaseResponse<PageInfo<DictDataInfo>>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL,
				"找不到被编辑的字典类型", null);
	}
	
	@RequestMapping("addDataPre")
	public String addDataPre(ModelMap model){
		return "dictInfo/dataSave";
	}
	
	@RequestMapping("editDataPre")
	public String editDataPre(ModelMap model , String id){
		if(StringUtils.isNotBlank(id)){
			DictTypeData cacheObject = SSOClientUtils.getInstance().getObject(EDIT_CACHE_ID, DictTypeData.class);
			for(DictDataInfo dataInfo : cacheObject.getDataList()){
				if(dataInfo.getId().equalsIgnoreCase(id)){
					model.put("edit", dataInfo);
					break;
				}
			}
		}
		return "dictInfo/dataSave";
	}
	
	@RequestMapping("saveData")
	public @ResponseBody ApiBaseResponse<Boolean> saveData(ModelMap model , DictDataInfo dataInfo){
		DictTypeData cacheObject = SSOClientUtils.getInstance().getObject(EDIT_CACHE_ID, DictTypeData.class);
		dataInfo.setDictType(cacheObject.getDictType());
		if (StringUtils.isNotBlank(dataInfo.getId())) {
			for (DictDataInfo item : cacheObject.getDataList()) {
				if (item.getId().equalsIgnoreCase(dataInfo.getId())) {
					BeanUtils.copyProperties(dataInfo, item);
					break;
				}
			}
		} else {
			dataInfo.setId("new"+RandomStringUtils.random(10));
			cacheObject.getDataList().add(dataInfo);
		}
		SSOClientUtils.getInstance().putObject(EDIT_CACHE_ID, cacheObject);
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}
	
	@RequestMapping("removeData")
	public @ResponseBody ApiBaseResponse<Boolean> removeData(ModelMap model, String[] ids){
		DictTypeData cacheObject = SSOClientUtils.getInstance().getObject(EDIT_CACHE_ID, DictTypeData.class);
		if (ids != null && ids.length > 0) {
			List<DictDataInfo> newList = new ArrayList<DictDataInfo>(10);
			List<String> idList = Arrays.asList(ids);
			for (DictDataInfo item : cacheObject.getDataList()) {
				if (idList != null && !idList.contains(item.getId())) {
					newList.add(item);
				}
			}
			cacheObject.setDataList(newList);
		}
		SSOClientUtils.getInstance().putObject(EDIT_CACHE_ID, cacheObject);
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}
	
}

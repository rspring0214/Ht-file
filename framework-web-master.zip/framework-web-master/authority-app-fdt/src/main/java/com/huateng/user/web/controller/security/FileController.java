package com.huateng.user.web.controller.security;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/s/common")
public class FileController {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@RequestMapping("/tempDownload")
	public void tempDownload(HttpServletResponse response , String fileId) {
		File file = new File(System.getProperty("java.io.tmpdir") , fileId);
		try {
			if(file.exists()) {
				InputStream inStream = new FileInputStream(file);// 文件的存放路径
		        // 设置输出的格式
		        response.reset();
		        response.setContentType("application/octet-stream");
		        response.addHeader("Content-Disposition", "attachment; filename=\"" + file.getName() + "\"");
		        // 循环取出流中的数据
		        byte[] b = new byte[1024*4];
		        int len;
	            while ((len = inStream.read(b)) > 0)
	            {
	            	response.getOutputStream().write(b, 0, len);
	            }
	            inStream.close();
	            response.getOutputStream().flush();
			}
		}catch(Exception e) {
			logger.error("download temp file exception " , e);
		}
	}
}

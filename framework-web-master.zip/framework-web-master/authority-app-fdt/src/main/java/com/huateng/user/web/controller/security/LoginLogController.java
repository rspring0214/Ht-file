package com.huateng.user.web.controller.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.user.api.annotations.SecurityChecker;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.core.model.loginLog.LoginLogQuery;
import com.huateng.user.core.service.LoginInfoService;
import com.huateng.user.dal.model.LoginInfo;

@Controller
@RequestMapping("/s/loginInfo")
public class LoginLogController {

	@Autowired
	private LoginInfoService loginLogService;
	
	@RequestMapping("showList")
	@SecurityChecker("user:loginInfo:search")
	public String showList(ModelMap model){
		return "loginLog/list";
	}
	
	@RequestMapping("search")
	@SecurityChecker("user:loginInfo:search")
	public @ResponseBody ApiBaseResponse<PageInfo<LoginInfo>> search(ModelMap model ,LoginLogQuery query, PageInfo<LoginInfo> page){
		if(page == null){
			page = new PageInfo<LoginInfo>();
		}
		loginLogService.search(query, page);
		return new ApiBaseResponse<PageInfo<LoginInfo>>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, page);
	}
	
	@SecurityChecker("user:loginInfo:remove")
    @RequestMapping("/remove")
    @ResponseBody
    public ApiBaseResponse<Boolean> remove(String ids) {
		loginLogService.deleteByIds(ids);
        return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
    }
	
}

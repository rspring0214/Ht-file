/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.web.controller.security;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.user.api.annotations.OperLog;
import com.huateng.user.api.annotations.SecurityChecker;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.core.service.MenuInfoService;
import com.huateng.user.dal.model.MenuInfo;
import com.huateng.user.dal.model.RoleInfo;
import com.huateng.user.web.model.MenuInfoVo;

/**
 * Description:资源菜单
 *
 * @author Heaven.tang
 * @version $Id: MenuInfoController.java, v 0.1 2019年3月28日 下午3:33:30 Heaven.tang Exp $
 */
@RequestMapping("/s/menuInfo")
@Controller
public class MenuInfoController {

	private static final Logger logger = LoggerFactory.getLogger(MenuInfoController.class);
	
	@Autowired
	private MenuInfoService menuService;

	@SecurityChecker("user:menuInfo:view")
	@RequestMapping("/showList")
	public String menu() {
		return "menuInfo/list";
	}

	@SecurityChecker("user:menuInfo:search")
	@RequestMapping("/search")
	@ResponseBody
	public ApiBaseResponse<List<MenuInfo>> search(MenuInfo menuInfo) {
		// 菜单树、不需要分页
		List<MenuInfo> menus = menuService.selectMenuList(menuInfo);
		// TODO 因前端脚本强制要求必须要完整的树数据才展示，所以需要递归补齐所有资源到低级资源
		Set<String> initIds = new HashSet<String>();
		Set<String> initParentIds = new HashSet<String>();
		for (MenuInfo menu : menus) {
			initIds.add(menu.getId());
		}
		for (MenuInfo menu : menus) {
			if (!initIds.contains(menu.getParentId()) && !StringUtils.equals(Constants.ROOT_ID, menu.getParentId())) {
				initParentIds.add(menu.getParentId());
			}
		}
		for (String id : initParentIds) {
			recursiveGetParent(id, menus, initParentIds);
		}
		
		return new ApiBaseResponse<List<MenuInfo>>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, menus);
	}

	/**
	 * 
	 * @param id
	 * @param menus
	 * @param initParentIds 
	 */
	private void recursiveGetParent(String id, List<MenuInfo> menus, Set<String> initParentIds) {
		if (StringUtils.equals(id, Constants.ROOT_ID)) {
			return;
		}
		MenuInfo menu = menuService.selectMenuById(id);
		if (null == menu) {
			return;
		}
		menus.add(menu);
		if (!initParentIds.contains(menu.getParentId())) {
			recursiveGetParent(menu.getParentId(), menus, initParentIds);
		}
	}

	/**
	 * 删除菜单
	 */
	@SecurityChecker("user:menuInfo:remove")
	@RequestMapping("/remove")
	@ResponseBody
	@OperLog(functionName="删除",menuName="菜单管理")
	public ApiBaseResponse<Boolean> remove(String id) {
		if (menuService.countMenusByParentId(id) > 0) {
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, "存在子菜单,不允许删除", false);
		}
		if (menuService.countRolesByMenuId(id) > 0) {
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, "菜单已分配,不允许删除", false);
		}
		boolean del = menuService.deleteMenuById(id) > 0 ? true : false;
		if (!del) {
			logger.error("delete menu failed, expected 1 but {}", del);
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, "菜单已分配,不允许删除", false);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}

	/**
	 * 新增
	 */
	@RequestMapping("/addPre")
	public String add(ModelMap model, String id) {
		MenuInfo menuInfo = new MenuInfo();
		if (!StringUtils.equals(Constants.ROOT_ID, id)) {
			MenuInfo menu = menuService.selectMenuById(id);
			if(menu != null){
				menuInfo.setId(menu.getId());
				menuInfo.setParentId(menu.getParentId());
				menuInfo.setMenuName(menu.getMenuName());
			}else{
				menuInfo.setId(Constants.ROOT_ID);
				menuInfo.setMenuName(Constants.ROOT_CONTENT_NAME);
			}
		} else {
			menuInfo.setId(Constants.ROOT_ID);
			menuInfo.setMenuName(Constants.ROOT_CONTENT_NAME);
		}
		model.put("menu", menuInfo);
		return "menuInfo/add";
	}

	/**
	 * 新增保存菜单
	 */
	@SecurityChecker("user:menuInfo:add")
	@RequestMapping("/add")
	@ResponseBody
	@OperLog(functionName="新增",menuName="菜单管理")
	public ApiBaseResponse<Boolean> addSave(MenuInfo menuInfo) {
		int rows = 0;
		try {
			menuInfo.setCreateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
			if (StringUtils.isBlank(menuInfo.getParentId())) {
				menuInfo.setParentId(Constants.ROOT_ID);
			}
			if (StringUtils.isBlank(menuInfo.getUrl())) {
				menuInfo.setUrl("#");
			}
			rows = menuService.insertMenu(menuInfo);
		} catch (Exception e) {
			logger.error("insert menu info error, cause ", e);
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, Constants.API_RESPONSE_FAIL_MESSAGE, false);
		}
		if (rows != 1) {
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, Constants.API_RESPONSE_FAIL_MESSAGE, false);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}

	/**
	 * 修改菜单
	 */
	@RequestMapping("/editPre")
	public String edit(ModelMap model, String id) {
		MenuInfoVo menu = transfor(menuService.selectMenuById(id));
		model.put("menu", menu);
		MenuInfo pMenu = null;
		if (StringUtils.equals(menu.getParentId(), Constants.ROOT_ID)) {
			pMenu = new MenuInfo();
			pMenu.setId(Constants.ROOT_ID);
			pMenu.setMenuName(Constants.ROOT_CONTENT_NAME);
		} else {
			pMenu = menuService.selectMenuById(menu.getParentId());
		}
		model.put("pMenu", pMenu);
		return "menuInfo/edit";
	}

	private MenuInfoVo transfor(MenuInfo menu) {
		MenuInfoVo vo = new MenuInfoVo();
		BeanUtils.copyProperties(menu, vo);
		MenuInfo info = menuService.selectMenuById(menu.getParentId());
		if (null != info && StringUtils.isNotBlank(info.getMenuName())) {
			vo.setParentName(info.getMenuName());
		} else if (StringUtils.equals(Constants.ROOT_ID, menu.getParentId())) {
			vo.setParentName(Constants.ROOT_CONTENT_NAME);
		}
		return vo;
	}

	/**
	 * 修改保存菜单
	 */
	@SecurityChecker("user:menuInfo:edit")
	@RequestMapping("/edit")
	@ResponseBody
	@OperLog(functionName="修改",menuName="菜单管理")
	public ApiBaseResponse<Boolean> editSave(MenuInfo menu) {
		menu.setUpdateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
		if (StringUtils.isBlank(menu.getParentId())) {
			menu.setParentId(Constants.ROOT_ID);
		}
		int u = menuService.updateMenu(menu);
		if (u != 1) {
			logger.error("update menu info failed, expected 1 but {}", u);
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, Constants.API_RESPONSE_FAIL_MESSAGE, true);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}

	/**
	 * 选择菜单图标
	 */
	@RequestMapping("/icon")
	public String icon() {
		return "menuInfo/icon";
	}

	/**
	 * 校验菜单名称
	 */
	@RequestMapping("/checkMenuNameUnique")
	@ResponseBody
	public ApiBaseResponse<Boolean> checkMenuNameUnique(MenuInfo menuInfo) {
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, menuService.checkMenuNameUnique(menuInfo));
	}

	/**
	 * 选择菜单树
	 */
	@RequestMapping("/selectMenu")
	public String selectMenu(ModelMap model, String id) {
		model.put("menu", menuService.selectMenuById(id));
		return "menuInfo/tree";
	}
	
	/**
	 * 加载菜单列表树
	 */
	@RequestMapping("/menuTreeData")
	@ResponseBody
	public List<Map<String, Object>> menuTreeData(String id) {
//		if (StringUtils.isBlank(id)) {
//			return menuService.menuTreeData();
//		}
//		return menuService.menuTreeData(id);
		return menuService.menuTreeData(true);
	}
	
	/**
	 * 加载角色菜单列表树
	 */
	@RequestMapping("/roleMenuTreeData")
	@ResponseBody
	public List<Map<String, Object>> roleMenuTreeData(RoleInfo roleInfo) {
		List<Map<String, Object>> tree = menuService.roleMenuTreeData(roleInfo);
		return tree;
	}
	
	@RequestMapping("/menuDirSelect")
	@ResponseBody
	public List<Map<String , Object>> menuDirSelect(String menuName){
		List<Map<String, Object>> tree = menuService.menuTreeData(true,menuName);
		return tree;
	}
	
	@RequestMapping("findButtonByMenuId")
	@SecurityChecker("user:menuInfo:search")
	public @ResponseBody ApiBaseResponse<PageInfo<MenuInfo>> findButtonByMenuId(String id){
		PageInfo<MenuInfo> pageInfo = new PageInfo<MenuInfo>();
		if(StringUtils.isNotBlank(id)) {
			List<MenuInfo> menuList = menuService.findButtonByParent(id);
			pageInfo.setData(menuList);
		}
		return new ApiBaseResponse<PageInfo<MenuInfo>>(Constants.API_RESPONSE_SUCCESS_CODE,RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, pageInfo);
	}
	
}

package com.huateng.user.web.controller.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.user.api.annotations.OperLog;
import com.huateng.user.api.annotations.SecurityChecker;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.core.security.InnerTokenService;
import com.huateng.user.core.service.UserOnlineInfoService;
import com.huateng.user.dal.model.UserOnlineInfo;

@Controller
@RequestMapping("/s/onlineInfo")
public class OnlineController {

	@Autowired
	private UserOnlineInfoService onlineService;
	
	@Autowired
	private InnerTokenService tokenService;
	
	@RequestMapping("showList")
	@SecurityChecker("user:onlineInfo:view")
	public String showList(){
		return "userOnline/list";
	}
	
	@RequestMapping("search")
	@SecurityChecker("user:onlineInfo:search")
	public @ResponseBody ApiBaseResponse<PageInfo<UserOnlineInfo>> search(String loginName, String deptName, String ipaddr, PageInfo<UserOnlineInfo> page){
		if(page == null){
			page = new PageInfo<UserOnlineInfo>();
		}
		onlineService.search(loginName, deptName, ipaddr, page);
		return new ApiBaseResponse<PageInfo<UserOnlineInfo>>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, page);
	}
	
	@RequestMapping("forceLogout")
	@OperLog(functionName="强制退出",menuName="在线用户")
	@SecurityChecker("user:onlineInfo:forceLogout")
	public @ResponseBody ApiBaseResponse<Boolean> forceLogout(String[] ids){
		if(ids != null && ids.length>0){
			for(String token : ids){
				tokenService.invalidToken(token);
			}
			onlineService.remveUserOnlineInfo(ids);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}
	
	@RequestMapping("batchForceLogout")
	@OperLog(functionName="批量强制退出",menuName="在线用户")
	@SecurityChecker("user:onlineInfo:batchForceLogout")
	public @ResponseBody ApiBaseResponse<Boolean> batchForceLogout(@RequestParam("ids[]") String[] ids){
		return forceLogout(ids);
	}
}

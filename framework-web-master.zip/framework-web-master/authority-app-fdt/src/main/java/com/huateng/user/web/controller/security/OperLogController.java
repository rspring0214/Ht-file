package com.huateng.user.web.controller.security;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.base.export.annotation.Exporter;
import com.huateng.user.api.annotations.SecurityChecker;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.core.model.operLog.OperLogQuery;
import com.huateng.user.core.service.OperLogInfoService;
import com.huateng.user.dal.model.OperLogInfo;

@Controller
@RequestMapping("/s/operLogInfo")
public class OperLogController {

	private static final Logger logger = LoggerFactory.getLogger(OperLogController.class);
	
	@Autowired
	private OperLogInfoService operLogService;
	
	@RequestMapping("showList")
	@SecurityChecker("user:operLog:search")
	public String showList(ModelMap model) {
		return "operLog/list";
	}
	
	
	@RequestMapping("search")
	@SecurityChecker("user:operLog:search")
	@Exporter("OpLog")
	public @ResponseBody ApiBaseResponse<PageInfo<OperLogInfo>> search(ModelMap model , OperLogQuery query , PageInfo<OperLogInfo> pageInfo){
		if(pageInfo == null){
			pageInfo = new PageInfo<OperLogInfo>();
		}
		operLogService.search(query, pageInfo);
		
		return new ApiBaseResponse<PageInfo<OperLogInfo>>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, pageInfo);
	}
	
	/**
	 * 删除操作日志记录
	 */
	@SecurityChecker("user:operLog:remove")
	@RequestMapping( "/remove")
	@ResponseBody
	public ApiBaseResponse<Boolean> remove(String ids) {
		int num = 0;
		try {
			List<String> idList = Arrays.asList(ids.split(","));
			num = operLogService.deleteOperLogByIds(Arrays.asList(ids.split(",")));
			if (null != idList && num == idList.size()) {
				return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
						Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
			}
		} catch (Exception e) {
			logger.error("Delete config info by id exception ", e);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL,
				Constants.API_RESPONSE_FAIL_MESSAGE, false);
	}
	
	@SecurityChecker("user:operLog:detail")
	@RequestMapping("/detail")
    public String detail(ModelMap model, String id) {
		model.put("operLog", operLogService.selectOperLogById(id));
        return "operLog/detail";
    }
    
    @SecurityChecker("user:operLog:remove")
    @RequestMapping("/clean")
    @ResponseBody
    public ApiBaseResponse<Boolean> clean() {
        operLogService.cleanOperLog();
        return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
    }
	
}

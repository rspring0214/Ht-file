/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.web.controller.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.user.api.annotations.OperLog;
import com.huateng.user.api.annotations.SecurityChecker;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.utils.Echo;
import com.huateng.user.core.service.PostInfoService;
import com.huateng.user.dal.model.PostInfo;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: PostInfoController.java, v 0.1 2019年4月3日 下午4:36:50 Heaven.tang Exp $
 */
@RequestMapping("/s/postInfo")
@Controller
public class PostInfoController {

private static final Logger logger = LoggerFactory.getLogger(DeptInfoController.class);
	
	@Autowired
	private PostInfoService postService;

	@SecurityChecker("user:postInfo:view")
	@RequestMapping("/showList")
	public String dept() {
		return "postInfo/list";
	}

	@SecurityChecker("user:postInfo:search")
	@RequestMapping("/search")
	@ResponseBody
	public ApiBaseResponse<PageInfo<PostInfo>> search(PostInfo postInfo, PageInfo<PostInfo> page) {
		if (page == null) {
			page = new PageInfo<PostInfo>();
		}
		postService.selectPostListByPage(postInfo, page);
		return new ApiBaseResponse<PageInfo<PostInfo>>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, page);
	}

	/**
	 * 新增
	 */
	@RequestMapping("/addPre")
	public String add() {
		return "postInfo/add";
	}

	/**
	 * 新增保存岗位
	 */
	@SecurityChecker("user:postInfo:add")
	@RequestMapping("/add")
	@ResponseBody
	@OperLog(functionName="新增",menuName="岗位管理")
	public ApiBaseResponse<Boolean> addSave(PostInfo postInfo) {
		int rows = 0;
		try {
			postInfo.setCreateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
			rows = postService.insertPost(postInfo);
		} catch (Exception e) {
			logger.error("insert dept info error ", e);
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, Constants.API_RESPONSE_FAIL_MESSAGE, false);
		}
		if (rows <= 0) {
			logger.error("insert post info failed, expected 1 but {}", rows);
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, Constants.API_RESPONSE_FAIL_MESSAGE, false);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}
	
	/**
	 * 修改岗位
	 */
	@RequestMapping("/editPre")
	public String edit(ModelMap model, String id) {
		model.put("post", postService.selectPostById(id));
		return "postInfo/edit";
	}

	/**
	 * 修改保存岗位
	 */
	@SecurityChecker("user:postInfo:edit")
	@RequestMapping("/edit")
	@ResponseBody
	@OperLog(functionName="修改",menuName="岗位管理")
	public ApiBaseResponse<?> editSave(PostInfo dept) {
		dept.setUpdateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
		int u = postService.updatePost(dept);
		if (u != 1) {
			logger.error("update post info failed, expected 1 but {}", u);
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, Constants.API_RESPONSE_FAIL_MESSAGE, true);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}
	
	/**
	@SecurityChecker("user:postInfo:export")
	@RequestMapping("/export")
    @ResponseBody
    public ApiBaseResponse<?> export(PostInfo post) {
        List<PostInfo> list = postService.selectPostList(post);
        List<PostInfoVO> voList = BeanUtils.propertiesCopy(list, new PostInfoVO());
        ExcelUtil<PostInfoVO> util = new ExcelUtil<PostInfoVO>(PostInfoVO.class);
        return util.exportExcel(voList, "岗位数据");
    }
    */
	
	/**
	 * 删除岗位
	 */
	@SecurityChecker("user:postInfo:remove")
	@RequestMapping("/remove")
	@ResponseBody
	@OperLog(functionName="删除",menuName="岗位管理")
	public ApiBaseResponse<?> remove(String ids) {
		int n = postService.countUsersByPostIds(ids);
		if (n > 0) {
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, "存在使用中的用户，不允许删除", false);
		}
		// 实际更新了标识为失效
		try {
			postService.deletePostByIds(ids);
		} catch (Exception e) {
			logger.error("delete post info exception ", e);
			return Echo.toFail(e);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}
	
	/**
	 * 校验岗位名称
	 */
	@RequestMapping("/checkPostNameUnique")
	@ResponseBody
	public ApiBaseResponse<Boolean> checkPostNameUnique(PostInfo postInfo) {
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, postService.checkPostNameUnique(postInfo));
	}
	
	/**
	 * 校验岗位编号
	 */
	@RequestMapping("/checkPostCodeUnique")
	@ResponseBody
	public ApiBaseResponse<Boolean> checkPostCodeUnique(PostInfo postInfo) {
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, postService.checkPostCodeUnique(postInfo));
	}

}

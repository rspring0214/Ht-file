/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.web.controller.security;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.user.api.annotations.OperLog;
import com.huateng.user.api.annotations.SecurityChecker;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.utils.Echo;
import com.huateng.user.core.model.roleInfo.RoleInfoModel;
import com.huateng.user.core.model.roleInfo.RoleInfoQueryModel;
import com.huateng.user.core.service.RoleInfoService;
import com.huateng.user.dal.model.RoleInfo;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: RoleInfoController.java, v 0.1 2019年4月3日 下午6:51:13 Heaven.tang Exp $
 */
@RequestMapping("/s/roleInfo")
@Controller
public class RoleInfoController {

	private static final Logger logger = LoggerFactory.getLogger(RoleInfoController.class);
	
	@Autowired
	private RoleInfoService roleService;
	
	@SecurityChecker("user:roleInfo:view")
	@RequestMapping("/showList")
	public String role() {
		return "roleInfo/list";
	}

	@SecurityChecker("user:roleInfo:search")
	@RequestMapping("/search")
	@ResponseBody
	public ApiBaseResponse<PageInfo<RoleInfo>> search(RoleInfoQueryModel role, PageInfo<RoleInfo> page) {
		if (page == null) {
			page = new PageInfo<RoleInfo>();
		}
		roleService.selectRoleListByPage(role, page);
		return new ApiBaseResponse<PageInfo<RoleInfo>>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, page);
	}

	/**
	 * 新增
	 */
	@RequestMapping("/addPre")
	public String add(ModelMap model) {
		/**
		if (UserUtils.isAdmin()) {
			model.put("tenants", tenantService.selectTenants(Constants.COMMON_VALID);
		} else {
			model.put("tenantId", SSOClientUtils.getInstance().findCurrentUser().getTenantId());
		}
		*/
		return "roleInfo/add";
	}

	/**
	 * 新增保存角色
	 */
	@SecurityChecker("user:roleInfo:add")
	@RequestMapping("/add")
	@ResponseBody
	@OperLog(functionName="新增",menuName="角色管理")
	public ApiBaseResponse<Boolean> addSave(RoleInfoModel role) {
		try {
			role.setCreateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
			roleService.insertRole(role);
		} catch (Exception e) {
			logger.error("insert role info error ", e);
			return Echo.toFail(e);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}
	
	/**
	 * 修改角色
	 */
	@RequestMapping("/editPre")
	public String edit(ModelMap model, String id) {
		model.put("role", roleService.selectRoleById(id));
		return "roleInfo/edit";
	}

	/**
	 * 修改保存角色
	 */
	@SecurityChecker("user:roleInfo:edit")
	@RequestMapping("/edit")
	@ResponseBody
	@OperLog(functionName="修改角色菜单",menuName="角色管理")
	public ApiBaseResponse<Boolean> editSave(RoleInfoModel role) {
		if (role.getStatus().intValue() == Constants.COMMON_INVALID.intValue()) {
			int count = roleService.countRoleUsersByRoleId(role.getId());
			if (count > 0) {
				return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, "存在使用中的用户，不允许变更为失效", false);
			}
		}
		try {
			role.setUpdateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
			roleService.updateRole(role);
		} catch (Exception e) {
			logger.error("insert role info error ", e);
			return Echo.toFail(e);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}
	
	/**
	@SecurityChecker("user:roleInfo:export")
	@RequestMapping("/export")
    @ResponseBody
    public ApiBaseResponse<?> export(RoleInfo role) {
        List<RoleInfo> list = roleService.selectRoleList(role);
        List<RoleInfoVO> voList = BeanUtils.propertiesCopy(list, new RoleInfoVO());
        ExcelUtil<RoleInfoVO> util = new ExcelUtil<RoleInfoVO>(RoleInfoVO.class);
        return util.exportExcel(voList, "角色数据");
    }
    */
	
	/**
     * 新增数据权限
     */
	@RequestMapping("/rulePre")
    public String rule(ModelMap model, String id) {
		model.put("role", roleService.selectRoleById(id));
        return "roleInfo/rule";
    }

    /**
     * 修改保存数据权限
     */
	@SecurityChecker("user:roleInfo:edit")
    @RequestMapping("/rule")
    @ResponseBody
    @OperLog(functionName="修改角色组织机构",menuName="角色管理")
    public ApiBaseResponse<Boolean> ruleSave(RoleInfoModel role) {
		try {
			role.setUpdateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
			roleService.updateRule(role);
		} catch (Exception e) {
			logger.error("update role info error ", e);
			return Echo.toFail(e);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
    }
	
	/**
	 * 删除角色
	 */
	@SecurityChecker("user:roleInfo:remove")
	@RequestMapping("/remove")
	@ResponseBody
	@OperLog(functionName="删除",menuName="角色管理")
	public ApiBaseResponse<Boolean> remove(String ids) {
		// 实际更新了标识为失效
		try {
			roleService.deleteRoleByIds(ids);
		} catch (Exception e) {
			logger.error("delete role info error ", e);
			return Echo.toFail(e);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}
	
	/**
	 * 校验角色名称
	 */
	@RequestMapping("/checkRoleNameUnique")
	@ResponseBody
	public ApiBaseResponse<Boolean> checkRoleNameUnique(RoleInfo role) {
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, roleService.checkRoleNameUnique(role));
	}
	
	/**
	 * 校验角色编号
	 */
	@RequestMapping("/checkRoleKeyUnique")
	@ResponseBody
	public ApiBaseResponse<Boolean> checkRoleKeyUnique(RoleInfo role) {
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, roleService.checkRoleKeyUnique(role));
	}
	
	/**
     * 角色状态修改
     */
	@SecurityChecker("user:roleInfo:edit")
    @RequestMapping("/changeStatus")
    @ResponseBody
    @OperLog(functionName="修改状态",menuName="角色管理")
    public ApiBaseResponse<Boolean> changeStatus(RoleInfo role) {
		if (role.getStatus().intValue() == Constants.COMMON_INVALID.intValue()) {
			int count = roleService.countRoleUsersByRoleId(role.getId());
			if (count > 0) {
				return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, "存在使用中的用户，不允许变更为失效", false);
			}
		}
		// 实际更新了标识为失效
		try {
			role.setUpdateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
			roleService.updateRoleInfo(role);
		} catch (Exception e) {
			logger.error("update role info error ", e);
			return Echo.toFail(e);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
    }
	
	/**
	 * 根据用户ID和机构查询角色：标记已有角色
	 * 
	 * @param userId
	 * @param deptId
	 * @return
	 */
	@RequestMapping("/getRolesByUserId")
	@ResponseBody
	public List<RoleInfoModel> getRolesByUserId(String userId, String deptId) {
		return roleService.selectRolesByUserId(userId, deptId);
	}
}

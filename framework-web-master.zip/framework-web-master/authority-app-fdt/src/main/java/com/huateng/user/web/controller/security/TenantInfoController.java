package com.huateng.user.web.controller.security;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.user.api.annotations.OperLog;
import com.huateng.user.api.annotations.SecurityChecker;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.enums.YesOrNoEnum;
import com.huateng.user.core.service.TenantInfoService;
import com.huateng.user.dal.model.TenantInfo;

@Controller
@RequestMapping("/s/tenantInfo")
public class TenantInfoController {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private TenantInfoService tenantInfoService;

	@RequestMapping("showList")
	public String showTenant(ModelMap model) {
		return "tenant/list";
	}

	@RequestMapping("search")
	@SecurityChecker("user:tenantInfo:search")
	public @ResponseBody ApiBaseResponse<PageInfo<TenantInfo>> search(TenantInfo tenantInfo, PageInfo<TenantInfo> page) {
		if (page == null) {
			page = new PageInfo<TenantInfo>();
		}
		tenantInfoService.findTanantList(tenantInfo, page);
		return new ApiBaseResponse<PageInfo<TenantInfo>>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, page);
		// return tenantInfoService.findTanantList(tenantInfo, page);
	}

	@RequestMapping("addPre")
	@SecurityChecker("user:tenantInfo:add")
	public String addPre(ModelMap model, String id) {
		if (StringUtils.isNotBlank(id)) {
			TenantInfo tenantInfo = tenantInfoService.selectByPrimaryKey(id);
			model.put("edit", tenantInfo);
		}
		return "tenant/save";
	}

	@RequestMapping("editPre")
	@SecurityChecker("user:tenantInfo:edit")
	public String editPre(ModelMap model, String id) {
		return addPre(model, id);
	}

	@RequestMapping("save")
	@OperLog(functionName="保存",menuName="租户管理")
	public @ResponseBody ApiBaseResponse<Boolean> save(TenantInfo tenantInfo) {
		try {
			tenantInfoService.saveTenantInfo(tenantInfo);
//			List<TenantInfoVo> list = BeanUtils.propertiesCopy(tenantInfoService.selectTenants(Constants.COMMON_VALID), new TenantInfoVo());
//			cacheManager.putObj(Constants.TENANT_CACHE_KEY, JSON.toJSONString(list), 60 * 5L);
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
		} catch (Exception e) {
			logger.error("save exception ", e);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, Constants.API_RESPONSE_FAIL_MESSAGE, false);
	}
	
	@RequestMapping("selectById")
	@ResponseBody
	public ApiBaseResponse<TenantInfo> selectById(String id) {
		return new ApiBaseResponse<TenantInfo>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, "", tenantInfoService.selectByPrimaryKey(id));
	}
	
	/**
	 * 校验用户名
	 */
	@RequestMapping("/checkTenantCodeUnique")
	@ResponseBody
	public ApiBaseResponse<Boolean> checkTenantCodeUnique(TenantInfo tenant) {
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, tenantInfoService.checkTenantCodeUnique(tenant));
	}
	
	@RequestMapping("/getTenants")
	@ResponseBody
	public ApiBaseResponse<List<TenantInfo>> selectTenants() {
		List<TenantInfo> tenants = tenantInfoService.selectCacheTenants(Integer.valueOf(YesOrNoEnum.YES.getCode()));
		
		return new ApiBaseResponse<>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, tenants);
	}
}

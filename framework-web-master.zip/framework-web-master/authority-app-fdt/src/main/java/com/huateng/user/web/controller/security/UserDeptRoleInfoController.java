/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.web.controller.security;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.user.api.annotations.OperLog;
import com.huateng.user.api.annotations.SecurityChecker;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.model.BaseException;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.api.model.UserDept;
import com.huateng.user.api.utils.Echo;
import com.huateng.user.core.model.userDept.UserDeptQueryModel;
import com.huateng.user.core.model.userDept.UserDeptRole;
import com.huateng.user.core.model.userDept.UserDeptRoleBinding;
import com.huateng.user.core.security.InnerTokenService;
import com.huateng.user.core.service.AsycRecordService;
import com.huateng.user.core.service.DeptInfoService;
import com.huateng.user.core.service.MenuInfoService;
import com.huateng.user.core.service.RoleInfoService;
import com.huateng.user.core.service.UserDeptRoleService;
import com.huateng.user.core.service.UserInfoService;
import com.huateng.user.core.util.BeanUtils;
import com.huateng.user.dal.model.DeptInfo;
import com.huateng.user.dal.model.RoleInfo;
import com.huateng.user.dal.model.UserInfo;
import com.huateng.user.web.util.WebCommonUtils;

/**
 * Description:用户机构角色绑定处理
 *
 * @author Heaven.tang
 * @version $Id: UserDeptRoleInfoController.java, v 0.1 2019年8月7日 上午10:50:37 Heaven.tang Exp $
 */
@RequestMapping("/s/userDeptRole")
@Controller
public class UserDeptRoleInfoController {

	private static final Logger logger = LoggerFactory.getLogger(UserDeptRoleInfoController.class);
	
	@Autowired
	private UserDeptRoleService userDeptRoleService;
	
	@Autowired
	private UserInfoService userInfoService;
	
	@Autowired
	private DeptInfoService deptInfoService;
	
	@Autowired
	private RoleInfoService roleInfoService;
	
	@Autowired
	private MenuInfoService menuInfoService;
	
	@Autowired
	private InnerTokenService tokenService;
	
	@Autowired
	private AsycRecordService asycRecord;
	
	@Value("${app.base.url}")
	private String baseUrl;
	
	@Value("${sso.login.success.url}")
	private String loginSuccessUrl;
	
	@Value("${sso.token.storeType:cookie}")
	private String storeType;
	
	@Value("${sso.token.name:HTtoken}")
	private String tokenName;
	
	@SecurityChecker("user:userDeptRole:view")
	@RequestMapping("/showList")
	public String showList() {
		return "userDeptRole/list";
	}

	@SecurityChecker("user:userDeptRole:search")
	@RequestMapping("/search")
	@ResponseBody
	public ApiBaseResponse<PageInfo<UserDeptRole>> search(UserDeptQueryModel user, PageInfo<UserDeptRole> page) {
		if (page == null) {
			page = new PageInfo<UserDeptRole>();
		}
		user.setDeptId(SSOClientUtils.getInstance().findCurrentUser().getLoginDept().getId());
		userDeptRoleService.selectUserDeptRolesByPage(user, page, true);
		
		for(UserDeptRole udr : page.getData()){
			udr.setUserName(udr.getUserDept().getUserName());
			udr.setDeptName(udr.getUserDept().getDeptName());
		}
		
		
		return new ApiBaseResponse<PageInfo<UserDeptRole>>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, page);
	}
	
	@SecurityChecker("user:userDeptRole:add")
	@RequestMapping("/addPre")
	public String addPre() {
		return "userDeptRole/add";
	}
	
	@RequestMapping("/save")
	@OperLog(functionName="保存",menuName="委任管理")
	public @ResponseBody ApiBaseResponse<Boolean> save(UserDeptRoleBinding data) {
		// 不允许选择用户所属机构
		String result = checkSave(data);
		if (StringUtils.isNotBlank(result)) {
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL,
					result, false);
		}
		
		try {
			userDeptRoleService.saveBinding(data);
		} catch (Exception e) {
			logger.error("insert user info error ", e);
			return Echo.toFail(e);
		}
		
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}

	private String checkSave(UserDeptRoleBinding data) {
		UserInfo user = userInfoService.selectUserById(data.getUserId());
		if (null == user) {
			logger.error("User not exists, id : {}", data.getUserId());
			return "用户不存在";
		}
		
		DeptInfo dept = deptInfoService.selectDeptById(data.getDeptId());
		if (null == dept) {
			logger.error("Dept not exists, id : {}", data.getDeptId());
			return "组织机构不存在";
		}
		if (StringUtils.equals(user.getDeptId(), data.getDeptId())) {
			logger.error("Band user dept not allow, userId : {}, deptId : {}", data.getUserId(), data.getDeptId());
			return "不允许委任用户所属机构";
		}
		
		List<RoleInfo> roles = roleInfoService.selectRolesByIds(Arrays.asList(data.getRoleIds()));
		if (CollectionUtils.isEmpty(roles) || roles.size() < data.getRoleIds().length) {
			logger.error("Role not exists, ids : {}", data.getRoleIds().toString());
			return "角色不存在，请检查";
		}
		
		return null;
	}
	
	@SecurityChecker("user:userDeptRole:edit")
	@RequestMapping("/editPre")
	public String editPre(ModelMap model, String userId, String deptId) {
		model.put("user", userInfoService.selectUserById(userId));
		model.put("dept", deptInfoService.selectDeptById(deptId));
		return "userDeptRole/edit";
	}
	
	@RequestMapping("/showLoginDept")
	public String selectLoginDeptPre(ModelMap model) {
		return "userDeptRole/loginDeptList";
	}
	
	@RequestMapping("/selectLoginDeptPre")
	@ResponseBody
	public ApiBaseResponse<PageInfo<UserDeptRole>> search(PageInfo<UserDeptRole> page) {
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		UserDeptQueryModel query = new UserDeptQueryModel();
		query.setUserId(user.getUserId());
		userDeptRoleService.selectUserDeptRolesByPage(query, page, false);
		
		for(UserDeptRole udr : page.getData()){
			udr.setUserName(udr.getUserDept().getUserName());
			udr.setDeptId(udr.getUserDept().getDeptId());
			udr.setDeptName(udr.getUserDept().getDeptName());
		}
		
		return new ApiBaseResponse<PageInfo<UserDeptRole>>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, page);
	}
	
	@RequestMapping("/selectLoginDept")
	public String selectLoginDept(HttpServletRequest request, HttpServletResponse response, String deptId) {
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		
		cleanLoginInfo(user);
		
		DeptInfo dept = deptInfoService.selectDeptById(deptId);
		// 复核部门用户关系
		boolean userInDept = userDeptRoleService.userInDept(user.getUserId(), deptId);
		if (!userInDept) {
			logger.error("user not in dept, deptId:{}", deptId);
			throw new BaseException("用户机构关系不存在");
		}
		// 重新设置登录机构、角色、权限
		resetLoginInfo(deptId, dept, user);
		
		// 更新日志中的登录信息
		asycRecord.updateLoginLog(user);
		
//		String redirectUrl = baseUrl + loginSuccessUrl;
		String redirectUrl = WebCommonUtils.contactPath(baseUrl, loginSuccessUrl);
		if (StringUtils.equals(storeType, Constants.PAGE)) {
			redirectUrl = redirectUrl + "?HTtoken=" + WebCommonUtils.findToken(request, tokenName);
		}
		try {
			response.sendRedirect(redirectUrl);
		} catch (IOException e) {
			logger.error("select login dept success, but redirect to index exception, ", e);
		}
		return null;
	}

	/**
	 * 
	 * @param user
	 */
	private void cleanLoginInfo(SSOUser user) {
		if (null != user && null != user.getLoginDept()) {
			// 清空当前登录机构角色权限信息
			user.setLoginDept(null);
			user.setRoles(null);
			user.setPermissions(new HashSet<String>());
			tokenService.saveTokenModel(user);
		}
	}

	private void resetLoginInfo(String deptId, DeptInfo dept, SSOUser user) {
		UserDept loginDept = BeanUtils.propertiesCopy(dept, new UserDept());
		user.setLoginDept(loginDept);
		UserDeptQueryModel query = new UserDeptQueryModel();
		query.setUserId(user.getUserId());
		query.setDeptId(deptId);
		PageInfo<UserDeptRole> page = new PageInfo<UserDeptRole>(1);
		List<UserDeptRole> userDeptRoles = userDeptRoleService.selectUserDeptRolesByPage(query, page, false);
		if (CollectionUtils.isNotEmpty(userDeptRoles)) {
			user.setRoles(userDeptRoles.get(0).getRoles());
		}
		List<String> permList = menuInfoService.findPermByUserId(user.getUserId(), deptId);
		if (CollectionUtils.isNotEmpty(permList)) {
			user.getPermissions().addAll(permList);
		}
		tokenService.saveTokenModel(user);
	}
	
	@SecurityChecker("user:userDeptRole:remove")
	@RequestMapping("/remove")
	@ResponseBody
	@OperLog(functionName="删除",menuName="用户委任")
	public ApiBaseResponse<Boolean> remove(String userId, String deptId) {
		try {
			userDeptRoleService.delete(userId, deptId);
		} catch (Exception e) {
			logger.error("delete userRoles failed, ", e);
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL,
					Constants.API_RESPONSE_FAIL_MESSAGE, false);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, true);
	}
}

/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.web.controller.security;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.MethodUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.huateng.base.common.api.model.ApiBaseResponse;
import com.huateng.base.common.api.model.PageInfo;
import com.huateng.base.common.api.model.RetStatusEnum;
import com.huateng.base.export.ExportRegister;
import com.huateng.base.export.ExportTemplate;
import com.huateng.base.export.util.ExportUtils;
import com.huateng.user.api.annotations.OperLog;
import com.huateng.user.api.annotations.SecurityChecker;
import com.huateng.user.api.client.SSOClientUtils;
import com.huateng.user.api.constants.Constants;
import com.huateng.user.api.constants.ExceptionConstants;
import com.huateng.user.api.enums.YesOrNoEnum;
import com.huateng.user.api.model.SSOUser;
import com.huateng.user.api.utils.Echo;
import com.huateng.user.api.utils.UserUtils;
import com.huateng.user.core.exception.IllegalParamException;
import com.huateng.user.core.model.userInfo.UserInfoQueryModel;
import com.huateng.user.core.service.DeptInfoService;
import com.huateng.user.core.service.PostInfoService;
import com.huateng.user.core.service.RoleInfoService;
import com.huateng.user.core.service.TenantInfoService;
import com.huateng.user.core.service.UserInfoService;
import com.huateng.user.core.util.MD5Utils;
import com.huateng.user.dal.model.DeptInfo;
import com.huateng.user.dal.model.PostInfo;
import com.huateng.user.dal.model.TenantInfo;
import com.huateng.user.dal.model.UserInfo;
import com.huateng.user.dal.model.ext.ExtUserDeptInfo;
import com.huateng.user.dal.model.ext.ExtUserInfo;
import com.huateng.user.web.model.Page;
import com.huateng.user.web.model.UpdatePasswordModel;
import com.huateng.user.web.model.condition.UserDeptConditionModel;
import com.huateng.user.web.model.condition.UserDeptConditionQueryData;
import com.huateng.user.web.util.WebCommonUtils;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: UserInfoController.java, v 0.1 2019年4月4日 下午2:38:02 Heaven.tang Exp $
 */
@RequestMapping("/s/userInfo")
@Controller
public class UserInfoController {

	private static final Logger logger = LoggerFactory.getLogger(UserInfoController.class);
	
	@Autowired
	private UserInfoService userService;
	
	@Autowired
	private DeptInfoService deptService;
	
	@Autowired
	private RoleInfoService roleService;
	
	@Autowired
	private PostInfoService postService;
	
	@Autowired
	private TenantInfoService tenantService;
	
	@Value("${app.base.url}")
	private String baseUrl;
	
	@Value("${sso.login.success.url}")
	private String loginSuccessUrl;
	
	@Value("${sso.token.storeType:cookie}")
	private String storeType;
	
	@Value("${sso.token.name:HTtoken}")
	private String tokenName;
	
	@Value("${multiple.corporate:false}")
	private boolean multipleCorporate;
	
	@SecurityChecker("user:userInfo:view")
	@RequestMapping("/showList")
	public String user() {
		return "userInfo/list";
	}

	@SecurityChecker("user:userInfo:search")
	@RequestMapping(value = "/search")
	@ResponseBody
	public ApiBaseResponse<PageInfo<ExtUserInfo>> search(UserInfoQueryModel user, PageInfo<ExtUserInfo> page) {
		if (page == null) {
			page = new PageInfo<ExtUserInfo>();
		}
		SSOUser ssoUser = SSOClientUtils.getInstance().findCurrentUser();
		// 非超级管理员，限定默认查询当前用户登录机构及其下级机构下的用户
		/*if (!UserUtils.isAdmin() && StringUtils.isBlank(user.getDeptId())) {
			user.setDeptId(ssoUser.getLoginDept().getId());
		}*/
		
		if(UserUtils.isAdmin(ssoUser)){
			userService.selectUserListByPage4Admin(user, page);
		} else {
			userService.selectUserListByPage(user, page);
		}
		
		for(ExtUserInfo u : page.getData()){
			u.setDeptCode(u.getDept().getDeptName());
		}
		
		return new ApiBaseResponse<PageInfo<ExtUserInfo>>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, page);
	}
	
	@OperLog(functionName="导出", menuName="用户管理")
	@RequestMapping(value = "/export")
	public void export(UserInfoQueryModel user, PageInfo<ExtUserInfo> page, HttpServletResponse resp) throws IOException {
		resp.setHeader("content-disposition", "attachment;filename=userList.xlsx");
		
		//add by senvon for 导出优化
		//可以调用任意方法
		//有一些前提,查询方法必须返回List,ApiBaseResponse<List> , PageInfo,ApiBaseResponse<PageInfo<List>>其中之一
		//参数中必须包含PageInfo作为分页的参数
		ExportTemplate template = ExportRegister.getInstance().findTemplateByCode("UserInfo");
		Method targetMethod = MethodUtils.getAccessibleMethod(UserInfoController.class, "search" , new Class[]{com.huateng.user.core.model.userInfo.UserInfoQueryModel.class , com.huateng.base.common.api.model.PageInfo.class});
		ExportUtils.exportExcel(this, targetMethod, new Object[]{user , page}, resp.getOutputStream(), template);
		
	}

	/**
	 * 新增用户
	 */
	@RequestMapping("/addPre")
	public String add(ModelMap model, String id) {
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		// TODO 用户创建的限制？？？
		if (StringUtils.isNotBlank(id)) {
			// 传递了具体的组织机构ID，限定新增页面的角色和组织机构
			DeptInfo dept = deptService.selectDeptById(id);
			if (null != dept) {
				model.put("dept", dept);
			} else {
				TenantInfo tenant = tenantService.selectByPrimaryKey(id);
				List<TenantInfo> tenants = new ArrayList<TenantInfo>();
				tenants.add(tenant);
				model.put("tenants", tenants);
			}
		} else {
			if (UserUtils.isAdmin(user)) {
				model.put("tenants", tenantService.selectCacheTenants(Integer.valueOf(YesOrNoEnum.YES.getCode())));
			}
		}
		PostInfo post = new PostInfo();
		post.setStatus(Constants.COMMON_VALID);
		model.put("posts", postService.selectPostList(post));
		return "userInfo/add";
	}

	/**
	 * 新增保存用户
	 */
	@SecurityChecker("user:userInfo:add")
	@RequestMapping("/add")
	@ResponseBody
	@OperLog(functionName="新增",menuName="用户管理")
	public ApiBaseResponse<Boolean> addSave(ExtUserInfo user) {
		if (UserUtils.isAdmin(user.getUserName())) {
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, 
					ExceptionConstants.SUPER_USER_UPDATE_NOT_ALLOW_MESSAGE);
		}
		
		// 密码不在指定范围
		if (user.getPassword().length() < Constants.PASSWORD_MIN_LENGTH || user.getPassword().length() > Constants.PASSWORD_MAX_LENGTH) {
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, 
					"密码长度在 " + Constants.PASSWORD_MIN_LENGTH + "~" + Constants.PASSWORD_MAX_LENGTH + " 位");
        }

        // 用户名不在指定范围内 错误
        if (user.getUserName().length() < Constants.USERNAME_MIN_LENGTH || user.getUserName().length() > Constants.USERNAME_MAX_LENGTH) {
        	return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, 
					"用户名长度在 " + Constants.USERNAME_MIN_LENGTH + "~" + Constants.USERNAME_MAX_LENGTH + " 位");
        }
		
        // 根据组织机构查询租户
        DeptInfo dept = deptService.selectDeptById(user.getDeptId());
        if (null == dept || StringUtils.isBlank(dept.getTenantId())) {
        	logger.error("find dept by id : {}, dept : {}", new Object[]{user.getDeptId(), JSONObject.toJSONString(dept)});
        	return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, "信息异常");
        }
        
        user.setTenantId(dept.getTenantId());
        user.setTenantCode(dept.getTenantCode());
        
        user.setDeptCode(dept.getDeptCode());
        
		user.setSalt(MD5Utils.genSalt());
		user.setPassword(MD5Utils.genSaltMD5(UserUtils.createPasswdKey(user.getLoginName(), user.getPassword(), user.getSalt())));
		user.setCreateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
		try {
			userService.insertUser(user);
		} catch (Exception e) {
			logger.error("insert user info error ", e);
			return Echo.toFail(e);
		}
		
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, 
				Constants.API_RESPONSE_SUCCESS_MESSAGE);
	}

	/**
	 * 修改用户：限定只能查看和修改所属机构下的用户，如有需要，自行扩展
	 */
	@RequestMapping("/editPre")
	public String edit(ModelMap model, String id) {
		model.put("user", userService.selectUserDetailsById(id));
		model.put("roles", roleService.selectRolesByUserId(id, SSOClientUtils.getInstance().findCurrentUser().getLoginDept().getId()));
		model.put("posts", postService.selectPostsByUserId(id));
		return "userInfo/edit";
	}

	/**
	 * 修改保存用户
	 */
	@SecurityChecker("user:userInfo:edit")
	@RequestMapping("/edit")
	@ResponseBody
	@OperLog(functionName="修改",menuName="用户管理")
	public ApiBaseResponse<Boolean> editSave(ExtUserInfo user) {
		String rspCode = Constants.API_RESPONSE_SUCCESS_CODE;
		RetStatusEnum rspStatus = RetStatusEnum.SUCCESS;
		String rspMsg = Constants.API_RESPONSE_SUCCESS_MESSAGE;
		if (UserUtils.isAdmin(user.getUserName())) {
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, ExceptionConstants.SUPER_USER_UPDATE_NOT_ALLOW_MESSAGE);
		}
		try {
			user.setUpdateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
			userService.updateUser(user);
//			cacheManager.set(user.getId(), user.getStatus());
		} catch (Exception e) {
			logger.error("update user info exception ", e);
			return Echo.toFail(e);
		}
		return new ApiBaseResponse<Boolean>(rspCode, rspStatus, rspMsg);
	}

	@RequestMapping("/resetPwdPre")
	public String resetPwd(ModelMap model, String id) {
		SSOUser loginUser = SSOClientUtils.getInstance().findCurrentUser();
		if (StringUtils.equals(id, loginUser.getUserId())) {
			model.put("change", true);
		}
		model.put("user", userService.selectUserById(id));
		return "userInfo/resetPwd";
	}

	
	@RequestMapping("/forceResetPwdPre")
	public String forceResetPwd(ModelMap model, Boolean expire) {
		model.put("warnInfo", (expire != null && expire) ? Constants.EXPIRE_REST_PASSWORD : Constants.FIRST_LOGIN_REST_PASSWORD);
		return "userInfo/forceResetPwd";
	}
	
	@RequestMapping("/forceResetPwd")
	@OperLog(functionName="强制重置密码",menuName="用户管理")
	public String forceResetPwdSave(ModelMap model, HttpServletRequest request, HttpServletResponse response, UpdatePasswordModel updateUser, boolean expire) {
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		if (null == user) {
			model.put("input", updateUser);
			model.put("errorMsg", "系统异常");
			return forceResetPwd(model , expire);
		}
		updateUser.setId(user.getUserId());
		ApiBaseResponse<Boolean> result = resetPwdSave(updateUser);
		if (RetStatusEnum.SUCCESS == result.getRetStatus()) {
			try {
//				String redirectUrl = baseUrl + loginSuccessUrl;
				String redirectUrl = WebCommonUtils.contactPath(baseUrl, loginSuccessUrl);
				if (StringUtils.equals(storeType, Constants.PAGE)) {
					redirectUrl = redirectUrl + "?HTtoken=" + WebCommonUtils.findToken(request, tokenName);
				}
				response.sendRedirect(redirectUrl);
			} catch (IOException e) {
				logger.error("force reset password exception ", e);
			}
			return null;
		} else {
			model.put("input", updateUser);
			model.put("errorMsg", result.getMessage());
			return forceResetPwd(model, expire);
		}
	}
	
	@SecurityChecker("user:userInfo:resetPwd")
	@RequestMapping("/resetPwd")
	@ResponseBody
	@OperLog(functionName="重置密码",menuName="用户管理")
	public ApiBaseResponse<Boolean> resetPwdSave(UpdatePasswordModel updateUser) {
		String rspCode = Constants.API_RESPONSE_SUCCESS_CODE;
		RetStatusEnum rspStatus = RetStatusEnum.SUCCESS;
		String rspMsg = Constants.API_RESPONSE_SUCCESS_MESSAGE;
		try {
			if (StringUtils.isBlank(updateUser.getId())) {
				logger.error("Param id must not be blank, param : {}", JSONObject.toJSONString(updateUser));
				throw new IllegalParamException("用户ID不能为空");
			}
			// 登录用户自身重置密码，需要输入原密码并校验，管理员重置密码直接重置即可，这里不对管理员作权限认证
			UserInfo user = null;
			if (StringUtils.equals(updateUser.getId(), SSOClientUtils.getInstance().findCurrentUser().getUserId())) {
				if (StringUtils.isBlank(updateUser.getOldPassword())) {
					logger.warn("Param oldPassword must not be blank, param : {}", JSONObject.toJSONString(updateUser));
					throw new IllegalParamException(ExceptionConstants.NULL_OLD_PASSWORD_EXCEPTION_MESSAGE);
				}
				user = userService.checkPassword(updateUser.getId(), updateUser.getOldPassword());
				if (null == user) {
					throw new IllegalParamException(ExceptionConstants.OLD_PASSWORD_ERROR_EXCEPTION_MESSAGE);
				}
			} else {
				user = userService.selectUserById(updateUser.getId());
			}
			// 检查两次输入是否相同，
			if (StringUtils.isBlank(updateUser.getNewPassword()) || StringUtils.isBlank(updateUser.getConfirmNewPassword())) {
				throw new IllegalParamException(ExceptionConstants.NULL_NEW_PASSWORD_EXCEPTION_MESSAGE);
			}
			if (!StringUtils.equals(updateUser.getNewPassword(), updateUser.getConfirmNewPassword())) {
				throw new IllegalParamException(ExceptionConstants.NEW_PASSWORD_NOT_EQUALS_EXCEPTION_MESSAGE);
			}
			// 检查新密码是否和原密码相同
			if (StringUtils.equals(updateUser.getOldPassword(), updateUser.getNewPassword())) {
				throw new IllegalParamException(ExceptionConstants.NEW_SAME_AS_PASSWORD_EXCEPTION_MESSAGE);
			}
			userService.changePassword(user, updateUser.getConfirmNewPassword());
		} catch (Exception e) {
			logger.error("resetPwdSave exception ", e);
			return Echo.toFail(e);
		}
		
		return new ApiBaseResponse<Boolean>(rspCode, rspStatus, rspMsg);
	}

	@SecurityChecker("user:userInfo:remove")
	@RequestMapping("/remove")
	@ResponseBody
	@OperLog(functionName="删除",menuName="用户管理")
	public ApiBaseResponse<Boolean> remove(String ids) {
		SSOUser user = SSOClientUtils.getInstance().findCurrentUser();
		if (Arrays.asList(ids.split(",")).contains(user.getUserId())) {
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, ExceptionConstants.SUPER_USER_DELETE_NOT_ALLOW_MESSAGE, false);
		}
		String rspCode = Constants.API_RESPONSE_SUCCESS_CODE;
		RetStatusEnum rspStatus = RetStatusEnum.SUCCESS;
		String rspMsg = Constants.API_RESPONSE_SUCCESS_MESSAGE;
		try {
			userService.deleteUserByIds(Arrays.asList(ids.trim().split(",")));
		} catch (Exception e) {
			logger.error("delete user info exception ", e);
			return Echo.toFail(e);
		}
		return new ApiBaseResponse<Boolean>(rspCode, rspStatus, rspMsg);
	}

	/**
	 * 校验用户名
	 */
	@RequestMapping("/checkLoginNameUnique")
	@ResponseBody
	public ApiBaseResponse<Boolean> checkLoginNameUnique(UserInfo user) {
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, userService.checkLoginNameUnique(user));
	}

	/**
	 * 校验手机号码
	 */
	@RequestMapping("/checkPhoneUnique")
	@ResponseBody
	public ApiBaseResponse<Boolean> checkPhoneUnique(UserInfo user) {
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, userService.checkPhoneUnique(user));
	}

	/**
	 * 校验email邮箱
	 */
	@RequestMapping("/checkEmailUnique")
	@ResponseBody
	public ApiBaseResponse<Boolean> checkEmailUnique(UserInfo user) {
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, userService.checkEmailUnique(user));
	}

	/**
	 * 用户状态修改
	 */
	@SecurityChecker("user:userInfo:edit")
	@RequestMapping("/changeStatus")
	@ResponseBody
	@OperLog(functionName="修改状态",menuName="用户管理")
	public ApiBaseResponse<Boolean> changeStatus(UserInfo user) {
		if (UserUtils.isAdmin(user.getUserName())) {
			return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL, ExceptionConstants.SUPER_USER_UPDATE_NOT_ALLOW_MESSAGE, false);
		}
		// 实际更新了标识为失效/锁定
		try {
			user.setUpdateBy(SSOClientUtils.getInstance().findCurrentUser().getUserName());
			userService.updateUser(user);
//			cacheManager.set(user.getId(), user.getStatus());
		} catch (Exception e) {
			logger.error("update role info error ", e);
			return Echo.toFail(e);
		}
		return new ApiBaseResponse<Boolean>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE);
	}
	
	/**
	 * 查询用户数据：机构及子集机构的所有用户（超级管理员查询所有用户）
	 */
	@RequestMapping("/getUsers")
	@ResponseBody
	public List<UserInfo> getUsers() {
		return userService.selectUsersWithSubDept(SSOClientUtils.getInstance().findCurrentUser().getLoginDept().getId(), Integer.valueOf(YesOrNoEnum.YES.getCode()));
	}
	
	@RequestMapping("/selectUserById")
	@ResponseBody
	public ApiBaseResponse<UserInfo> selectUserById(String id) {
		UserInfo user = userService.selectUserById(id);
		return new ApiBaseResponse<UserInfo>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS, Constants.API_RESPONSE_SUCCESS_MESSAGE, user); 
	}
	
	@RequestMapping("/getUsersByName")
	@ResponseBody
	public ApiBaseResponse<Page<ExtUserDeptInfo>> getUsersByName(String parameters) {
		UserDeptConditionModel queryData = new UserDeptConditionModel();
		try {
			queryData = JSON.parseObject(parameters, UserDeptConditionModel.class);
		} catch (Exception e) {
			logger.error("parameters parse to object failed, ", e);
			return new ApiBaseResponse<Page<ExtUserDeptInfo>>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL,
					"请求参数结构不正确");
		}
		PageInfo<ExtUserDeptInfo> page = new PageInfo<ExtUserDeptInfo>();
		UserDeptConditionQueryData data = queryData.getQueryData();
		if (null == data) {
			logger.error("parameters is null");
			return new ApiBaseResponse<Page<ExtUserDeptInfo>>(Constants.API_RESPONSE_FAIL_CODE, RetStatusEnum.FAIL,
					"请求参数为空");
		}
		if (data.getResult() != null) {
			page.setCurrent(data.getResult().getCurrentPage());
			page.setLimit(data.getResult().getPageSize());
		} else {
			data.setResult(new Page<ExtUserDeptInfo>());
		}
		SSOUser ssoUser = SSOClientUtils.getInstance().findCurrentUser();
		// 非超级管理员，限定默认查询当前用户登录机构及其下级机构下的用户
		if (!UserUtils.isAdmin() && StringUtils.isBlank(data.getDeptId())) {
			data.setDeptId(ssoUser.getLoginDept().getId());
		}
		userService.selectUserDeptListByPage(data, page);
		data.getResult().setCurrentPage(page.getCurrent());
		data.getResult().setRows(page.getData());
		data.getResult().setTotal(page.getTotalRecord());
		
		return new ApiBaseResponse<Page<ExtUserDeptInfo>>(Constants.API_RESPONSE_SUCCESS_CODE, RetStatusEnum.SUCCESS,
				Constants.API_RESPONSE_SUCCESS_MESSAGE, data.getResult());
	}
	
}

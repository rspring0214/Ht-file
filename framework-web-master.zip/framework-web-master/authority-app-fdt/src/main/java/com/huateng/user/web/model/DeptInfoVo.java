/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.web.model;

import com.huateng.user.dal.model.DeptInfo;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: DeptInfoVo.java, v 0.1 2019年4月3日 下午3:31:17 Heaven.tang Exp $
 */
public class DeptInfoVo extends DeptInfo {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = -5078481975685018836L;

	private String parentName;

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	
	private boolean showOper;

	public boolean getShowOper() {
		return showOper;
	}

	public void setShowOper(boolean showOper) {
		this.showOper = showOper;
	}
	
}

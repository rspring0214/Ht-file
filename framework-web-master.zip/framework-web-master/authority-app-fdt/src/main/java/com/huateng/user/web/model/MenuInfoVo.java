package com.huateng.user.web.model;

import java.util.ArrayList;
import java.util.List;

import com.huateng.user.dal.model.MenuInfo;

public class MenuInfoVo extends MenuInfo {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -1440257027457334963L;

	private String parentName;

	private List<MenuInfoVo> children = new ArrayList<MenuInfoVo>(10);

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public List<MenuInfoVo> getChildren() {
		return children;
	}

	public void setChildren(List<MenuInfoVo> children) {
		this.children = children;
	}

}

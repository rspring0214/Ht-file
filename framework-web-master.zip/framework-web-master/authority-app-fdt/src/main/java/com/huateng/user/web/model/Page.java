/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.web.model;

import java.util.List;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: Page.java, v 0.1 2019年8月21日 下午3:17:30 Heaven.tang Exp $
 */
public class Page<T> {

	private Integer total = 0;// 总共有多少记录

	private Integer currentPage = 1;// 当前的页码

	private Integer pageSize = 10;// 每页条数

	private List<T> rows;// 数据

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	public Integer getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public List<T> getRows() {
		return rows;
	}

	public void setRows(List<T> rows) {
		this.rows = rows;
	}

}

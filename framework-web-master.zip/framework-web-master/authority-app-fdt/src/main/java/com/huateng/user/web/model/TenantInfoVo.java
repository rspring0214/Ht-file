/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.web.model;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: TenantInfoVo.java, v 0.1 2019年4月19日 上午10:24:21 Heaven.tang Exp $
 */
public class TenantInfoVo {

	private String id;
	
	private String tenantCode;
	
	private String tenantName;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTenantCode() {
		return tenantCode;
	}

	public void setTenantCode(String tenantCode) {
		this.tenantCode = tenantCode;
	}

	public String getTenantName() {
		return tenantName;
	}

	public void setTenantName(String tenantName) {
		this.tenantName = tenantName;
	}

}

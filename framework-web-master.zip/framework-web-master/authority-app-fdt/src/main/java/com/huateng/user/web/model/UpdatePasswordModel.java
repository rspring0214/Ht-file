/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.web.model;

/**
 * Description:修改密码参数对象
 *
 * @author Heaven.tang
 * @version $Id: UpdatePasswordModel.java, v 0.1 2019年4月17日 上午10:46:59 Heaven.tang Exp $
 */
public class UpdatePasswordModel {

	/** 用户ID，必填 */
	private String id;

	/** 用户原密码，登录用户操作更改密码时必填 */
	private String oldPassword;

	/** 新密码 */
	private String newPassword;

	/** 确认新密码 */
	private String confirmNewPassword;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOldPassword() {
		return oldPassword;
	}

	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getConfirmNewPassword() {
		return confirmNewPassword;
	}

	public void setConfirmNewPassword(String confirmNewPassword) {
		this.confirmNewPassword = confirmNewPassword;
	}

}

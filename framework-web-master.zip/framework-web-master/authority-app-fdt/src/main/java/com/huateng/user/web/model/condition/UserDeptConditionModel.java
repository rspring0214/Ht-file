/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.web.model.condition;

import java.io.Serializable;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: UserDeptConditionModel.java, v 0.1 2019年8月21日 下午4:24:07 Heaven.tang Exp $
 */
public class UserDeptConditionModel implements Serializable {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = 1506754845374697656L;
	
	private UserDeptConditionQueryData queryData;

	public UserDeptConditionQueryData getQueryData() {
		return queryData == null ? new UserDeptConditionQueryData() : queryData;
	}

	public void setQueryData(UserDeptConditionQueryData queryData) {
		this.queryData = queryData;
	}
	
}

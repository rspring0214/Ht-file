/**
 * Copyright (c) 2019 All Rights Reserved, Shanghai Huateng Software Systems Co., Ltd.
 */
package com.huateng.user.web.model.condition;

import com.huateng.user.core.model.userInfo.UserInfoQueryModel;
import com.huateng.user.dal.model.ext.ExtUserDeptInfo;
import com.huateng.user.web.model.Page;

/**
 * Description:(替换类描述)
 *
 * @author Heaven.tang
 * @version $Id: UserDeptConditionQueryData.java, v 0.1 2019年8月21日 下午4:26:55 Heaven.tang Exp $
 */
public class UserDeptConditionQueryData extends UserInfoQueryModel {

	/**
	 * serialVersionUID	
	 */
	private static final long serialVersionUID = -630510564820945089L;
	
	private Page<ExtUserDeptInfo> result;
	
	public Page<ExtUserDeptInfo> getResult() {
		return result;
	}

	public void setResult(Page<ExtUserDeptInfo> result) {
		this.result = result;
	}
	
}
